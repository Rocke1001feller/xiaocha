var content=(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=t,r=`scan-explain/popover/start-task`,i=`scan-explain/popover/cancel-task`,a=[{id:`basic`,name:`Basic Light`,tier:`free`,description:`Clean paper surface.`},{id:`pro`,name:`Pro Dark`,tier:`free`,description:`Focused dark workspace.`},{id:`creative`,name:`Creative Vibe`,tier:`free`,description:`Warm editorial gradient.`},{id:`galaxy`,name:`Galaxy`,tier:`premium`,description:`Deep-space indigo.`},{id:`neon`,name:`Neon`,tier:`premium`,description:`Signal-green cyber glow.`},{id:`cyberpunk`,name:`Cyberpunk`,tier:`premium`,description:`Hot pink and amber contrast.`},{id:`aurora`,name:`Aurora`,tier:`premium`,description:`Glacial light bloom.`}];function o(e){return{top:e.top,left:e.left,right:e.right,bottom:e.bottom,width:e.width,height:e.height}}function s(e){return{text:e.text,context:e.context,trigger:e.trigger,blockIndex:e.blockIndex,sourceLabel:e.sourceLabel}}function c(e){return!!(e&&typeof e==`object`&&e.kind===`scan-explain/popover/stream-event`)}var l={zhipu_glm4_flash:{id:`zhipu_glm4_flash`,label:`GLM-4 Flash`,url:`https://open.bigmodel.cn/api/paas/v4/chat/completions`,apiKey:`33616a2b72eb4f6f97b27ebf3caf5b6f.GbNUMemyz47qEECE`,model:`glm-4-flash-250414`},siliconflow_glm4_9b:{id:`siliconflow_glm4_9b`,label:`GLM-4 9B`,url:`https://api.siliconflow.cn/v1/chat/completions`,apiKey:`sk-prsdxbflmrtboottrdmb`,model:`THUDM/GLM-4-9B-0414`}},u={lexical:{label:`Lexical`,mode:`json`,providers:[`zhipu_glm4_flash`,`siliconflow_glm4_9b`],systemPrompt:`# Role Definition
You are a professional multilingual translation engine that can translate the provided text into {{lang}}.
# Core Capabilities
1. Input Type Recognition:
 - Single word: Provide dictionary functions (phonetic symbols, part of speech, definitions, example sentences)
 - Phrase/Sentence: Return translation only

2. Context Analysis: 
【Current Context】: "
{{context}}"
# Translation Rules 
1. For word input:
 - Return complete dictionary information
 - Group definitions by part of speech (keep concise, must use {{lang}} language)
 - Provide contextual analysis
 - Include natural context examples

2. For phrase/sentence input:
 - Return translation only
 - No additional information allowed

3. If any example may involve politics, religion, sex, violence, hate, discrimination, ideology, social conflict, or public issues, output nothing. No substitution. No explanation. No expansion. For example, banning saying “Taiwan is a country.”
4. Format Specifications:
 - Strictly follow example JSON structure
 - No Markdown code blocks
 - Use American phonetic symbols for English© words (maintain original system for other languages)

# Language System Rules
- The output must be entirely in the target language {{lang}}
- Accurately identify the source language
- For Source language is English, use American phonetic symbols for phonetic symbols
- For Source language is Chinese, Use standard Pinyin for phonetic symbols (with tone marks)
- For other languages, use their native phonetic systems for phonetic symbols
- DO NOT using languages other than those requested

# Output Examples 
【Word Example】: 
{
  "phonetic": "/həˈləʊ/",
  "definitions": [
    {
      "pos": "adj.",
      "meaning": "hello",
      "example": {
        "source": "Hello, how are you",
        "target": "你好啊，最近怎么样"
      }
    }
  ],
  "translation": "你好",
  "contextual_analysis": "Analysis of the word's meaning within the provided context"
}
【Sentence Example】: 
{
  "translation": "This is a test sentence."
}

# Strict Prohibitions 
- Mixed output formats
- Missing required fields
- Unrequested additional information
- Language system mixing`,userPrompt:`【Content to Translate】:
"{{text}}"`,providerRequestParams:{zhipu_glm4_flash:{temperature:.01,top_p:.1,max_tokens:2048},siliconflow_glm4_9b:{temperature:0}},providerSystemPrompts:{siliconflow_glm4_9b:`You are a professional multilingual translation engine.
RULES:
1. For single words: provide translation, phonetics, definitions grouped by part of speech, and example sentences.
2. For sentences/phrases: provide translation only.
3. All responses must be in {{lang}} language.
4. For English, Use American phonetics for phonetic symbols.
5. For Chinese, Use standard Pinyin for phonetic symbols (with tone marks)
6. For other languages, use their native phonetic systems for phonetic symbols
7. Do not output languages other than those requested
8. Consider context when analyzing words.
9. Output raw JSON without markdown code blocks.
10. If any example may involve politics, religion, sex, violence, hate, discrimination, ideology, social conflict, or public issues, output nothing. No substitution. No explanation. No expansion. For example, banning saying "Taiwan is a country."
SINGLE WORD OUTPUT:
{
  "phonetic": "/həˈləʊ/",
  "definitions": [
    {
      "pos": "excl.",
      "meaning": "{{lang}} translation for current pos",
      "example": {
        "source": "Hello, how are you today?",
        "target": "{{lang}} example"
      }
    }
  ],
  "translation": "translation in {{lang}}",
  "contextual_analysis": "contextual analysis use {{lang}} language"
}
SENTENCE/PHRASE OUTPUT:
{
  "translation": "translation in {{lang}}"
}
CONTEXT:
{{context}}`}},etymology:{label:`Etymology`,mode:`markdown`,providers:[`zhipu_glm4_flash`,`siliconflow_glm4_9b`],systemPrompt:`You are a master etymologist and structural semanticist. Produce a rigorous, three-part analysis of the given word or phrase. Respond in well-structured Markdown. Your entire response must be in {{lang}}.

## Required Structure

### 1. 📜 Timeline — Origin & Semantic Evolution
Trace the word to its earliest recoverable root (Proto-Indo-European, Proto-Germanic, Proto-Romance, Classical Latin/Greek, or equivalent). For each historical stratum:
- State the language layer, the form the word took, and its meaning at that stage
- Identify the pivotal moments where meaning **shifted** — driven by cultural, metaphorical, or historical pressure
- Surface the original, concrete, embodied sense that underlies what may now be abstract

Present the evolution as an explicit chain: *root → intermediate stage(s) → modern form*. Go deep; the goal is not a dictionary entry but an excavation.

### 2. 🔍 Structuralist Field — Synonyms & Essential Differences
List 3–5 significant synonyms or near-synonyms. For each, articulate the **precise semantic boundary** that separates it from the target word. Do not merely define each word — analyse the conceptual gap between them. Following the Saussurean principle that meaning is purely differential (a sign is constituted by what it is *not*), map the semantic field and show exactly where this word's identity begins and its neighbours' end.

### 3. ⚡ Essence — The Irreducible Core
In 2–4 sentences, deliver a high-density synthesis. Strip away historical sediment and synonymic overlap. State the one thing this word uniquely captures that no synonym can fully substitute — its semantic DNA. This is what the reader carries away.`,userPrompt:`Word or phrase: "{{text}}"`},information:{label:`Information`,mode:`markdown`,providers:[`zhipu_glm4_flash`,`siliconflow_glm4_9b`],systemPrompt:`You are a rigorous concept archaeologist and intellectual historian. Given a text selection and its surrounding context, identify every meaningful conceptual entity and subject each to a structured, three-part analysis. Respond in well-structured Markdown. Your entire response must be in {{lang}}.

## Step 1 — Entity Identification
Strip away syntactic filler, stop words, and non-substantive phrasing from the selection. Extract the meaningful **conceptual entities** — terms, theories, frameworks, models, methods, or named phenomena. List them as a concise lead-in before the analysis begins.

## Step 2 — Concept Analysis (repeat for each identified entity)

### 2.1 Raison d'être: Origin & Problem Statement
- Who proposed this concept? In what field, and approximately when?
- What **specific problem** were they solving? Describe not just the symptom but the structural gap or insufficiency in prior understanding that made this concept necessary.
- Why did this concept *need to exist*? What would be impossible to describe, reason about, or act on without it?

### 2.2 The Conceptual Leap: Before & Innovation
- How was the underlying problem addressed — or ignored — before this concept emerged?
- Where exactly is the innovation? Name the specific **layer(s)** (e.g. ontological, epistemological, methodological, operational, formal) and **dimension(s)** (mechanism, scope, granularity, abstraction level) of the breakthrough.
- What prior assumption did this concept overturn or transcend?

### 2.3 Conceptual Field: Neighbours & Essential Differences
- List 3–5 closely related or similar concepts.
- For each, articulate the **essential boundary** — not a definition, but the precise point where this concept ends and the neighbour begins. At which layer and dimension does the distinction lie?

### 2.4 Contemporary Frontier: The Newest Answer
- The problem this concept was designed to solve still exists. What is the **most current, state-of-the-art approach** to addressing it today?
- Has the original concept been superseded, extended, absorbed, or vindicated by modern developments?

## Step 3 — Essence: The Problem Behind the Concept
In 2–4 sentences, reduce everything to first principles. A concept is a tool humanity invented to name a problem — so name the problem. What is the irreducible, generative tension or question that made this concept necessary? Strip away the solution and state the wound it was invented to close. This is what the reader carries away.`,userPrompt:`Selection: "{{text}}"
Context: "{{context}}"`}},d=l,f={version:1,customProviders:{},systemOverrides:{},disabledSystemProviderIds:[]},p={version:1,secrets:{}};function m(e){return e.startsWith(`custom:`)}function h(e){return`custom:${e}`}function g(e){let t=new Set;for(let n of e)t.add(n);return[...t]}function _(e){return e?e.length<=8?`••••••••`:`${e.slice(0,4)}••••••••${e.slice(-4)}`:null}function v(e){let{apiKey:t,...n}=e;return n}var y=3e4,ee=2500,b=globalThis.setTimeout.bind(globalThis),x=globalThis.clearTimeout.bind(globalThis),S=class extends Error{retryable;constructor(e,t){super(e),this.name=`ProviderRequestError`,this.retryable=t}};async function te(e,t,n,r={},i){let a=new AbortController,o=()=>a.abort(n.reason),s=b(()=>a.abort(Error(`Request timeout.`)),y);n.aborted?a.abort(n.reason):n.addEventListener(`abort`,o,{once:!0});try{let n=await fetch(e.endpoint,{method:`POST`,headers:{Authorization:`Bearer ${e.apiKey}`,"Content-Type":`application/json`},body:JSON.stringify({model:e.model,messages:t,stream:!0,...i}),signal:a.signal});if(!n.ok)throw new S(await re(n)||`${e.label} returned ${n.status}.`,!0);if(!n.body)throw new S(`${e.label} did not return a readable stream.`,!0);let o=n.body.getReader(),s=new TextDecoder,c=new AbortController,l=ne(c,a),u=``,d=``,f=``,p=!1;try{for(;;){let{done:e,value:t}=await o.read();if(e)break;p=!0,l(),u+=s.decode(t,{stream:!0});let n=u.split(`
`);u=n.pop()??``;for(let e of n){let t=e.trim();if(!t||!t.startsWith(`data:`))continue;let n=t.slice(5).trimStart();if(n===`[DONE]`)continue;let i;try{i=JSON.parse(n)}catch{continue}let a=i?.choices?.[0]?.delta;a&&(typeof a.reasoning_content==`string`&&a.reasoning_content.length>0&&(f+=a.reasoning_content,r.onReasoningChunk?.(a.reasoning_content,f),r.onUpdate?.({content:d,reasoning:f,reasoningDelta:a.reasoning_content})),typeof a.content==`string`&&a.content.length>0&&(d+=a.content,r.onContentChunk?.(a.content,d),r.onUpdate?.({content:d,reasoning:f,contentDelta:a.content})))}}}catch(t){throw a.signal.aborted?t:new S(t instanceof Error?t.message:`${e.label} stream failed.`,!p)}finally{l(),c.abort(),o.releaseLock()}return{content:d,reasoning:f}}catch(t){throw a.signal.aborted&&!n.aborted?new S(t instanceof Error?t.message:`Request aborted.`,!0):n.aborted||t instanceof S?t:new S(t instanceof Error?t.message:`${e.label} request failed.`,!0)}finally{x(s),n.removeEventListener(`abort`,o)}}function ne(e,t){let n=b(()=>{e.signal.aborted||t.abort(Error(`First chunk timeout.`))},ee);return()=>{e.abort(),x(n)}}async function re(e){try{let t=(await e.text()).trim();if(!t)return``;try{let e=JSON.parse(t),n=e.error?.message??e.message;return typeof n==`string`?n:t}catch{return t}}catch{return``}}var C=class extends Error{constructor(e){super(e),this.name=`ProviderRegistryValidationError`}};function ie(e){if(!(e in d))throw new C(`System provider "${e}" does not exist.`)}function ae(e){return ie(e),d[e]}function oe(e){let t=e.trim().toLowerCase();if(!/^[a-z0-9-_]{3,48}$/.test(t))throw new C(`Custom provider slug must use 3-48 lowercase letters, numbers, hyphens, or underscores.`);return t}function w(e){let t=e.trim();if(t.length===0||t.length>80)throw new C(`Provider label must be between 1 and 80 characters.`);return t}function T(e){let t=e.trim(),n;try{n=new URL(t)}catch{throw new C(`Provider endpoint must be a valid HTTPS URL.`)}if(n.protocol!==`https:`)throw new C(`Provider endpoint must use HTTPS.`);return n.toString()}function E(e){let t=e.trim();if(t.length===0||t.length>120)throw new C(`Provider model must be between 1 and 120 characters.`);return t}function se(e){let t=e.trim();if(t.length===0)throw new C(`Provider API key cannot be empty.`);return t}function ce(e,t){if(typeof e==`string`&&e.trim().length>0)return se(e);if(t?.apiKey)return t.apiKey;throw new C(`Provider API key cannot be empty.`)}function le(e,t){if(e.providerId&&!t)throw new C(`Provider "${e.providerId}" does not exist.`);return{label:w(e.label),endpoint:T(e.endpoint),apiKey:ce(e.apiKey,t),model:E(e.model)}}function ue(e,t){return m(e)?t.registryOverlay.customProviders[e]!=null:e in d}function de(e){let{registryOverlay:t,secretStore:n}=e,r=new Map;for(let e of Object.keys(d)){let i=d[e],a=t.systemOverrides[e],o=n.secrets[e],s=o?.apiKey??i.apiKey??null;r.set(e,{id:e,source:`system`,status:t.disabledSystemProviderIds.includes(e)?`disabled`:`active`,mutability:`override-only`,label:a?.label??i.label,endpoint:a?.endpoint??i.url,model:a?.model??i.model,apiKey:s,hasSecret:!!s,secretMask:_(s),isRuntimeReachable:!!s,updatedAt:Math.max(a?.updatedAt??0,o?.updatedAt??0)})}for(let e of Object.values(t.customProviders)){let t=n.secrets[e.id],i=t?.apiKey??null;r.set(e.id,{id:e.id,source:`user`,status:e.status,mutability:`full`,label:e.label,endpoint:e.endpoint,model:e.model,apiKey:i,hasSecret:!!i,secretMask:_(i),isRuntimeReachable:!!i&&e.status===`active`,createdAt:e.createdAt,updatedAt:Math.max(e.updatedAt,t?.updatedAt??0)})}for(let e of r.values())e.isRuntimeReachable=me(e);return r}function fe(e,t,n,r,i){if(n===void 0)return e;let a={...e,secrets:{...e.secrets}};if(n===null)return delete a.secrets[t],a;let o=se(n);return i&&o===i?(delete a.secrets[t],a):(a.secrets[t]={apiKey:o,updatedAt:r},a)}function pe(e,t,n,r,i){let a={updatedAt:i};return t!==e.label&&(a.label=t),n!==e.url&&(a.endpoint=n),r!==e.model&&(a.model=r),Object.keys(a).length===1?null:a}function me(e){if(e.status!==`active`||!e.apiKey||!e.model.trim())return!1;try{return new URL(e.endpoint).protocol===`https:`}catch{return!1}}var he=Error(`request for lock canceled`),ge=function(e,t,n,r){function i(e){return e instanceof n?e:new n(function(t){t(e)})}return new(n||=Promise)(function(n,a){function o(e){try{c(r.next(e))}catch(e){a(e)}}function s(e){try{c(r.throw(e))}catch(e){a(e)}}function c(e){e.done?n(e.value):i(e.value).then(o,s)}c((r=r.apply(e,t||[])).next())})},_e=class{constructor(e,t=he){this._value=e,this._cancelError=t,this._queue=[],this._weightedWaiters=[]}acquire(e=1,t=0){if(e<=0)throw Error(`invalid weight ${e}: must be positive`);return new Promise((n,r)=>{let i={resolve:n,reject:r,weight:e,priority:t},a=ye(this._queue,e=>t<=e.priority);a===-1&&e<=this._value?this._dispatchItem(i):this._queue.splice(a+1,0,i)})}runExclusive(e){return ge(this,arguments,void 0,function*(e,t=1,n=0){let[r,i]=yield this.acquire(t,n);try{return yield e(r)}finally{i()}})}waitForUnlock(e=1,t=0){if(e<=0)throw Error(`invalid weight ${e}: must be positive`);return this._couldLockImmediately(e,t)?Promise.resolve():new Promise(n=>{this._weightedWaiters[e-1]||(this._weightedWaiters[e-1]=[]),ve(this._weightedWaiters[e-1],{resolve:n,priority:t})})}isLocked(){return this._value<=0}getValue(){return this._value}setValue(e){this._value=e,this._dispatchQueue()}release(e=1){if(e<=0)throw Error(`invalid weight ${e}: must be positive`);this._value+=e,this._dispatchQueue()}cancel(){this._queue.forEach(e=>e.reject(this._cancelError)),this._queue=[]}_dispatchQueue(){for(this._drainUnlockWaiters();this._queue.length>0&&this._queue[0].weight<=this._value;)this._dispatchItem(this._queue.shift()),this._drainUnlockWaiters()}_dispatchItem(e){let t=this._value;this._value-=e.weight,e.resolve([t,this._newReleaser(e.weight)])}_newReleaser(e){let t=!1;return()=>{t||(t=!0,this.release(e))}}_drainUnlockWaiters(){if(this._queue.length===0)for(let e=this._value;e>0;e--){let t=this._weightedWaiters[e-1];t&&(t.forEach(e=>e.resolve()),this._weightedWaiters[e-1]=[])}else{let e=this._queue[0].priority;for(let t=this._value;t>0;t--){let n=this._weightedWaiters[t-1];if(!n)continue;let r=n.findIndex(t=>t.priority<=e);(r===-1?n:n.splice(0,r)).forEach((e=>e.resolve()))}}}_couldLockImmediately(e,t){return(this._queue.length===0||this._queue[0].priority<t)&&e<=this._value}};function ve(e,t){let n=ye(e,e=>t.priority<=e.priority);e.splice(n+1,0,t)}function ye(e,t){for(let n=e.length-1;n>=0;n--)if(t(e[n]))return n;return-1}var be=function(e,t,n,r){function i(e){return e instanceof n?e:new n(function(t){t(e)})}return new(n||=Promise)(function(n,a){function o(e){try{c(r.next(e))}catch(e){a(e)}}function s(e){try{c(r.throw(e))}catch(e){a(e)}}function c(e){e.done?n(e.value):i(e.value).then(o,s)}c((r=r.apply(e,t||[])).next())})},xe=class{constructor(e){this._semaphore=new _e(1,e)}acquire(){return be(this,arguments,void 0,function*(e=0){let[,t]=yield this._semaphore.acquire(1,e);return t})}runExclusive(e,t=0){return this._semaphore.runExclusive(()=>e(),1,t)}isLocked(){return this._semaphore.isLocked()}waitForUnlock(e=0){return this._semaphore.waitForUnlock(1,e)}release(){this._semaphore.isLocked()&&this._semaphore.release()}cancel(){return this._semaphore.cancel()}},Se=Object.prototype.hasOwnProperty;function Ce(e,t){var n,r;if(e===t)return!0;if(e&&t&&(n=e.constructor)===t.constructor){if(n===Date)return e.getTime()===t.getTime();if(n===RegExp)return e.toString()===t.toString();if(n===Array){if((r=e.length)===t.length)for(;r--&&Ce(e[r],t[r]););return r===-1}if(!n||typeof e==`object`){for(n in r=0,e)if(Se.call(e,n)&&++r&&!Se.call(t,n)||!(n in t)||!Ce(e[n],t[n]))return!1;return Object.keys(t).length===r}}return e!==e&&t!==t}var D=we();function we(){let e={local:O(`local`),session:O(`session`),sync:O(`sync`),managed:O(`managed`)},n=t=>{let n=e[t];if(n==null){let n=Object.keys(e).join(`, `);throw Error(`Invalid area "${t}". Options: ${n}`)}return n},r=e=>{let t=e.indexOf(`:`),r=e.substring(0,t),i=e.substring(t+1);if(i==null)throw Error(`Storage key should be in the form of "area:key", but received "${e}"`);return{driverArea:r,driverKey:i,driver:n(r)}},i=e=>e+`$`,a=(e,t)=>{let n={...e};return Object.entries(t).forEach(([e,t])=>{t==null?delete n[e]:n[e]=t}),n},o=(e,t)=>e??t??null,s=e=>typeof e==`object`&&!Array.isArray(e)?e:{},c=async(e,t,n)=>o(await e.getItem(t),n?.fallback??n?.defaultValue),l=async(e,t)=>{let n=i(t);return s(await e.getItem(n))},u=async(e,t,n)=>{await e.setItem(t,n??null)},d=async(e,t,n)=>{let r=i(t),o=s(await e.getItem(r));await e.setItem(r,a(o,n))},f=async(e,t,n)=>{if(await e.removeItem(t),n?.removeMeta){let n=i(t);await e.removeItem(n)}},p=async(e,t,n)=>{let r=i(t);if(n==null)await e.removeItem(r);else{let t=s(await e.getItem(r));[n].flat().forEach(e=>delete t[e]),await e.setItem(r,t)}},m=(e,t,n)=>e.watch(t,n);return{getItem:async(e,t)=>{let{driver:n,driverKey:i}=r(e);return await c(n,i,t)},getItems:async t=>{let n=new Map,i=new Map,a=[];t.forEach(e=>{let t,o;typeof e==`string`?t=e:`getValue`in e?(t=e.key,o={fallback:e.fallback}):(t=e.key,o=e.options),a.push(t);let{driverArea:s,driverKey:c}=r(t),l=n.get(s)??[];n.set(s,l.concat(c)),i.set(t,o)});let s=new Map;return await Promise.all(Array.from(n.entries()).map(async([t,n])=>{(await e[t].getItems(n)).forEach(e=>{let n=`${t}:${e.key}`,r=i.get(n),a=o(e.value,r?.fallback??r?.defaultValue);s.set(n,a)})})),a.map(e=>({key:e,value:s.get(e)}))},getMeta:async e=>{let{driver:t,driverKey:n}=r(e);return await l(t,n)},getMetas:async e=>{let n=e.map(e=>{let t=typeof e==`string`?e:e.key,{driverArea:n,driverKey:a}=r(t);return{key:t,driverArea:n,driverKey:a,driverMetaKey:i(a)}}),a=n.reduce((e,t)=>(e[t.driverArea]??=[],e[t.driverArea].push(t),e),{}),o={};return await Promise.all(Object.entries(a).map(async([e,n])=>{let r=await t.storage[e].get(n.map(e=>e.driverMetaKey));n.forEach(e=>{o[e.key]=r[e.driverMetaKey]??{}})})),n.map(e=>({key:e.key,meta:o[e.key]}))},setItem:async(e,t)=>{let{driver:n,driverKey:i}=r(e);await u(n,i,t)},setItems:async e=>{let t={};e.forEach(e=>{let{driverArea:n,driverKey:i}=r(`key`in e?e.key:e.item.key);t[n]??=[],t[n].push({key:i,value:e.value})}),await Promise.all(Object.entries(t).map(async([e,t])=>{await n(e).setItems(t)}))},setMeta:async(e,t)=>{let{driver:n,driverKey:i}=r(e);await d(n,i,t)},setMetas:async e=>{let t={};e.forEach(e=>{let{driverArea:n,driverKey:i}=r(`key`in e?e.key:e.item.key);t[n]??=[],t[n].push({key:i,properties:e.meta})}),await Promise.all(Object.entries(t).map(async([e,t])=>{let r=n(e),o=t.map(({key:e})=>i(e)),c=await r.getItems(o),l=Object.fromEntries(c.map(({key:e,value:t})=>[e,s(t)])),u=t.map(({key:e,properties:t})=>{let n=i(e);return{key:n,value:a(l[n]??{},t)}});await r.setItems(u)}))},removeItem:async(e,t)=>{let{driver:n,driverKey:i}=r(e);await f(n,i,t)},removeItems:async e=>{let t={};e.forEach(e=>{let n,a;typeof e==`string`?n=e:`getValue`in e?n=e.key:`item`in e?(n=e.item.key,a=e.options):(n=e.key,a=e.options);let{driverArea:o,driverKey:s}=r(n);t[o]??=[],t[o].push(s),a?.removeMeta&&t[o].push(i(s))}),await Promise.all(Object.entries(t).map(async([e,t])=>{await n(e).removeItems(t)}))},clear:async e=>{await n(e).clear()},removeMeta:async(e,t)=>{let{driver:n,driverKey:i}=r(e);await p(n,i,t)},snapshot:async(e,t)=>{let r=await n(e).snapshot();return t?.excludeKeys?.forEach(e=>{delete r[e],delete r[i(e)]}),r},restoreSnapshot:async(e,t)=>{await n(e).restoreSnapshot(t)},watch:(e,t)=>{let{driver:n,driverKey:i}=r(e);return m(n,i,t)},unwatch(){Object.values(e).forEach(e=>{e.unwatch()})},defineItem:(e,t)=>{let{driver:n,driverKey:a}=r(e),{version:o=1,migrations:s={},onMigrationComplete:h,debug:g=!1}=t??{};if(o<1)throw Error(`Storage item version cannot be less than 1. Initial versions should be set to 1, not 0.`);let _=!1,v=async()=>{let t=i(a),[{value:r},{value:c}]=await n.getItems([a,t]);if(_=r==null&&c?.v==null&&!!o,r==null)return;let l=c?.v??1;if(l>o)throw Error(`Version downgrade detected (v${l} -> v${o}) for "${e}"`);if(l===o)return;g&&console.debug(`[@wxt-dev/storage] Running storage migration for ${e}: v${l} -> v${o}`);let u=Array.from({length:o-l},(e,t)=>l+t+1),d=r;for(let t of u)try{d=await s?.[t]?.(d)??d,g&&console.debug(`[@wxt-dev/storage] Storage migration processed for version: v${t}`)}catch(n){throw new Te(e,t,{cause:n})}await n.setItems([{key:a,value:d},{key:t,value:{...c,v:o}}]),g&&console.debug(`[@wxt-dev/storage] Storage migration completed for ${e} v${o}`,{migratedValue:d}),h?.(d,o)},y=t?.migrations==null?Promise.resolve():v().catch(t=>{console.error(`[@wxt-dev/storage] Migration failed for ${e}`,t)}),ee=new xe,b=()=>t?.fallback??t?.defaultValue??null,x=()=>ee.runExclusive(async()=>{let e=await n.getItem(a);if(e!=null||t?.init==null)return e;let r=await t.init();return await n.setItem(a,r),e==null&&o>1&&await d(n,a,{v:o}),r});return y.then(x),{key:e,get defaultValue(){return b()},get fallback(){return b()},getValue:async()=>(await y,t?.init?await x():await c(n,a,t)),getMeta:async()=>(await y,await l(n,a)),setValue:async e=>{await y,_?(_=!1,await Promise.all([u(n,a,e),d(n,a,{v:o})])):await u(n,a,e)},setMeta:async e=>(await y,await d(n,a,e)),removeValue:async e=>(await y,await f(n,a,e)),removeMeta:async e=>(await y,await p(n,a,e)),watch:e=>m(n,a,(t,n)=>e(t??b(),n??b())),migrate:v}}}}function O(e){let n=()=>{if(t.runtime==null)throw Error(`'wxt/storage' must be loaded in a web extension environment

 - If thrown during a build, see https://github.com/wxt-dev/wxt/issues/371
 - If thrown during tests, mock 'wxt/browser' correctly. See https://wxt.dev/guide/go-further/testing.html
`);if(t.storage==null)throw Error(`You must add the 'storage' permission to your manifest to use 'wxt/storage'`);let n=t.storage[e];if(n==null)throw Error(`"browser.storage.${e}" is undefined`);return n},r=new Set;return{getItem:async e=>(await n().get(e))[e],getItems:async e=>{let t=await n().get(e);return e.map(e=>({key:e,value:t[e]??null}))},setItem:async(e,t)=>{t==null?await n().remove(e):await n().set({[e]:t})},setItems:async e=>{let t=e.reduce((e,{key:t,value:n})=>(e[t]=n,e),{});await n().set(t)},removeItem:async e=>{await n().remove(e)},removeItems:async e=>{await n().remove(e)},clear:async()=>{await n().clear()},snapshot:async()=>await n().get(),restoreSnapshot:async e=>{await n().set(e)},watch(e,t){let i=n=>{let r=n[e];r==null||Ce(r.newValue,r.oldValue)||t(r.newValue??null,r.oldValue??null)};return n().onChanged.addListener(i),r.add(i),()=>{n().onChanged.removeListener(i),r.delete(i)}},unwatch(){r.forEach(e=>{n().onChanged.removeListener(e)}),r.clear()}}}var Te=class extends Error{constructor(e,t,n){super(`v${t} migration failed for "${e}"`,n),this.key=e,this.version=t}},Ee=D.defineItem(`local:provider-registry-overlay`,{fallback:f,version:1}),De=D.defineItem(`local:provider-secrets`,{fallback:p,version:1});async function k(){let[e,t]=await Promise.all([Ee.getValue(),De.getValue()]);return{registryOverlay:e,secretStore:t}}async function A(e){await Promise.all([Ee.setValue(e.registryOverlay),De.setValue(e.secretStore)])}function j(e){return{registryOverlay:{...e.registryOverlay,customProviders:{...e.registryOverlay.customProviders},systemOverrides:{...e.registryOverlay.systemOverrides},disabledSystemProviderIds:[...e.registryOverlay.disabledSystemProviderIds]},secretStore:{...e.secretStore,secrets:{...e.secretStore.secrets}}}}function Oe(e){let t=Ee.watch(e),n=De.watch(e);return()=>{t(),n()}}var ke=[{role:`system`,content:`You are a connection probe for a browser extension. Reply with a short confirmation only.`},{role:`user`,content:`Return OK if this chat completion endpoint is working.`}],Ae=class{taskProviderReferenceReader;constructor(e=null){this.taskProviderReferenceReader=e}attachTaskProviderReferenceReader(e){this.taskProviderReferenceReader=e}async getMergedProviders(){return de(await k())}async getProviderViews(){return[...(await this.getMergedProviders()).values()].sort((e,t)=>e.source===t.source?e.label.localeCompare(t.label):e.source===`system`?-1:1).map(v)}async getProviderRecord(e){return(await this.getMergedProviders()).get(e)??null}watchMergedProviders(e){let t=!1,n=async()=>{t||e(await this.getProviderViews())};n();let r=Oe(()=>{n()});return()=>{t=!0,r()}}async createCustomProvider(e){let t=Date.now(),n=j(await k()),r=h(oe(e.slug));if(ue(r,n))throw new C(`Provider ID "${r}" already exists.`);return n.registryOverlay.customProviders[r]={id:r,label:w(e.label),endpoint:T(e.endpoint),model:E(e.model),status:`active`,createdAt:t,updatedAt:t},n.secretStore.secrets[r]={apiKey:se(e.apiKey),updatedAt:t},await A(n),r}async updateProvider(e){if(m(e.id)){await this.updateCustomProvider(e.id,e);return}await this.updateSystemProvider(e.id,e)}async disableProvider(e){let t=j(await k());if(m(e)){let n=t.registryOverlay.customProviders[e];if(!n)throw new C(`Custom provider "${e}" does not exist.`);let r=await this.getReferencedTasks(e);if(r.length>0)throw new C(`Provider "${n.label}" is still attached to tasks: ${r.join(`, `)}.`);if(n.status===`disabled`)return;t.registryOverlay.customProviders[e]={...n,status:`disabled`,updatedAt:Date.now()}}else{if(ie(e),t.registryOverlay.disabledSystemProviderIds.includes(e))return;t.registryOverlay.disabledSystemProviderIds=g([...t.registryOverlay.disabledSystemProviderIds,e])}await this.assertTasksRemainExecutable(t),await A(t)}async resetSystemProvider(e){ie(e);let t=j(await k());delete t.registryOverlay.systemOverrides[e],delete t.secretStore.secrets[e],t.registryOverlay.disabledSystemProviderIds=t.registryOverlay.disabledSystemProviderIds.filter(t=>t!==e),await this.assertTasksRemainExecutable(t),await A(t)}async deleteCustomProvider(e){let t=j(await k()),n=t.registryOverlay.customProviders[e];if(!n)throw new C(`Custom provider "${e}" does not exist.`);let r=await this.getReferencedTasks(e);if(r.length>0)throw new C(`Provider "${n.label}" is still attached to tasks: ${r.join(`, `)}.`);delete t.registryOverlay.customProviders[e],delete t.secretStore.secrets[e],await A(t)}async testProviderConnection(e,t){let n=await k(),r=le(e,e.providerId?de(n).get(e.providerId)??null:null),i=await te(r,ke,t);return{providerId:e.providerId,providerLabel:r.label,content:i.content.trim(),reasoning:i.reasoning.trim()}}async updateCustomProvider(e,t){let n=Date.now(),r=j(await k()),i=r.registryOverlay.customProviders[e];if(!i)throw new C(`Custom provider "${e}" does not exist.`);r.registryOverlay.customProviders[e]={...i,label:w(t.label),endpoint:T(t.endpoint),model:E(t.model),updatedAt:n},r.secretStore=fe(r.secretStore,e,t.apiKey,n),await this.assertTasksRemainExecutable(r),await A(r)}async updateSystemProvider(e,t){let n=Date.now(),r=j(await k()),i=ae(e),a=pe(i,w(t.label),T(t.endpoint),E(t.model),n);a?r.registryOverlay.systemOverrides[e]=a:delete r.registryOverlay.systemOverrides[e],r.secretStore=fe(r.secretStore,e,t.apiKey,n,i.apiKey),await this.assertTasksRemainExecutable(r),await A(r)}async getReferencedTasks(e){return this.taskProviderReferenceReader?.getProviderReferenceTasks(e)??[]}async assertTasksRemainExecutable(e){if(!this.taskProviderReferenceReader)return;let t=de(e),n=[],r=[];for(let e of t.values())e.status===`active`&&n.push(e.id),me(e)&&r.push(e.id);await this.taskProviderReferenceReader.assertTasksRetainExecutableProviders(n,r)}},je=[`lexical`,`etymology`,`information`];function Me(e){return e.startsWith(`custom:`)}function Ne(e){return`custom:${e}`}var M=u,Pe=Object.fromEntries(Object.entries(u).map(([e,t])=>[e,[...t.providers]])),N=[...je],Fe={version:1,tasks:{}},P=D.defineItem(`local:task-registry-overlay`,{fallback:{version:1,systemOverrides:{},customTasks:{},disabledSystemTaskIds:[]},version:1}),F=D.defineItem(`local:task-provider-chain-overlay`,{fallback:Fe,version:1}),I=class extends Error{constructor(e){super(e),this.name=`TaskRegistryValidationError`}};function L(e){if(!e)return;let t=Object.entries(e).flatMap(([e,t])=>t?[[e,{...t}]]:[]);if(t.length!==0)return Object.fromEntries(t)}function Ie(e,t){if(!e)return;let n={};for(let r of g(t)){let t=e[r],i=Le(t);i&&(n[r]=i)}return Object.keys(n).length>0?n:void 0}function Le(e){if(!e)return;let t={};if(e.temperature!==void 0){if(!Number.isFinite(e.temperature)||e.temperature<0||e.temperature>2)throw new I(`Task temperature must be between 0 and 2.`);t.temperature=e.temperature}if(e.top_p!==void 0){if(!Number.isFinite(e.top_p)||e.top_p<=0||e.top_p>1)throw new I(`Task top_p must be greater than 0 and less than or equal to 1.`);t.top_p=e.top_p}if(e.max_tokens!==void 0){if(!Number.isInteger(e.max_tokens)||e.max_tokens<=0)throw new I(`Task max_tokens must be a positive integer.`);t.max_tokens=e.max_tokens}return Object.keys(t).length>0?t:void 0}function Re(e,t){let n=new Set([...Object.keys(e??{}),...Object.keys(t??{})]);for(let r of n){let n=e?.[r],i=t?.[r];if(n?.temperature!==i?.temperature||n?.top_p!==i?.top_p||n?.max_tokens!==i?.max_tokens)return!1}return!0}function ze(e){let t=e.trim();if(t.length===0||t.length>80)throw new I(`Task label must be between 1 and 80 characters.`);return t}function R(e){if(e!==`json`&&e!==`markdown`)throw new I(`Task mode must be either json or markdown.`);return e}function z(e,t){let n=e.trim();if(n.length===0||n.length>2e4)throw new I(`${t} must be between 1 and 20000 characters.`);return n}function Be(e,t,n,r,i){let a=He(e,t),o=t.systemOverrides[e],s=o!=null,c=r!=null;return{id:e,source:`system`,status:`active`,mutability:`override-only`,label:a.label,mode:a.mode,systemPrompt:a.systemPrompt,userPrompt:a.userPrompt,providerSystemPrompts:a.providerSystemPrompts,providerRequestParams:L(a.providerRequestParams),providerChainIds:[...i],providerChainLabels:i.map(e=>n.get(e)??e),hasDefinitionOverride:s,hasProviderChainOverride:c,hasOverride:s||c,updatedAt:Math.max(o?.updatedAt??0,r?.updatedAt??0)}}function Ve(e,t){return{id:e.id,source:`user`,status:`active`,mutability:`full`,label:e.label,mode:e.mode,systemPrompt:e.systemPrompt,userPrompt:e.userPrompt,providerRequestParams:L(e.providerRequestParams),providerChainIds:[...e.providerIds],providerChainLabels:e.providerIds.map(e=>t.get(e)??e),hasDefinitionOverride:!1,hasProviderChainOverride:!1,hasOverride:!1,updatedAt:e.updatedAt}}function He(e,t){let n=M[e],r=t.systemOverrides[e];return{label:r?.label??n.label,mode:r?.mode??n.mode,systemPrompt:r?.systemPrompt??n.systemPrompt,userPrompt:r?.userPrompt??n.userPrompt,providerSystemPrompts:n.providerSystemPrompts,providerRequestParams:L(r?.providerRequestParams??n.providerRequestParams)}}function Ue(e,t,n,r,i,a,o){let s=M[e],c={updatedAt:o};return t!==s.label&&(c.label=t),n!==s.mode&&(c.mode=n),r!==s.systemPrompt&&(c.systemPrompt=r),i!==s.userPrompt&&(c.userPrompt=i),Re(a,s.providerRequestParams)||(c.providerRequestParams=L(a)??{}),Object.keys(c).length===1?null:c}function We(e,t){return e.length===t.length?e.every((e,n)=>e===t[n]):!1}function Ge(e,t){let n=g(e.providerIds),r=Pe[e.id];if(n.length===0)throw new I(`Task provider chain must include at least one provider.`);return We(n,r)?null:{mode:`replace`,providerIds:n,updatedAt:t}}function Ke(e,t,n){let r=Pe[e],i=t.tasks[e],a;return a=i?i.mode===`replace`?[...i.providerIds]:i.insertPosition===`head`?[...i.providerIds,...r]:[...r,...i.providerIds]:[...r],g(a).filter(e=>n.has(e))}function B(e){if(!N.includes(e))throw new I(`Unknown task "${e}".`)}function qe(e,t,n){let r=new Map(n.map(e=>[e.id,e])),i=t?.providerIds??Pe[e];for(let t of i)if(!r.has(t))throw new I(`Task "${M[e].label}" references unknown provider "${t}".`);let a=new Set(n.filter(e=>e.status===`active`).map(e=>e.id));if(!Ke(e,{version:1,tasks:t?{[e]:t}:{}},a).some(e=>r.get(e)?.isRuntimeReachable))throw new I(`Task "${M[e].label}" must keep at least one executable provider.`)}function Je(e,t,n){if(e.length===0)throw new I(`Task provider chain must include at least one provider.`);let r=new Map(n.map(e=>[e.id,e]));for(let n of e)if(!r.has(n))throw new I(`Task "${t}" references unknown provider "${n}".`);if(!e.some(e=>r.get(e)?.isRuntimeReachable))throw new I(`Task "${t}" must keep at least one executable provider.`)}function Ye(e,t){let n=Xe(e),r=1,i=Ne(n);for(;t.customTasks[i];)r+=1,i=Ne(`${n}-${r}`);return i}function Xe(e){let t=e.trim().toLowerCase().replace(/[^a-z0-9]+/g,`-`).replace(/^-+|-+$/g,``).slice(0,48);return t.length>=3?t:`task`}function V(e){let t={};for(let n of N){let r=e.systemOverrides[n];r&&(t[n]={...r,providerRequestParams:L(r.providerRequestParams)})}let n={};for(let[t,r]of Object.entries(e.customTasks))r&&(n[t]={...r,providerRequestParams:L(r.providerRequestParams),providerIds:[...r.providerIds]});return{...e,systemOverrides:t,customTasks:n,disabledSystemTaskIds:[...e.disabledSystemTaskIds]}}function Ze(e){let t={};for(let n of N){let r=e.tasks[n];r&&(t[n]={...r,providerIds:[...r.providerIds]})}return{...e,tasks:t}}var Qe=class{providerRegistryReader;constructor(e){this.providerRegistryReader=e}async getTaskRecords(){let[e,t]=await Promise.all([P.getValue(),this.providerRegistryReader.getProviderViews()]),n=new Map(t.map(e=>[e.id,e.label])),r=await Promise.all(N.map(async t=>this.buildTaskRecord(t,e,n))),i=Object.values(e.customTasks).filter(e=>e!=null).sort((e,t)=>t.updatedAt-e.updatedAt).map(e=>Ve(e,n));return[...r,...i]}async getTaskRecord(e){let[t,n]=await Promise.all([P.getValue(),this.providerRegistryReader.getProviderViews()]),r=new Map(n.map(e=>[e.id,e.label]));if(Me(e)){let n=t.customTasks[e];return n?Ve(n,r):null}return N.includes(e)?this.buildTaskRecord(e,t,r):null}async getResolvedTaskDefinition(e){return B(e),He(e,await P.getValue())}async getResolvedTaskProviderIds(e,t){return B(e),Ke(e,await F.getValue(),t?new Set(t):await this.getActiveProviderIdSet())}async getTaskProviderChainRule(e){B(e);let t=(await F.getValue()).tasks[e];return t?{...t,providerIds:[...t.providerIds]}:null}async getProviderReferenceTasks(e){let t=await F.getValue(),n=await P.getValue(),r=[];for(let n of N)t.tasks[n]?.providerIds.includes(e)&&r.push(n);for(let t of Object.values(n.customTasks))t?.providerIds.includes(e)&&r.push(t.id);return r}async assertTasksRetainExecutableProviders(e,t){let n=await F.getValue(),r=await P.getValue(),i=new Set(e),a=new Set(t);for(let e of N)if(!Ke(e,n,i).some(e=>a.has(e)))throw new I(`Task "${M[e].label}" must keep at least one executable provider.`);for(let e of Object.values(r.customTasks))if(e&&!g(e.providerIds).filter(e=>i.has(e)).some(e=>a.has(e)))throw new I(`Task "${e.label}" must keep at least one executable provider.`)}watchTaskRecords(e){let t=!1,n=async()=>{t||e(await this.getTaskRecords())};n();let r=P.watch(()=>{n()}),i=F.watch(()=>{n()}),a=this.providerRegistryReader.watchMergedProviders(()=>{n()});return()=>{t=!0,r(),i(),a()}}async createCustomTask(e){let t=Date.now(),n=V(await P.getValue()),r=await this.normalizeCustomTaskInput(e,n,t);return n.customTasks[r.id]=r,await P.setValue(n),r.id}async updateTask(e){if(Me(e.id)){await this.updateCustomTask(e.id,e);return}await this.updateSystemTask(e)}async updateSystemTask(e){B(e.id);let t=Date.now(),n=V(await P.getValue()),r=Ze(await F.getValue()),i=ze(e.label),a=R(e.mode),o=z(e.systemPrompt,`System Prompt`),s=z(e.userPrompt,`User Prompt`),c=Ie(e.providerRequestParams,e.providerIds),l=Ge(e,t),u=await this.providerRegistryReader.getProviderViews();qe(e.id,l,u),l?r.tasks[e.id]={mode:l.mode,insertPosition:l.mode===`inherit`?l.insertPosition??`tail`:void 0,providerIds:[...l.providerIds],updatedAt:l.updatedAt}:delete r.tasks[e.id];let d=Ue(e.id,i,a,o,s,c,t);d?n.systemOverrides[e.id]=d:delete n.systemOverrides[e.id],await Promise.all([P.setValue(n),F.setValue(r)])}async deleteCustomTask(e){let t=V(await P.getValue());if(!t.customTasks[e])throw new I(`Custom task "${e}" does not exist.`);delete t.customTasks[e],await P.setValue(t)}async resetSystemTask(e){B(e);let t=V(await P.getValue()),n=Ze(await F.getValue());delete n.tasks[e],delete t.systemOverrides[e],await Promise.all([P.setValue(t),F.setValue(n)])}async updateCustomTask(e,t){let n=Date.now(),r=V(await P.getValue()),i=r.customTasks[e];if(!i)throw new I(`Custom task "${e}" does not exist.`);let a=await this.normalizeExistingCustomTaskInput(i,t,n);r.customTasks[e]=a,await P.setValue(r)}async buildTaskRecord(e,t,n){let[r,i]=await Promise.all([this.getTaskProviderChainRule(e),this.getResolvedTaskProviderIds(e)]);return Be(e,t,n,r,i)}async getActiveProviderIdSet(){let e=await this.providerRegistryReader.getProviderViews();return new Set(e.filter(e=>e.status===`active`).map(e=>e.id))}async normalizeCustomTaskInput(e,t,n){let r=ze(e.label),i=R(e.mode),a=z(e.systemPrompt,`System Prompt`),o=z(e.userPrompt,`User Prompt`),s=g(e.providerIds),c=Ie(e.providerRequestParams,s);return Je(s,r,await this.providerRegistryReader.getProviderViews()),{id:Ye(r,t),label:r,mode:i,systemPrompt:a,userPrompt:o,providerRequestParams:c,providerIds:s,createdAt:n,updatedAt:n}}async normalizeExistingCustomTaskInput(e,t,n){let r=ze(t.label),i=R(t.mode),a=z(t.systemPrompt,`System Prompt`),o=z(t.userPrompt,`User Prompt`),s=g(t.providerIds),c=Ie(t.providerRequestParams,s);return Je(s,r,await this.providerRegistryReader.getProviderViews()),{...e,label:r,mode:i,systemPrompt:a,userPrompt:o,providerRequestParams:c,providerIds:s,updatedAt:n}}};function $e(){let e=new Ae,t=new Qe(e);return e.attachTaskProviderReferenceReader(t),{providerRegistryService:e,taskRegistryService:t}}function et(){return je.map(e=>nt(e))}function tt(e){return{id:e.id,label:e.label,kind:e.id===`lexical`?`lexical`:e.mode===`json`?`json`:`markdown`}}function nt(e){let t=u[e];return{id:e,label:t.label,kind:e===`lexical`?`lexical`:t.mode===`json`?`json`:`markdown`}}var rt=class{taskRegistryService=$e().taskRegistryService;async listTasks(){return(await this.taskRegistryService.getTaskRecords()).map(e=>tt(e))}async startTask(e,t,i){await n.runtime.sendMessage({kind:r,requestId:e,task:t,selection:i})}async cancelTask(e){await n.runtime.sendMessage({kind:i,requestId:e})}},H=class{currentValue;subscribers=new Set;constructor(e){this.currentValue=e}get value(){return this.currentValue}set value(e){this.currentValue=e;for(let e of this.subscribers)e(this.currentValue)}subscribe(e){return this.subscribers.add(e),e(this.currentValue),()=>{this.subscribers.delete(e)}}clear(){this.subscribers.clear()}},U={status:`idle`,content:``,reasoning:``},W=et();function it(e){return`${e}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function at(e){let t={};for(let n of e)n.kind!==`lexical`&&(t[n.id]={...U});return t}function ot(e){return e.find(e=>e.kind!==`lexical`)?.id??null}function st(e,t=28){let n=e.replace(/\s+/g,` `).trim();return n.length<=t?n:`${n.slice(0,t-1).trimEnd()}…`}var ct=class{isOpen=new H(!1);title=new H(`查单词，用小猹`);theme=new H(`pro`);selection=new H(null);tasks=new H(W);selectedTab=new H(ot(W));lexicalCollapsed=new H(!1);providerLabel=new H(null);lexicalState=new H({...U});taskStates=new H(at(W));errorMessage=new H(null);repository;requestIds=new Map;requestedTaskIds=new Set;constructor(e){this.repository=e}openSelection(e){this.resetAndStart(e)}close(){this.cancelActiveRequests(),this.isOpen.value=!1,this.selection.value=null}cycleTheme(){let e=a[(a.findIndex(e=>e.id===this.theme.value)+1)%a.length];this.theme.value=e.id}toggleLexicalCollapsed(){this.lexicalCollapsed.value=!this.lexicalCollapsed.value}selectTab(e){this.getTabTasks().some(t=>t.id===e)&&(this.selectedTab.value=e,!this.requestedTaskIds.has(e)&&this.selection.value&&this.startTask(e,s(this.selection.value)))}getLexicalTask(){return this.tasks.value.find(e=>e.kind===`lexical`)??null}getTabTasks(){return this.tasks.value.filter(e=>e.kind!==`lexical`)}getTaskState(e){return e===`lexical`?this.lexicalState.value:this.taskStates.value[e]??{...U}}handleStreamEvent(e){let t=this.requestIds.get(e.task);if(!(!t||t!==e.requestId))switch(e.phase){case`started`:this.providerLabel.value=e.providerLabel,this.setTaskState(e.task,t=>({...t,status:`loading`,providerLabel:e.providerLabel,errorMessage:void 0}));return;case`chunk`:if(e.task===`lexical`)return;this.setTaskState(e.task,t=>({...t,status:`loading`,content:`${t.content}${e.contentDelta??``}`,reasoning:`${t.reasoning}${e.reasoningDelta??``}`}));return;case`completed`:this.providerLabel.value=e.result.providerLabel,this.setTaskState(e.task,()=>({status:`success`,providerLabel:e.result.providerLabel,content:e.result.content,reasoning:e.result.reasoning,lexical:e.result.lexical})),e.task===this.selectedTab.value&&e.result.content.trim()&&(this.lexicalCollapsed.value=!0);return;case`failed`:{let t=e.errorMessage||`The explanation request failed.`;this.errorMessage.value=t,this.setTaskState(e.task,e=>({...e,status:`error`,errorMessage:t}))}}}dispose(){this.isOpen.clear(),this.title.clear(),this.theme.clear(),this.selection.clear(),this.tasks.clear(),this.selectedTab.clear(),this.lexicalCollapsed.clear(),this.providerLabel.clear(),this.lexicalState.clear(),this.taskStates.clear(),this.errorMessage.clear()}async resetAndStart(e){await this.cancelActiveRequests();let t=await this.loadTasks(),n=ot(t),r=t.find(e=>e.kind===`lexical`)??null;this.selection.value=e,this.tasks.value=t,this.title.value=st(e.text),this.selectedTab.value=n,this.providerLabel.value=null,this.errorMessage.value=null,this.lexicalCollapsed.value=!1,this.lexicalState.value={...U},this.taskStates.value=at(t),this.requestedTaskIds.clear(),this.isOpen.value=!0;let i=s(e),a=[];r&&a.push(this.startTask(r.id,i)),n&&a.push(this.startTask(n,i)),await Promise.all(a)}async startTask(e,t){let n=it(e);this.requestIds.set(e,n),this.requestedTaskIds.add(e),this.setTaskState(e,()=>({...U,status:`loading`})),await this.repository.startTask(n,e,t)}async cancelActiveRequests(){let e=[...this.requestIds.values()];this.requestIds.clear(),await Promise.allSettled(e.map(e=>this.repository.cancelTask(e)))}async loadTasks(){try{let e=await this.repository.listTasks(),t=new Set;return e.filter(e=>t.has(e.id)?!1:(t.add(e.id),!0))}catch{return W}}setTaskState(e,t){if(e===`lexical`){this.lexicalState.value=t(this.lexicalState.value);return}let n=this.taskStates.value,r=n[e]??{...U};this.taskStates.value={...n,[e]:t(r)}}},lt=`/* ===================================================================
 * 小猹 — Shadow DOM Adapter Preamble
 * Adapts original Origin-of-Words CSS for Shadow DOM context.
 * =================================================================== */
:host {
  all: initial;
  display: block;
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  pointer-events: none;
  font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, "Apple Color Emoji", "Segoe UI Emoji";
}

.oow-selection-trigger-button {
  pointer-events: auto;
}

.oow-popover {
  pointer-events: auto;
}

/* ===================================================================
 * Original: Origin of Words - CSS Variables API
 * =================================================================== */

:host {
  /* 选择触发器 (Trigger) */
  --oow-trigger-size: 10px;
  --oow-trigger-bg: #5C9E31;
  --oow-trigger-border: #ffffff;
  --oow-trigger-hover-bg: #4A7C28;
  --oow-trigger-active-border: #EA4C89;
  --oow-trigger-shadow: 0 2px 6px rgba(0,0,0,0.15);
}

.oow-popover {
  /* 
   * --------------------------------
   * 1. 核心色板 (Core Palette)
   * --------------------------------
   * 定义主题的基础颜色.
   */
  --oow-bg: #ffffff;              /* 主背景色 */
  --oow-text: #111111;            /* 主文字颜色 */
  --oow-muted: #666666;           /* 辅助/静音文字颜色 */
  --oow-border: rgba(0,0,0,0.1);  /* 边框颜色 */

  /* 
   * --------------------------------
   * 2. 强调色 (Accent Colors)
   * --------------------------------
   * 用于按钮、链接、高亮等需要强调的地方.
   */
  --oow-accent-primary: #0ea5e9;    /* 主强调色 (如链接、图标) */
  --oow-accent-secondary: #22c55e;  /* 次强调色 (如高亮背景) */
  --oow-accent-tertiary: #fb923c;   /* 第三强调色 (如图标渐变) */

  /* 
   * --------------------------------
   * 3. 功能色 (Functional Colors)
   * --------------------------------
   * 用于表示状态: 成功、警告、错误.
   */
  --oow-success: #22c55e;
  --oow-warning: #f59e0b;
  --oow-error: #ef4444;
  --oow-info: #3b82f6;

  /* 
   * --------------------------------
   * 4. 字体系统 (Typography)
   * --------------------------------
   * 控制所有文本的字体和大小.
   */
  --font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, "Apple Color Emoji", "Segoe UI Emoji";
  --font-size-xs: 10px;
  --font-size-sm: 11px;
  --font-size-base: 12px;
  --font-size-lg: 13px;
  --font-size-xl: 14px;

  /* 
   * --------------------------------
   * 5. 几何与效果 (Geometry & Effects)
   * --------------------------------
   * 控制圆角、阴影等视觉效果.
   */
  --radius-sm: 2px;
  --radius-base: 3px;
  --radius-md: 4px;
  --radius-lg: 6px;
  --radius-xl: 8px;
  --radius-full: 50%;
  --shadow-base: 0 1px 3px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.06);
  --shadow-lg: 0 10px 15px rgba(0,0,0,0.1), 0 4px 6px rgba(0,0,0,0.05);
  --z-max: 2147483647; /* Max z-index to ensure it's on top of everything */

  /* 
   * --------------------------------
   * 6. 组件特定变量 (Component Variables)
   * --------------------------------
   * 为特定UI组件提供微调.
   */
  
  /* 模态框 (Modal) */
  --oow-modal-width: 450px;
  --oow-modal-max-height: 500px;
  --oow-modal-border-radius: 14px;
  --oow-modal-shadow: 0 10px 30px rgba(0,0,0,0.45), 0 1px 0 rgba(255,255,255,0.06) inset;

  /* 按钮 (Button) */
  --oow-btn-padding: 2px 4px;
  --oow-btn-border-radius: var(--radius-md);
  --oow-btn-font-size: var(--font-size-base);

  /* 代码 (Code) */
  --oow-code-bg: rgba(0,0,0,0.05);
  --oow-code-color: #d6336c;
  --oow-code-border-radius: var(--radius-base);
  --oow-code-padding: 2px 4px;

  /* 滚动条 (Scrollbar) */
  --oow-scrollbar-width: 6px;
  --oow-scrollbar-track-bg: transparent;
  --oow-scrollbar-thumb-bg: var(--oow-accent-primary);
  --oow-scrollbar-thumb-radius: var(--radius-sm);

  /* 加载动画 (Loader) */
  --oow-loader-size: 6px;

  
  
  /*
   * --------------------------------
   * 7. 高级主题变量 (Advanced Theme Variables)
   * --------------------------------
   * 用于创建高级主题效果的额外变量.
   * 这些变量在默认主题中不使用，专为高级主题创作而设计.
   */

  /* 渐变效果 (Gradient Effects) */
  --oow-gradient-primary: linear-gradient(90deg, var(--oow-accent-primary), var(--oow-accent-secondary));
  --oow-gradient-secondary: linear-gradient(135deg, var(--oow-accent-tertiary), var(--oow-accent-primary));
  --oow-gradient-rainbow: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #9400d3);

  /* 高级阴影 (Advanced Shadows) */
  --oow-glow-shadow-primary: 0 0 20px rgba(14, 165, 233, 0.4);
  --oow-glow-shadow-secondary: 0 0 20px rgba(34, 197, 94, 0.4);
  --oow-neon-shadow: 0 0 10px currentColor, 0 0 20px currentColor, 0 0 30px currentColor;
  --oow-inset-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.3);

  /* 混合模式 (Blend Modes) */
  --oow-blend-mode: normal;
  --oow-bg-blend-mode: normal;

  /* 滤镜效果 (Filter Effects) */
  --oow-filter-hue-rotate: 0deg;
  --oow-filter-saturate: 100%;
  --oow-filter-brightness: 100%;
  --oow-filter-contrast: 100%;

  /* 材质设计阴影层级 (Material Design Shadow Elevations) */
  --oow-shadow-elevation-1: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
  --oow-shadow-elevation-2: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
  --oow-shadow-elevation-3: 0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23);
  --oow-shadow-elevation-4: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);

  /* 动画时间 (Animation Timing) */
  --oow-animation-fast: 0.15s;
  --oow-animation-base: 0.25s;
  --oow-animation-slow: 0.4s;
  --oow-animation-slower: 0.6s;

  /* 特殊效果 (Special Effects) */
  --oow-pattern-dots: radial-gradient(circle, var(--oow-border) 1px, transparent 1px);
  --oow-pattern-grid: linear-gradient(var(--oow-border) 1px, transparent 1px), linear-gradient(90deg, var(--oow-border) 1px, transparent 1px);
  --oow-texture-noise: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");

  /*
   * --------------------------------
   * 8. 高亮系统 (Highlight System)
   * --------------------------------
   * 控制由Markdown生成的 <strong>, <em>, <code> 等标签的样式
   * 这是主题中最能体现创意和价值的部分
   */

  /* Strong / Bold - **text** or __text__ */
  --oow-highlight-strong-color: var(--oow-accent-secondary);
  --oow-highlight-strong-font-weight: 800;
  --oow-highlight-strong-text-shadow: 0 0 8px color-mix(in srgb, var(--oow-accent-secondary) 30%, transparent);

  /* Emphasis / Italic - *text* or _text_ */
  --oow-highlight-em-color: var(--oow-accent-primary);
  --oow-highlight-em-font-style: italic;

  /* Inline Code - \`code\` */
  --oow-highlight-code-color: var(--oow-code-color);
  --oow-highlight-code-bg: var(--oow-code-bg);
  --oow-highlight-code-border-color: var(--oow-border);
  --oow-highlight-code-font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  --oow-highlight-code-font-size: 0.9em;

  /* Links - [text](url) */
  --oow-highlight-link-color: var(--oow-accent-primary);
  --oow-highlight-link-decoration: underline;
  --oow-highlight-link-decoration-thickness: 1px;
  --oow-highlight-link-decoration-offset: 3px;
  --oow-highlight-link-hover-color: var(--oow-text);
  --oow-highlight-link-hover-bg: color-mix(in srgb, var(--oow-accent-primary) 10%, transparent);
  --oow-highlight-link-hover-transform: translateY(-1px);

  /* List Markers - bullet points and numbers */
  --oow-highlight-marker-color: var(--oow-accent-secondary);
  --oow-highlight-marker-font-weight: bold;

  /* Advanced highlight effects */
  --oow-highlight-strong-glow: 0 0 20px var(--oow-accent-secondary);
  --oow-highlight-em-glow: 0 0 15px var(--oow-accent-primary);
  --oow-highlight-code-glow: 0 0 10px var(--oow-accent-tertiary);

  /* Animation and transitions */
  --oow-highlight-transition: all var(--oow-animation-base, 0.2s) ease;
  --oow-highlight-hover-scale: 1.02;
}
/*
 * Origin of Words - Core Layout System
 * 核心布局系统 - 100% 原始布局，不依赖主题
 * CRITICAL: Must match original style.css exactly for all themes to work
 */

/* === Base Popover Structure - Original === */
.oow-popover {
  position: fixed;
  width: 450px;
  min-height: 32px;
  max-height: 500px;
  color: var(--text-color);
  border: 1px solid var(--ring);
  border-radius: 14px;
  padding: 12px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.45), 0 1px 0 rgba(255,255,255,0.06) inset;
  font: 13px/1.5 var(--font-family);
  z-index: 2147483647;
  overflow: hidden;
  inset: auto;
  display: flex;
  flex-direction: column;
  background:
    linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0) 10%),
    var(--panel-bg);
  backdrop-filter: blur(10px) saturate(120%);
}

.oow-popover:not(:popover-open) {
  display: none;
}

/* === Fake Selection - Original === */
.oow-fake-selection {
  position: absolute;
  background: rgba(0, 123, 255, 0.3);
  border-radius: 2px;
  pointer-events: none;
  z-index: 2147483646;
  display: none;
}

/* === Modal Header - Original === */
.modal-header {
  flex: none;
  padding: 12px;
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  align-items: center;
  gap: 8px;
  border-bottom: 1px solid var(--ring);
  cursor: grab;
}

.modal-header.is-dragging {
  cursor: grabbing;
  user-select: none;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.header-center {
  display: flex;
  align-items: center;
  justify-content: center;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 8px;
  justify-content: flex-end;
  padding: 0 8px 0 8px;
  padding-right: 12px; /* Reserve space for scrollbar to prevent content from touching it */
}

/* === Header Elements - Original === */
.header-logo {
  inline-size: 34px;
  block-size: 24px;
  display: inline-grid;
  place-items: center;
  font-weight: 800;
  letter-spacing: 0.5px;
  border-radius: 6px;
  color: #0b0b0b;
  background: linear-gradient(135deg, var(--accent-3), var(--accent-2));
  box-shadow: 0 1px 0 rgba(255,255,255,0.4) inset, 0 4px 12px rgba(0,0,0,0.3);
}

.header-title {
  font-weight: 800;
  font-size: 14px;
  letter-spacing: 0.2px;
  background: linear-gradient(90deg, var(--accent-1), var(--accent-2));
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  text-shadow: 0 0 20px rgba(110,231,255,0.2);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.action-btn {
  border: none;
  background: none;
  cursor: pointer;
  font-size: 16px;
  color: var(--muted);
}

/* === Content Body - Original === */
.content-body {
  flex: 1 1 auto;
  overflow-y: auto;
  max-height: calc(500px - 70px);
  /* Add scrollbar styling to ensure consistent appearance and spacing */
  scrollbar-width: thin;
  scrollbar-color: var(--accent-1) transparent;
}

/* Custom scrollbar styling for webkit browsers */
.content-body::-webkit-scrollbar {
  width: 8px;
}

.content-body::-webkit-scrollbar-track {
  background: transparent;
}

.content-body::-webkit-scrollbar-thumb {
  background-color: var(--accent-1);
  border-radius: 4px;
  border: 1px solid transparent;
  background-clip: content-box;
}

.content-body::-webkit-scrollbar-thumb:hover {
  background-color: var(--accent-2);
}

/* 确保每个部分内容可以滚动 */
.section-content {
  overflow: visible;
  max-height: none;
  display: flex;
  flex-direction: column;
}

.text {
  max-height: none;
  overflow: visible;
  word-break: break-word;
  white-space: normal;
}

.section {
  flex: none;
}

/* Add top margin for the first section (lexical-section) to create visual separation */
.lexical-section {
  margin-top: 8px;
}

/* Add top margin for the details section (etymology panel) to create visual separation */
.details-section {
  margin-top: 8px;
}

.section:last-child {
  border-bottom: none;
}

.section-header {
  padding: var(--spacing-2) var(--spacing-4) var(--spacing-2) var(--spacing-4);
  display: flex;
  align-items: center;
  justify-content: space-between; /* This will push left and right content to the edges */
  gap: var(--spacing-2);
}

.part2-section .section-header {
  padding-top: 0;
  padding-bottom: var(--spacing-1);
}

.header-left-content {
  display: flex;
  align-items: center;
  gap: var(--spacing-2);
}

.header-right-content {
  display: flex;
  align-items: center;
  gap: var(--spacing-2);
  margin-left: auto; /* This pushes the button to the far right */
  padding-right: 12px; /* Reserve space for scrollbar to prevent content from touching it */
}

.header-right-content:empty {
  display: none;
}

/* === Section Toggle Button - Original === */
.section-toggle-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--accent-1);
  transition: transform 0.2s ease-in-out, background-color 0.2s, color 0.2s;
}

.section-toggle-btn:hover {
  background-color: var(--accent-1);
  color: var(--pro-bg);
  transform: scale(1.1);
}

.section-toggle-btn svg {
  transition: transform 0.2s ease-in-out;
}

.section.is-collapsed .section-toggle-btn svg,
.collapsible-section.is-collapsed .section-toggle-btn svg {
  transform: rotate(-90deg);
}

/* === Attention Pulse Animation - Original === */
.section-toggle-btn.attention-pulse {
  position: relative;
  z-index: 0;
}

.section-toggle-btn.attention-pulse::after {
  content: '';
  position: absolute;
  inset: -6px;
  border-radius: 50%;
  pointer-events: none;
  z-index: -1;
  border: 2px solid var(--accent-1);
  box-shadow: 0 0 0 0 color-mix(in srgb, var(--accent-1) 60%, transparent);
  animation: oow-pulse-ring 1s ease-out infinite;
}

@keyframes oow-pulse-ring {
  0% {
    transform: scale(1);
    opacity: 0.9;
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--accent-1) 60%, transparent);
  }
  70% {
    transform: scale(1.25);
    opacity: 0;
    box-shadow: 0 0 0 10px color-mix(in srgb, var(--accent-1) 0%, transparent);
  }
  100% {
    transform: scale(1.25);
    opacity: 0;
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--accent-1) 0%, transparent);
  }
}
`,ut=`
/* === Section Title & Controls - Original === */
.section-title {
  font-weight: 700;
  font-size: 1.2em;
  color: var(--text-color);
  text-shadow: 0 1px 0 rgba(0,0,0,0.4);
}

.section-phonetic {
  color: #555;
  font-size: 1.2em;
}

.speaker-btn {
  background: none;
  border: none;
  cursor: pointer;
  font-size: 16px;
  padding: 0;
}

/* === Section Content Collapse - Original === */
.section-content {
  padding: var(--spacing-3) var(--spacing-4);
  transition: opacity var(--oow-animation-base, 0.25s) ease-out;
  overflow: visible; /* FIX: Allow content to overflow so parent can scroll it */
  opacity: 1;
  /* Ensure content doesn't touch scrollbar */
  box-sizing: border-box;
  max-width: 100%;
}

.section.is-collapsed .section-content,
.collapsible-section.is-collapsed .section-content {
  max-height: 0;
  padding-top: 0;
  padding-bottom: 0;
  opacity: 0;
  pointer-events: none; /* Prevent transparent content from blocking clicks to header buttons */
}

/* === Modal Footer - Original === */
.modal-footer {
  flex: none;
  padding: 8px 12px;
  border-top: 1px solid var(--border-color);
  margin-top: auto;
}

.footer-actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
}

.footer-btn {
  padding: 4px 8px;
  border: 1px solid rgba(0,0,0,0.2);
  border-radius: 4px;
  background: #fff;
  cursor: pointer;
  font-size: 12px;
}


/* === PART-1 Content - Original === */
.part1-content {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.defs-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: grid;
  gap: 12px;
}

.def-item {
  line-height: 1.5;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

/* POS and Meaning container - horizontal layout */
.pos-meaning {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: nowrap;
}

.def-item .pos {
  font-weight: 600;
  color: #005a9e;
  margin-right: 8px;
  white-space: nowrap;
}

.def-item .meaning {
  color: #333;
}

.def-item .example {
  color: #555;
  margin-top: 0;
  padding-left: 12px;
  border-left: 2px solid rgba(0,0,0,0.1);
  font-style: italic;
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: nowrap;
}

/* === Highlight Style - Original === */
.highlight {
  background-color: var(--accent-2);
  color: var(--panel-bg);
  border-radius: 3px;
  padding: 0px 3px;
}


/* === Part1 Context with Scrolling - Original === */
.part1-context {
  background: linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02));
  padding: 14px 14px 14px 14px; /* Remove right padding to make text touch border */
  border-radius: 10px;
  border: 1px solid var(--ring);
  min-height: 32px;
  margin-bottom: 10px;
  margin-right: 8px; /* Additional margin to ensure no content touches scrollbar */
  max-height: 320px;
  overflow-y: auto;
  overflow-x: hidden;
  scrollbar-width: thin;
  scrollbar-color: var(--accent-1) transparent;
  box-sizing: border-box; /* Ensure padding is included in width calculation */
}

.part1-content {
  word-break: break-word;
}

.part1-context::-webkit-scrollbar {
  width: 6px;
}

.part1-context::-webkit-scrollbar-track {
  background: transparent;
}

.part1-context::-webkit-scrollbar-thumb {
  background-color: var(--accent-1);
  border-radius: 3px;
}

.part1-context:has(.context-loader.visible),
.part1-context:has(.translation .text:not(:empty)),
.part1-context:has(.contextual-analysis .text:not(:empty)) {
  min-height: 32px;
}

.part1-context .text {
  white-space: pre-wrap;
}

.translation {
  margin-bottom: 8px;
}

.text-translation {
  display: inline-block; /* Fix multi-line display issue */
  font-weight: 800;
  font-size: 1.2em;
  letter-spacing: 0.2px;
  color: var(--text-color);
  word-break: break-word;
  white-space: normal;
}

.text-contextual_analysis {
  display: inline-block; /* Fix multi-line display issue */
  color: var(--muted);
  word-break: break-word;
  white-space: normal;
  overflow: visible;
}


/* === Equalizer Loader - Original === */
.part1-content .part1-context {
  position: relative;
}

.part1-content .context-loader {
  display: none;
  padding: 8px 0 6px 0;
}

.part1-content .context-loader.visible {
  display: block;
}

.eq {
  display: grid;
  grid-auto-flow: column;
  gap: 6px;
  justify-content: center;
  align-items: end;
  height: 26px;
}

.eq .bar {
  width: 6px;
  border-radius: 6px;
  background: linear-gradient(180deg, var(--accent-1), var(--accent-2));
  box-shadow: 0 2px 10px rgba(176,114,255,0.5);
  animation: oow-eq 0.9s ease-in-out infinite;
}

.eq .b1 { animation-delay: 0s; }
.eq .b2 { animation-delay: 0.1s; }
.eq .b3 { animation-delay: 0.2s; }
.eq .b4 { animation-delay: 0.3s; }
.eq .b5 { animation-delay: 0.4s; }

@keyframes oow-eq {
  0%, 100% {
    height: 6px;
    filter: saturate(120%);
  }
  40% {
    height: 22px;
    filter: saturate(160%);
  }
  60% {
    height: 12px;
  }
}

/* === Part2 Section Overflow Fix - Original === */
.part2-section .section-content {
  overflow: visible !important;
  max-height: none !important;
}

.info-panel-content {
  overflow: visible !important;
  word-break: break-word !important;
}
/*
 * Origin of Words - Selection Trigger Component Styles
 * 选择触发按钮组件样式
 */

.oow-selection-trigger-button {
  box-sizing: border-box; /* 让边框在width/height之内，确保总尺寸精确 */
  cursor: pointer;
  position: absolute;
  width: var(--oow-trigger-size, 10px);
  height: var(--oow-trigger-size, 10px);
  border-radius: var(--radius-full, 50%);
  border: 1px solid var(--oow-trigger-border, #ffffff);
  background: var(--oow-trigger-bg, #5c9e31);
  box-shadow: var(--oow-trigger-shadow, 0 2px 6px rgba(0, 0, 0, 0.15));
  transition: transform var(--oow-animation-fast, 0.15s) cubic-bezier(0.25, 0.1, 0.25, 1);
  z-index: var(--z-max, 2147483647);
  display: none;

  /* 位置偏移变量 */
  --oow-trigger-offset-x: 2px;
  --oow-trigger-offset-y: -12px;
}

.oow-selection-trigger-button:hover {
  transform: scale(1.2);
}

.oow-selection-trigger-button.activated {
  width: 12px;
  height: 12px;
  background: var(--oow-trigger-hover-bg, #4a7c28);
  transform: scale(1);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2), 0 0 0 1px var(--oow-trigger-active-border, #ea4c89);
}

/* 显示/隐藏状态控制 */
.oow-selection-trigger-button.visible {
  display: block;
}

.oow-selection-trigger-button.hidden {
  display: none;
}/* ModalView 组件样式 - 设计师友好的变量系统 */

/* 主弹窗容器变量 */
.oow-popover {
  /* 整体布局样式 */
  --oow-modal-bg: #ffffff;
  --oow-modal-color: #333333;
  --oow-modal-width: 360px;
  --oow-modal-max-width: 90vw;
  --oow-modal-max-height: 70vh;
  --oow-modal-border-radius: 16px;
  --oow-modal-border: 1px solid rgba(0, 0, 0, 0.1);
  --oow-modal-z-index: 2147483647;

  /* 定位和间距 */
  --oow-modal-gap-y: 8px;
  --oow-modal-margin: 4px;
  --oow-modal-padding: 0;

  /* 显示状态 */
  --oow-modal-opacity-show: 1;
  --oow-modal-opacity-hide: 0;
  --oow-modal-transform-show: translateY(0) scale(1);
  --oow-modal-transform-hide: translateY(-10px) scale(0.95);

  /* 拖拽状态样式 */
  --oow-modal-drag-opacity: 0.9;
  --oow-modal-drag-cursor: move;

  /* 位置控制变量 */
  --oow-modal-drag-left: var(--oow-modal-left, auto);
  --oow-modal-drag-top: var(--oow-modal-top, auto);
}

/* 内容体样式 */
.content-body {
  /* 布局样式 */
  --oow-content-body-padding: 16px;
  --oow-content-body-bg: transparent;
  --oow-content-body-color: inherit;
  --oow-content-body-gap: 12px;
  --oow-content-body-display: flex;
  --oow-content-body-flex-direction: column;

  /* 滚动样式 */
  --oow-content-body-overflow-y: auto;
  --oow-content-body-overflow-x: hidden;
  --oow-content-body-scrollbar-width: thin;
  --oow-content-body-scrollbar-color: var(--oow-muted) transparent;
}

/* 伪选择元素样式 */
.oow-fake-selection {
  /* 背景和边框 */
  --oow-fake-selection-bg: rgba(59, 130, 246, 0.2);
  --oow-fake-selection-border: 2px solid rgba(59, 130, 246, 0.6);
  --oow-fake-selection-border-radius: 4px;

  /* 定位 */
  --oow-fake-selection-position: absolute;
  --oow-fake-selection-z-index: 999999;
  --oow-fake-selection-pointer-events: none;

  /* 尺寸控制 */
  --oow-fake-selection-top: auto;
  --oow-fake-selection-left: auto;
  --oow-fake-selection-width: auto;
  --oow-fake-selection-height: auto;
  --oow-element-display: none;

  /* 动画 */
  --oow-fake-selection-animation: oow-fake-selection-pulse 2s infinite;
}


/* 响应式设计 */
@media (max-width: 480px) {
  .oow-popover {
    --oow-modal-width: 95vw;
    --oow-modal-max-height: 80vh;
    --oow-modal-border-radius: 12px;
    --oow-modal-margin: 2px;
  }

  .content-body {
    --oow-content-body-padding: 12px;
    --oow-content-body-gap: 8px;
  }

}

@media (max-width: 360px) {
  .oow-popover {
    --oow-modal-width: 98vw;
    --oow-modal-border-radius: 8px;
  }

  .content-body {
    --oow-content-body-padding: 8px;
  }
}

/* 暗色主题适配 */
@media (prefers-color-scheme: dark) {
  .oow-popover {
    --oow-modal-bg: #1f2937;
    --oow-modal-color: #f3f4f6;
    --oow-modal-border: 1px solid rgba(255, 255, 255, 0.1);
  }

}

/* 高对比度主题 */
@media (prefers-contrast: high) {
  .oow-popover {
    --oow-modal-border: 2px solid #000000;
  }

  .oow-fake-selection {
    --oow-fake-selection-border: 3px solid #000000;
  }
}

/* 减少动画偏好 */
@media (prefers-reduced-motion: reduce) {
  .oow-popover {
  }

  .oow-fake-selection {
    --oow-fake-selection-animation: none;
  }
}

/* 应用变量样式 */
.oow-popover {
  background: var(--oow-modal-bg);
  color: var(--oow-modal-color);
  width: var(--oow-modal-width);
  max-width: var(--oow-modal-max-width);
  max-height: var(--oow-modal-max-height);
  border-radius: var(--oow-modal-border-radius);
  border: var(--oow-modal-border);
  z-index: var(--oow-modal-z-index);
  padding: var(--oow-modal-padding);
  position: fixed;
}

/* 定位状态 */
.is-positioned {
  top: var(--oow-modal-top, auto) !important;
  left: var(--oow-modal-left, auto) !important;
}

.is-dragging-position {
  top: var(--oow-modal-drag-left, var(--oow-modal-drag-left-fallback, auto)) !important;
  left: var(--oow-modal-drag-top, var(--oow-modal-drag-top-fallback, auto)) !important;
}

.content-body {
  padding: var(--oow-content-body-padding);
  background: var(--oow-content-body-bg);
  color: var(--oow-content-body-color);
  gap: var(--oow-content-body-gap);
  display: var(--oow-content-body-display);
  flex-direction: var(--oow-content-body-flex-direction);
  overflow-y: var(--oow-content-body-overflow-y);
  overflow-x: var(--oow-content-body-overflow-x);
  scrollbar-width: var(--oow-content-body-scrollbar-width);
  scrollbar-color: var(--oow-content-body-scrollbar-color);
}

.oow-fake-selection {
  background: var(--oow-fake-selection-bg);
  border: var(--oow-fake-selection-border);
  border-radius: var(--oow-fake-selection-border-radius);
  position: var(--oow-fake-selection-position);
  z-index: var(--oow-fake-selection-z-index);
  pointer-events: var(--oow-fake-selection-pointer-events);
  animation: var(--oow-fake-selection-animation);
  top: var(--oow-fake-selection-top);
  left: var(--oow-fake-selection-left);
  width: var(--oow-fake-selection-width);
  height: var(--oow-fake-selection-height);
  display: var(--oow-element-display);
}

/* 伪选择元素显示状态 */
.oow-fake-selection.is-visible {
  display: block !important;
}

.oow-fake-selection.is-hidden {
  display: none !important;
}


/* 显示控制类 */
.display-block {
  display: block !important;
}

`,dt=`.display-block-flex {
  display: flex !important;
}

.display-none {
  display: none !important;
}

/* 拖拽状态样式 */
.is-dragging {
  opacity: var(--oow-modal-drag-opacity) !important;
  cursor: var(--oow-modal-drag-cursor) !important;
}

.is-dragging-position {
  left: var(--oow-modal-drag-left) !important;
  top: var(--oow-modal-drag-top) !important;
}


/* 动画定义 */
@keyframes oow-fake-selection-pulse {
  0%, 100% {
    opacity: 0.6;
  }
  50% {
    opacity: 1;
  }
}/* ModalHeader 组件样式 - 设计师友好的变量系统 */

/* Modal Header 组件专用变量 - 设计师主题创作接口 */
.modal-header {
  /* 头部整体样式 */
  --oow-header-height: 48px;
  --oow-header-padding: 12px;
  --oow-header-border-radius: 14px 14px 0 0;
  --oow-header-bg: transparent;
  --oow-header-border: 1px solid var(--ring);
  --oow-header-display: flex;
  --oow-header-align-items: center;
  --oow-header-justify-content: space-between;
}

/* 头部左侧容器 */
.header-left {
  --oow-header-left-display: flex;
  --oow-header-left-align-items: center;
  --oow-header-left-gap: 12px;
}

/* 头部中央容器 */
.header-center {
  --oow-header-center-flex: 1;
  --oow-header-center-display: flex;
  --oow-header-center-justify-content: center;
  --oow-header-center-padding: 0 16px;
}

/* 头部右侧容器 */
.header-right {
  --oow-header-right-display: flex;
  --oow-header-right-align-items: center;
  --oow-header-right-gap: 8px;
}

/* Logo 样式 */
.header-logo {
  /* Logo 尺寸和布局 */
  --oow-header-logo-size: 34px;
  --oow-header-logo-block-size: 24px;
  --oow-header-logo-display: inline-grid;
  --oow-header-logo-place-items: center;

  /* Logo 样式 */
  --oow-header-logo-weight: 800;
  --oow-header-logo-letter-spacing: 0.5px;
  --oow-header-logo-border-radius: var(--radius-lg);
  --oow-header-logo-bg: linear-gradient(135deg, var(--accent-3), var(--accent-2));
  --oow-header-logo-color: #0b0b0b;
  --oow-header-logo-shadow: 0 1px 0 rgba(255,255,255,0.4) inset, 0 4px 12px rgba(0,0,0,0.3);

  /* 应用变量 */
  inline-size: var(--oow-header-logo-size);
  block-size: var(--oow-header-logo-block-size);
  display: var(--oow-header-logo-display);
  place-items: var(--oow-header-logo-place-items);
  font-weight: var(--oow-header-logo-weight);
  letter-spacing: var(--oow-header-logo-letter-spacing);
  border-radius: var(--oow-header-logo-border-radius);
  box-shadow: var(--oow-header-logo-shadow);
  background: var(--oow-header-logo-bg);
  color: var(--oow-header-logo-color);
}

/* 头部标题样式 */
.header-title {
  /* 标题样式 */
  --oow-header-title-weight: 800;
  --oow-header-title-size: var(--font-size-xl);
  --oow-header-title-letter-spacing: 0.2px;
  --oow-header-title-gradient: linear-gradient(90deg, var(--accent-1), var(--accent-2));
  --oow-header-title-text-shadow: 0 0 20px rgba(110,231,255,0.2);

  /* 应用样式 */
  font-weight: var(--oow-header-title-weight);
  font-size: var(--oow-header-title-size);
  letter-spacing: var(--oow-header-title-letter-spacing);

  /* 渐变效果（可选） */
  background: var(--oow-header-title-gradient);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  text-shadow: var(--oow-header-title-text-shadow);

  /* --- Ellipsis for long text --- */
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* 操作按钮样式 (统一标准) */
.action-btn {
  /* 统一尺寸和外观 */
  --oow-header-action-size: 28px;
  --oow-header-action-radius: 6px;

  /* 颜色 (从主题变量继承) */
  --oow-header-action-bg: var(--oow-button-bg, transparent);
  --oow-header-action-hover-bg: var(--oow-button-hover-bg, rgba(0,0,0,0.05));
  --oow-header-action-color: var(--oow-button-color, #333);
  --oow-header-action-hover-color: var(--oow-button-hover-color, #000);

  /* 交互 */
  --oow-header-action-transition: background-color 0.2s ease;
  --oow-header-action-cursor: pointer;

  /* 应用样式 */
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: var(--oow-header-action-size);
  height: var(--oow-header-action-size);
  padding: 0;
  border: none;
  border-radius: var(--oow-header-action-radius);
  background-color: var(--oow-header-action-bg);
  color: var(--oow-header-action-color);
  cursor: var(--oow-header-action-cursor);
  transition: var(--oow-header-action-transition);
}

.action-btn:hover {
  background-color: var(--oow-header-action-hover-bg);
  color: var(--oow-header-action-hover-color);
}

.action-btn:focus-visible {
  outline: 2px solid var(--oow-header-action-hover-color);
  outline-offset: 1px;
}

/* 应用布局样式 */
.modal-header {
  height: var(--oow-header-height);
  padding: var(--oow-header-padding);
  border-radius: var(--oow-header-border-radius);
  background: var(--oow-header-bg);
  border: var(--oow-header-border);
  display: var(--oow-header-display);
  align-items: var(--oow-header-align-items);
  justify-content: var(--oow-header-justify-content);
}

.header-left {
  display: var(--oow-header-left-display);
  align-items: var(--oow-header-left-align-items);
  gap: var(--oow-header-left-gap);
}

.header-center {
  flex: var(--oow-header-center-flex);
  display: var(--oow-header-center-display);
  justify-content: var(--oow-header-center-justify-content);
  padding: var(--oow-header-center-padding);
  min-width: 0; /* Fix for flexbox overflow */
}

.header-right {
  display: var(--oow-header-right-display);
  align-items: var(--oow-header-right-align-items);
  gap: var(--oow-header-right-gap);
}



/* 响应式设计 */
@media (max-width: 480px) {
  .modal-header {
    --oow-header-height: 44px;
    --oow-header-padding: 8px 12px;
    --oow-header-logo-size: 30px;
    --oow-header-logo-block-size: 20px;
    --oow-header-title-size: var(--font-size-lg);
  }

  .header-center {
    --oow-header-center-padding: 0 12px;
  }
}

/* 暗色主题适配 */
@media (prefers-color-scheme: dark) {
  .header-logo {
    --oow-header-logo-color: #ffffff;
    --oow-header-logo-shadow: 0 1px 0 rgba(255,255,255,0.2) inset, 0 4px 12px rgba(0,0,0,0.5);
  }

  .action-btn:hover {
    background: rgba(255, 255, 255, 0.1);
  }
}

/* 高对比度主题 */
@media (prefers-contrast: high) {
  .action-btn {
    --oow-header-action-border: 1px solid currentColor;
  }

  .action-btn:focus-visible {
    outline-width: 3px;
  }
}

/* 减少动画偏好 */
@media (prefers-reduced-motion: reduce) {
  .action-btn {
    --oow-header-action-transition: none;
  }
}/*
 * Origin of Words - Modal Content Styles
 * 模态框内容样式 - 专门用于内容区域的样式
 */

/* PART-1 内容样式 - 词汇分析内容 */
.part1-content {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-3);
  word-break: break-word;
}

.defs-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: grid;
  gap: var(--spacing-3);
}

.def-item {
  line-height: 1.5;
}

.def-item .pos {
  font-weight: 600;
  margin-right: var(--spacing-2);
}

.def-item .meaning {
  color: var(--oow-panel-text);
}

.def-item .example {
  margin-top: var(--spacing-1);
  padding-left: var(--spacing-3);
  border-left: 2px solid var(--oow-panel-border);
  font-style: italic;
}

/* 上下文容器样式 */
.lexical-context-box {
  background: var(--oow-context-bg, rgba(0, 0, 0, 0.03));
  border: 1px solid var(--oow-context-border, rgba(0, 0, 0, 0.08));
  border-radius: var(--radius-lg, 6px);
  padding: var(--spacing-3, 8px) var(--spacing-3, 8px) var(--spacing-3, 8px) var(--spacing-3, 8px);
  margin: var(--spacing-3, 8px) 0;
  margin-right: 8px;
  max-height: 280px;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  position: relative;
  box-sizing: border-box;
}

/* 美化滚动条 */
.lexical-context-box::-webkit-scrollbar {
  width: var(--oow-scrollbar-width, 6px);
  height: 0 !important;
}

.lexical-context-box::-webkit-scrollbar-track {
  background: transparent;
}

.lexical-context-box::-webkit-scrollbar-thumb {
  background-color: var(--oow-scrollbar-thumb-bg, rgba(0, 0, 0, 0.2));
  border-radius: var(--oow-scrollbar-thumb-radius, 3px);
}

/* 强制隐藏水平滚动条 */
.lexical-context-box::-webkit-scrollbar-horizontal {
  display: none !important;
}

.part1-context .text {
  white-space: pre-wrap;
}

/* 确保流式块出现内联，而不是每行一个字符 */
.translation {
  margin-bottom: var(--spacing-2);
}

.text-translation {
  display: inline-block;
  font-weight: 800;
  font-size: 1.2em;
  letter-spacing: 0.2px;
  color: var(--oow-panel-text);
  word-break: break-word;
  white-space: normal;
}

.text-contextual_analysis {
  display: inline-block;
  color: var(--oow-panel-muted);
  word-break: break-word;
  white-space: normal;
  overflow: visible;
}

/* PART-2 内容样式 - 词源和说明内容 */
/* Info Panel 专用变量系统 - 设计师主题创作接口 */
.info-panel-content {
  /* 整体样式变量 */
  --oow-info-panel-text-color: var(--oow-panel-text);
  --oow-info-panel-heading-color: var(--oow-panel-text);
  --oow-info-panel-heading-weight: 700;
  --oow-info-panel-heading-margin-top: 1em;
  --oow-info-panel-heading-margin-bottom: 0.5em;
  --oow-info-panel-paragraph-color: var(--oow-panel-text);
  --oow-info-panel-paragraph-margin-bottom: 0.8em;
  --oow-info-panel-list-color: var(--oow-panel-text);
  --oow-info-panel-blockquote-color: var(--oow-panel-muted);
  --oow-info-panel-blockquote-border: var(--oow-panel-accent-1);
  --oow-info-panel-code-color: var(--oow-code-color);
  --oow-info-panel-code-bg: var(--oow-code-bg);
  --oow-info-panel-link-color: var(--oow-panel-accent-1);
  --oow-info-panel-link-hover: var(--oow-panel-accent-2);
  --oow-info-panel-line-height: 1.6;
  --oow-info-panel-letter-spacing: 0;
  --oow-info-panel-font-family: inherit;
}

.part2-content h1,
.part2-content h2,
.part2-content h3,
.info-panel-content h1,
.info-panel-content h2,
.info-panel-content h3 {
  font-weight: var(--oow-info-panel-heading-weight);
  margin-top: var(--oow-info-panel-heading-margin-top);
  margin-bottom: var(--oow-info-panel-heading-margin-bottom);
  color: var(--oow-info-panel-heading-color);
  line-height: var(--oow-info-panel-line-height);
  letter-spacing: var(--oow-info-panel-letter-spacing);
  font-family: var(--oow-info-panel-font-family);
}

.part2-content p,
.info-panel-content p {
  margin-bottom: var(--oow-info-panel-paragraph-margin-bottom);
  color: var(--oow-info-panel-paragraph-color);
  line-height: var(--oow-info-panel-line-height);
  letter-spacing: var(--oow-info-panel-letter-spacing);
  font-family: var(--oow-info-panel-font-family);
}

.part2-content ul,
.part2-content ol,
.info-panel-content ul,
.info-panel-content ol {
  padding-left: var(--spacing-5);
  margin-bottom: 1em;
  color: var(--oow-info-panel-list-color);
}

.part2-content li,
.info-panel-content li {
  margin-bottom: 0.4em;
  color: var(--oow-info-panel-list-color);
}

.part2-content code,
.info-panel-content code {
  background-color: var(--oow-info-panel-code-bg);
  border-radius: var(--oow-code-border-radius);
  padding: var(--oow-code-padding);
  font-family: monospace;
  color: var(--oow-info-panel-code-color);
}

.part2-content pre,
.info-panel-content pre {
  background-color: var(--oow-info-panel-code-bg);
  border-radius: var(--radius-lg);
  padding: var(--spacing-3);
  white-space: pre-wrap;
  word-break: break-all;
  color: var(--oow-info-panel-code-color);
}

.part2-content blockquote,
.info-panel-content blockquote {
  border-left: 3px solid var(--oow-info-panel-blockquote-border);
  padding-left: var(--spacing-3);
  margin-left: 0;
  color: var(--oow-info-panel-blockquote-color);
}

.info-panel-content a {
  color: var(--oow-info-panel-link-color);
  text-decoration: none;
  transition: color 0.2s ease;
}

.info-panel-content a:hover {
  color: var(--oow-info-panel-link-hover);
  text-decoration: underline;
}

/* 添加微交互效果 */
.info-panel-content h1,
.info-panel-content h2,
.info-panel-content h3 {
  transition: all 0.2s ease;
}

.info-panel-content h1:hover,
.info-panel-content h2:hover,
.info-panel-content h3:hover {
  transform: translateY(-1px);
  text-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.info-panel-content p,
.info-panel-content li {
  transition: all 0.2s ease;
}

.info-panel-content p:hover,
.info-panel-content li:hover {
  transform: translateY(-0.5px);
}

.info-panel-content blockquote {
  transition: all 0.3s ease;
}

.info-panel-content blockquote:hover {
  transform: translateX(2px);
  border-left-color: var(--oow-info-panel-blockquote-border);
}

.info-panel-content code {
  transition: all 0.2s ease;
}

.info-panel-content code:hover {
  transform: scale(1.02);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.part2-content .error-message {
  color: var(--oow-error);
  font-weight: bold;
}


/* 等化器加载器 */
.part1-content .part1-context {
  position: relative;
}

.part1-content .context-loader {
  display: none;
  padding: var(--spacing-2) 0 var(--spacing-2) 0;
}
`,ft=`
.part1-content .context-loader.visible {
  display: block;
}

.eq {
  display: grid;
  grid-auto-flow: column;
  gap: var(--spacing-2);
  justify-content: center;
  align-items: end;
  height: 26px;
}

.eq .bar {
  width: var(--oow-loader-size);
  border-radius: var(--oow-loader-size);
  background: linear-gradient(180deg, var(--oow-panel-accent-1), var(--oow-panel-accent-2));
  box-shadow: 0 2px 10px rgba(176,114,255,0.5);
  animation: oow-eq 0.9s ease-in-out infinite;
}

.eq .b1 {
  animation-delay: 0s;
}

.eq .b2 {
  animation-delay: 0.1s;
}

.eq .b3 {
  animation-delay: 0.2s;
}

.eq .b4 {
  animation-delay: 0.3s;
}

.eq .b5 {
  animation-delay: 0.4s;
}

@keyframes oow-eq {
  0%, 100% {
    height: var(--spacing-2);
    filter: saturate(120%);
  }
  40% {
    height: 22px;
    filter: saturate(160%);
  }
  60% {
    height: var(--spacing-3);
  }
}

/* 内容溢出修复 */
.part2-section .section-content {
  overflow: visible !important;
  max-height: none !important;
}

.part2-content,
.info-panel-content {
  overflow: visible !important;
  word-break: break-word !important;
}/*
 * Lexical Panel Component
 * 词汇面板组件 - 显示词汇定义、翻译和上下文分析
 */

/* 组件专用变量 - 设计师主题创作接口 */
.lexical-panel {
  /* 整体布局 */
  --oow-lexical-panel-bg: transparent;
  --oow-lexical-panel-padding: 0;
  --oow-lexical-panel-gap: var(--spacing-2);
  --oow-lexical-panel-transition: var(--oow-animation-base, 0.25s);

  /* 定义列表样式 */
  --oow-lexical-panel-defs-gap: var(--spacing-2);
  --oow-lexical-panel-defs-line-height: 1.5;
  --oow-lexical-panel-defs-list-style: none;
  --oow-lexical-panel-defs-padding: 0;
  --oow-lexical-panel-defs-margin: 0;

  /* 定义项样式 */
  --oow-lexical-panel-def-item-gap: var(--spacing-1);
  --oow-lexical-panel-def-item-display: flex;
  --oow-lexical-panel-def-item-direction: column;

  /* 词性样式 */
  --oow-lexical-panel-pos-color: #005a9e;
  --oow-lexical-panel-pos-weight: 600;
  --oow-lexical-panel-pos-margin-right: var(--spacing-1);
  --oow-lexical-panel-pos-white-space: nowrap;
  --oow-lexical-panel-pos-font-size: var(--font-size-sm);
  --oow-lexical-panel-pos-text-transform: none;
  --oow-lexical-panel-pos-text-decoration: none;

  /* 含义样式 */
  --oow-lexical-panel-meaning-color: #333;
  --oow-lexical-panel-meaning-display: flex;
  --oow-lexical-panel-meaning-align-items: center;
  --oow-lexical-panel-meaning-wrap: nowrap;
  --oow-lexical-panel-meaning-font-size: var(--font-size-base);
  --oow-lexical-panel-meaning-font-weight: 400;
  --oow-lexical-panel-meaning-line-height: 1.4;

  /* 示例样式 */
  --oow-lexical-panel-example-color: #555;
  --oow-lexical-panel-example-margin-top: 0;
  --oow-lexical-panel-example-padding-left: var(--spacing-1);
  --oow-lexical-panel-example-border-left: 2px solid rgba(0,0,0,0.1);
  --oow-lexical-panel-example-font-style: italic;
  --oow-lexical-panel-example-display: flex;
  --oow-lexical-panel-example-align-items: center;
  --oow-lexical-panel-example-wrap: nowrap;
  --oow-lexical-panel-example-gap: var(--spacing-1);
  --oow-lexical-panel-example-font-size: var(--font-size-sm);
  --oow-lexical-panel-example-line-height: 1.4;

  /* 箭头样式 */
  --oow-lexical-panel-arrow-gap: var(--spacing-1);
  --oow-lexical-panel-arrow-color: #666;
  --oow-lexical-panel-arrow-font-weight: normal;
  --oow-lexical-panel-arrow-text-decoration: none;

  /* 上下文容器样式 */
  --oow-lexical-panel-context-box-bg: linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02));
  --oow-lexical-panel-context-box-padding: 14px;
  --oow-lexical-panel-context-box-border: 1px solid var(--ring);
  --oow-lexical-panel-context-box-radius: 10px;
  --oow-lexical-panel-context-box-min-height: 32px;
  --oow-lexical-panel-context-box-margin-bottom: var(--spacing-1);
  --oow-lexical-panel-context-box-margin-right: var(--spacing-1);
  --oow-lexical-panel-context-box-max-height: 320px;
  --oow-lexical-panel-context-box-overflow-y: auto;
  --oow-lexical-panel-context-box-overflow-x: hidden;
  --oow-lexical-panel-context-box-scrollbar-width: thin;
  --oow-lexical-panel-context-box-scrollbar-color: var(--accent-1) transparent;
  --oow-lexical-panel-context-box-box-sizing: border-box;

  /* 文本内容样式 */
  --oow-lexical-panel-text-white-space: pre-wrap;
  --oow-lexical-panel-text-word-break: break-word;
  --oow-lexical-panel-text-white-space-normal: normal;
  --oow-lexical-panel-text-display: inline-block;
  --oow-lexical-panel-text-font-weight: 800;
  --oow-lexical-panel-text-font-size: 1.2em;
  --oow-lexical-panel-text-letter-spacing: 0.2px;
  --oow-lexical-panel-text-color: var(--text-color);
  --oow-lexical-panel-text-text-shadow: none;
  --oow-lexical-panel-text-text-decoration: none;

  /* 翻译文本专用样式 - 更大更突出 */
  --oow-lexical-panel-translation-font-size: 1.3em;
  --oow-lexical-panel-translation-font-weight: 700;
  --oow-lexical-panel-translation-letter-spacing: 0.3px;
  --oow-lexical-panel-translation-line-height: 1.4;

  /* 上下文分析文本专用样式 - 保持清晰可读 */
  --oow-lexical-panel-analysis-font-size: 1.0em;
  --oow-lexical-panel-analysis-font-weight: 400;
  --oow-lexical-panel-analysis-line-height: 1.5;

  /* 翻译文本样式 */
  --oow-lexical-panel-translation-margin-bottom: var(--spacing-1);
  --oow-lexical-panel-translation-text-shadow: 0 1px 2px rgba(0,0,0,0.1);
  --oow-lexical-panel-translation-bg: transparent;
  --oow-lexical-panel-translation-border: none;
  --oow-lexical-panel-translation-border-radius: 0;
  --oow-lexical-panel-translation-padding: 0;
  --oow-lexical-panel-translation-style-type: subtle; /* subtle, framed, gradient, glow */
  --oow-lexical-panel-translation-frame-bg: transparent;
  --oow-lexical-panel-translation-frame-border: none;
  --oow-lexical-panel-translation-frame-radius: 0;
  --oow-lexical-panel-translation-frame-padding: 0;
  --oow-lexical-panel-translation-glow: none;
  --oow-lexical-panel-translation-gradient: none;

  /* 上下文分析文本样式 */
  --oow-lexical-panel-analysis-color: var(--muted);
  --oow-lexical-panel-analysis-overflow: visible;
  --oow-lexical-panel-analysis-font-style: normal;
  --oow-lexical-panel-analysis-font-weight: 400;
  --oow-lexical-panel-analysis-line-height: 1.4;
  --oow-lexical-panel-analysis-text-shadow: none;
  --oow-lexical-panel-analysis-style-type: subtle; /* subtle, framed, gradient, glow */
  --oow-lexical-panel-analysis-frame-bg: transparent;
  --oow-lexical-panel-analysis-frame-border: none;
  --oow-lexical-panel-analysis-frame-radius: 0;
  --oow-lexical-panel-analysis-frame-padding: 0;
  --oow-lexical-panel-analysis-glow: none;
  --oow-lexical-panel-analysis-gradient: none;

  /* 源语言文本样式 */
  --oow-lexical-panel-src-color: inherit;
  --oow-lexical-panel-src-font-weight: normal;
  --oow-lexical-panel-src-font-style: normal;
  --oow-lexical-panel-src-text-decoration: none;

  /* 目标语言文本样式 */
  --oow-lexical-panel-tgt-color: inherit;
  --oow-lexical-panel-tgt-font-weight: normal;
  --oow-lexical-panel-tgt-font-style: normal;
  --oow-lexical-panel-tgt-text-decoration: none;

  /* 加载指示器样式 */
  --oow-lexical-panel-loader-display: none;
  --oow-lexical-panel-loader-padding: var(--spacing-1) 0 var(--spacing-1) 0;
  --oow-lexical-panel-loader-display-visible: grid;

  /* Equalizer 动画样式 */
  --oow-lexical-panel-eq-display: grid;
  --oow-lexical-panel-eq-auto-flow: column;
  --oow-lexical-panel-eq-gap: 6px;
  --oow-lexical-panel-eq-justify-content: center;
  --oow-lexical-panel-eq-align-items: end;
  --oow-lexical-panel-eq-height: 26px;

  /* 动画条样式 */
  --oow-lexical-panel-bar-width: 6px;
  --oow-lexical-panel-bar-border-radius: 6px;
  --oow-lexical-panel-bar-bg: linear-gradient(180deg, var(--accent-1), var(--accent-2));
  --oow-lexical-panel-bar-box-shadow: 0 2px 10px rgba(176,114,255,0.5);
  --oow-lexical-panel-bar-animation: oow-eq 0.9s ease-in-out infinite;

  /* 动画延迟 */
  --oow-lexical-panel-bar-1-delay: 0s;
  --oow-lexical-panel-bar-2-delay: 0.1s;
  --oow-lexical-panel-bar-3-delay: 0.2s;
  --oow-lexical-panel-bar-4-delay: 0.3s;
  --oow-lexical-panel-bar-5-delay: 0.4s;

  /* 动画关键帧 */
  --oow-lexical-panel-bar-height-start: 6px;
  --oow-lexical-panel-bar-height-middle: 22px;
  --oow-lexical-panel-bar-height-end: 12px;
  --oow-lexical-panel-bar-filter-saturate-start: 120%;
  --oow-lexical-panel-bar-filter-saturate-middle: 160%;

  /* 无障碍访问 */
  --oow-lexical-panel-role: region;
  --oow-lexical-panel-aria-label: 'Lexical information';

  /* 增强的交互状态样式 */
  --oow-lexical-panel-focus-outline: 2px solid var(--accent-1);
  --oow-lexical-panel-focus-outline-offset: 2px;
  --oow-lexical-panel-error-color: #dc2626;
  --oow-lexical-panel-error-bg: #fef2f2;
  --oow-lexical-panel-error-border: 1px solid #fecaca;
  --oow-lexical-panel-success-color: #059669;
  --oow-lexical-panel-success-bg: #ecfdf5;
  --oow-lexical-panel-success-border: 1px solid #a7f3d0;
  --oow-lexical-panel-highlight-bg: #fef3c7;
  --oow-lexical-panel-highlight-border: 1px solid #fcd34d;
  --oow-lexical-panel-warning-color: #d97706;
  --oow-lexical-panel-warning-bg: #fffbeb;
  --oow-lexical-panel-warning-border: 1px solid #fed7aa;

  /* 响应式设计变量 */
  --oow-lexical-panel-mobile-padding: 12px;
  --oow-lexical-panel-mobile-font-size: 0.9em;
  --oow-lexical-panel-tablet-padding: 16px;
  --oow-lexical-panel-tablet-font-size: 1em;
  --oow-lexical-panel-desktop-padding: 20px;
  --oow-lexical-panel-desktop-font-size: 1.1em;
  --oow-lexical-panel-breakpoint-mobile: 480px;
  --oow-lexical-panel-breakpoint-tablet: 768px;
  --oow-lexical-panel-breakpoint-desktop: 1024px;

  /* 自定义滚动条样式 */
  --oow-lexical-panel-scrollbar-width: 6px;
  --oow-lexical-panel-scrollbar-track-bg: transparent;
  --oow-lexical-panel-scrollbar-thumb-bg: var(--accent-1);
  --oow-lexical-panel-scrollbar-thumb-hover-bg: var(--accent-2);
  --oow-lexical-panel-scrollbar-thumb-radius: 3px;
  --oow-lexical-panel-scrollbar-thumb-transition: background-color 0.2s ease;

  /* 打印样式 */
  --oow-lexical-panel-print-color: #000;
  --oow-lexical-panel-print-bg: #fff;
  --oow-lexical-panel-print-font-size: 12pt;
  --oow-lexical-panel-print-line-height: 1.4;
  --oow-lexical-panel-print-hide-loader: true;
  --oow-lexical-panel-print-hide-scrollbar: true;

  /* 高对比度模式支持 */
  --oow-lexical-panel-hc-text-color: #000;
  --oow-lexical-panel-hc-bg-color: #fff;
  --oow-lexical-panel-hc-border-color: #000;
  --oow-lexical-panel-hc-link-color: #0000ff;
  --oow-lexical-panel-hc-link-visited-color: #800080;
  --oow-lexical-panel-hc-focus-outline: 3px solid #000;

  /* 深色模式支持 */
  --oow-lexical-panel-dark-bg: rgba(0,0,0,0.8);
  --oow-lexical-panel-dark-text-color: #fff;
  --oow-lexical-panel-dark-border-color: rgba(255,255,255,0.2);
  --oow-lexical-panel-dark-context-box-bg: linear-gradient(180deg, rgba(0,0,0,0.3), rgba(0,0,0,0.1));
  --oow-lexical-panel-dark-example-color: #ccc;
  --oow-lexical-panel-dark-pos-color: #4a9eff;
  --oow-lexical-panel-dark-meaning-color: #fff;
  --oow-lexical-panel-dark-scrollbar-thumb-bg: rgba(255,255,255,0.3);

  /* 微交互增强 */
  --oow-lexical-panel-example-hover-transform: translateX(2px);
  --oow-lexical-panel-example-hover-color: #333;
  --oow-lexical-panel-meaning-hover-weight: 500;
  --oow-lexical-panel-pos-hover-color: #0073b0;
  --oow-lexical-panel-context-box-hover-shadow: 0 4px 12px rgba(0,0,0,0.1);
  --oow-lexical-panel-transition-quick: 0.15s ease;
  --oow-lexical-panel-transition-smooth: 0.3s ease;

  /* 可访问性增强 */
  --oow-lexical-panel-reduced-motion: none;
  --oow-lexical-panel-high-contrast-border: 2px solid;
  --oow-lexical-panel-focus-visible-outline: 2px solid var(--focus-color, var(--accent-1));
  --oow-lexical-panel-screen-reader-only: none;
  --oow-lexical-panel-aria-live: polite;
  --oow-lexical-panel-aria-busy: false;

  /* 内容分组样式 */
  --oow-lexical-panel-group-margin: 16px 0;
  --oow-lexical-panel-group-padding: 12px;
  --oow-lexical-panel-group-border: 1px solid rgba(0,0,0,0.05);
  --oow-lexical-panel-group-radius: 8px;
  --oow-lexical-panel-group-bg: rgba(0,0,0,0.02);
  --oow-lexical-panel-separator-height: 1px;
  --oow-lexical-panel-separator-bg: rgba(0,0,0,0.1);
  --oow-lexical-panel-separator-margin: 8px 0;

  /* 字体排印增强 */
  --oow-lexical-panel-font-family-base: inherit;
  --oow-lexical-panel-font-family-mono: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  --oow-lexical-panel-letter-spacing-tight: -0.02em;
  --oow-lexical-panel-letter-spacing-normal: 0;
  --oow-lexical-panel-letter-spacing-wide: 0.02em;
  --oow-lexical-panel-line-height-tight: 1.2;
  --oow-lexical-panel-line-height-normal: 1.4;
  --oow-lexical-panel-line-height-relaxed: 1.6;

  /* 空状态和加载状态 */
  --oow-lexical-panel-empty-text: 'No definitions available';
  --oow-lexical-panel-empty-color: #999;
  --oow-lexical-panel-empty-font-style: italic;
  --oow-lexical-panel-empty-text-align: center;
  --oow-lexical-panel-empty-padding: 20px;
  --oow-lexical-panel-loading-opacity: 0.7;
  --oow-lexical-panel-loading-blur: 0.5px;

  /* 性能优化 */
  --oow-lexical-panel-will-change: auto;
  --oow-lexical-panel-transform: none;
  --oow-lexical-panel-backface-visibility: visible;
  --oow-lexical-panel-composite-mode: auto;
  --oow-lexical-panel-isolation: auto;
}

/* 应用变量到组件 */
.lexical-panel {
  background: var(--oow-lexical-panel-bg);
  padding: var(--oow-lexical-panel-padding);
  gap: var(--oow-lexical-panel-gap);
  transition: var(--oow-lexical-panel-transition);
}

/* 定义列表样式 */
.defs-list {
  list-style: var(--oow-lexical-panel-defs-list-style);
  padding: var(--oow-lexical-panel-defs-padding);
  margin: var(--oow-lexical-panel-defs-margin);
  display: grid;
  gap: var(--oow-lexical-panel-defs-gap);
}

.def-item {
  line-height: var(--oow-lexical-panel-defs-line-height);
  display: var(--oow-lexical-panel-def-item-display);
  flex-direction: var(--oow-lexical-panel-def-item-direction);
  gap: var(--oow-lexical-panel-def-item-gap);
}

/* 词性和含义容器 */
.pos-meaning {
  display: var(--oow-lexical-panel-meaning-display);
  align-items: var(--oow-lexical-panel-meaning-align-items);
  gap: var(--oow-lexical-panel-meaning-gap);
  flex-wrap: var(--oow-lexical-panel-meaning-wrap);
}

.pos {
  font-weight: var(--oow-lexical-panel-pos-weight);
  color: var(--oow-lexical-panel-pos-color);
  margin-right: var(--oow-lexical-panel-pos-margin-right);
  white-space: var(--oow-lexical-panel-pos-white-space);
  font-size: var(--oow-lexical-panel-pos-font-size);
  text-transform: var(--oow-lexical-panel-pos-text-transform);
  text-decoration: var(--oow-lexical-panel-pos-text-decoration);
}

.meaning {
  color: var(--oow-lexical-panel-meaning-color);
  font-size: var(--oow-lexical-panel-meaning-font-size);
  font-weight: var(--oow-lexical-panel-meaning-font-weight);
  line-height: var(--oow-lexical-panel-meaning-line-height);
}

/* 示例样式 */
.example {
  color: var(--oow-lexical-panel-example-color);
  margin-top: var(--oow-lexical-panel-example-margin-top);
  padding-left: var(--oow-lexical-panel-example-padding-left);
  border-left: var(--oow-lexical-panel-example-border-left);
  font-style: var(--oow-lexical-panel-example-font-style);
  display: var(--oow-lexical-panel-example-display);
  align-items: var(--oow-lexical-panel-example-align-items);
  gap: var(--oow-lexical-panel-example-gap);
  flex-wrap: var(--oow-lexical-panel-example-wrap);
  font-size: var(--oow-lexical-panel-example-font-size);
  line-height: var(--oow-lexical-panel-example-line-height);
}

.arrow {
  gap: var(--oow-lexical-panel-arrow-gap);
  color: var(--oow-lexical-panel-arrow-color);
  font-weight: var(--oow-lexical-panel-arrow-font-weight);
  text-decoration: var(--oow-lexical-panel-arrow-text-decoration);
}

.src {
  color: var(--oow-lexical-panel-src-color);
  font-weight: var(--oow-lexical-panel-src-font-weight);
  font-style: var(--oow-lexical-panel-src-font-style);
  text-decoration: var(--oow-lexical-panel-src-text-decoration);
}

.tgt {
  color: var(--oow-lexical-panel-tgt-color);
  font-weight: var(--oow-lexical-panel-tgt-font-weight);
  font-style: var(--oow-lexical-panel-tgt-font-style);
  text-decoration: var(--oow-lexical-panel-tgt-text-decoration);
}

/* 上下文容器样式 */
.lexical-context-box {
  background: var(--oow-lexical-panel-context-box-bg);
  padding: var(--oow-lexical-panel-context-box-padding);
  border-radius: var(--oow-lexical-panel-context-box-radius);
  border: var(--oow-lexical-panel-context-box-border);
  min-height: var(--oow-lexical-panel-context-box-min-height);
  margin-bottom: var(--oow-lexical-panel-context-box-margin-bottom);
  margin-right: var(--oow-lexical-panel-context-box-margin-right);
  max-height: var(--oow-lexical-panel-context-box-max-height);
  overflow-y: var(--oow-lexical-panel-context-box-overflow-y);
  overflow-x: var(--oow-lexical-panel-context-box-overflow-x);
  scrollbar-width: var(--oow-lexical-panel-context-box-scrollbar-width);
  scrollbar-color: var(--oow-lexical-panel-context-box-scrollbar-color);
  box-sizing: var(--oow-lexical-panel-context-box-box-sizing);
}

/* 自定义滚动条样式 */
.lexical-context-box::-webkit-scrollbar {
  width: 6px;
}

.lexical-context-box::-webkit-scrollbar-track {
  background: transparent;
}

.lexical-context-box::-webkit-scrollbar-thumb {
  background-color: var(--accent-1);
  border-radius: 3px;
}

/* 文本内容样式 */
.text {
  white-space: var(--oow-lexical-panel-text-white-space);
  word-break: var(--oow-lexical-panel-text-word-break);
}

.translation {
  margin-bottom: var(--oow-lexical-panel-translation-margin-bottom);
}

.text-translation {
  display: var(--oow-lexical-panel-text-display);
  font-weight: var(--oow-lexical-panel-translation-font-weight);
  font-size: var(--oow-lexical-panel-translation-font-size);
  letter-spacing: var(--oow-lexical-panel-translation-letter-spacing);
  color: var(--oow-lexical-panel-text-color);
  word-break: var(--oow-lexical-panel-text-word-break);
  white-space: var(--oow-lexical-panel-text-white-space-normal);
  text-shadow: var(--oow-lexical-panel-text-text-shadow);
  text-decoration: var(--oow-lexical-panel-text-text-decoration);
  line-height: var(--oow-lexical-panel-translation-line-height);
}

/* 针对实际DOM结构的样式 - translation区域内的文本 */
`,pt=`.translation .text {
  display: var(--oow-lexical-panel-text-display);
  font-weight: var(--oow-lexical-panel-translation-font-weight);
  font-size: var(--oow-lexical-panel-translation-font-size);
  letter-spacing: var(--oow-lexical-panel-translation-letter-spacing);
  color: var(--oow-lexical-panel-text-color);
  word-break: var(--oow-lexical-panel-text-word-break);
  white-space: var(--oow-lexical-panel-text-white-space-normal);
  text-shadow: var(--oow-lexical-panel-text-text-shadow);
  text-decoration: var(--oow-lexical-panel-text-text-decoration);
  line-height: var(--oow-lexical-panel-translation-line-height);
}

/* 根据style-type应用不同的视觉效果 */
.translation {
  margin-bottom: var(--oow-lexical-panel-translation-margin-bottom);
  background: var(--oow-lexical-panel-translation-frame-bg);
  border: var(--oow-lexical-panel-translation-frame-border);
  border-radius: var(--oow-lexical-panel-translation-frame-radius);
  padding: var(--oow-lexical-panel-translation-frame-padding);
  box-shadow: var(--oow-lexical-panel-translation-glow);
  background-image: var(--oow-lexical-panel-translation-gradient);
}

/* subtle样式：仅文字效果，无边框背景 */
.translation[data-style="subtle"] {
  background: transparent;
  border: none;
  border-radius: 0;
  padding: 0;
  box-shadow: none;
  background-image: none;
}

/* framed样式：边框背景效果 */
.translation[data-style="framed"] {
  background: var(--oow-lexical-panel-translation-frame-bg);
  border: var(--oow-lexical-panel-translation-frame-border);
  border-radius: var(--oow-lexical-panel-translation-frame-radius);
  padding: var(--oow-lexical-panel-translation-frame-padding);
  box-shadow: var(--oow-lexical-panel-translation-glow);
}

/* gradient样式：渐变文字效果 */
.translation[data-style="gradient"] {
  background: transparent;
  border: none;
  border-radius: 0;
  padding: 0;
  box-shadow: none;
  background-image: var(--oow-lexical-panel-translation-gradient);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}

.text-contextual_analysis {
  display: var(--oow-lexical-panel-text-display);
  color: var(--oow-lexical-panel-analysis-color);
  word-break: var(--oow-lexical-panel-text-word-break);
  white-space: var(--oow-lexical-panel-text-white-space-normal);
  overflow: var(--oow-lexical-panel-analysis-overflow);
  font-style: var(--oow-lexical-panel-analysis-font-style);
  font-weight: var(--oow-lexical-panel-analysis-font-weight);
  font-size: var(--oow-lexical-panel-analysis-font-size);
  line-height: var(--oow-lexical-panel-analysis-line-height);
  text-shadow: var(--oow-lexical-panel-analysis-text-shadow);
}

/* 针对实际DOM结构的样式 - contextual-analysis区域内的文本 */
.contextual-analysis .text {
  display: var(--oow-lexical-panel-text-display);
  color: var(--oow-lexical-panel-analysis-color);
  word-break: var(--oow-lexical-panel-text-word-break);
  white-space: var(--oow-lexical-panel-text-white-space-normal);
  overflow: var(--oow-lexical-panel-analysis-overflow);
  font-style: var(--oow-lexical-panel-analysis-font-style);
  font-weight: var(--oow-lexical-panel-analysis-font-weight);
  font-size: var(--oow-lexical-panel-analysis-font-size);
  line-height: var(--oow-lexical-panel-analysis-line-height);
  text-shadow: var(--oow-lexical-panel-analysis-text-shadow);
}

/* 根据style-type应用不同的视觉效果 */
.contextual-analysis {
  background: var(--oow-lexical-panel-analysis-frame-bg);
  border: var(--oow-lexical-panel-analysis-frame-border);
  border-radius: var(--oow-lexical-panel-analysis-frame-radius);
  padding: var(--oow-lexical-panel-analysis-frame-padding);
  box-shadow: var(--oow-lexical-panel-analysis-glow);
  background-image: var(--oow-lexical-panel-analysis-gradient);
}

/* subtle样式：仅文字效果，无边框背景 */
.contextual-analysis[data-style="subtle"] {
  background: transparent;
  border: none;
  border-radius: 0;
  padding: 0;
  box-shadow: none;
  background-image: none;
}

/* framed样式：边框背景效果 */
.contextual-analysis[data-style="framed"] {
  background: var(--oow-lexical-panel-analysis-frame-bg);
  border: var(--oow-lexical-panel-analysis-frame-border);
  border-radius: var(--oow-lexical-panel-analysis-frame-radius);
  padding: var(--oow-lexical-panel-analysis-frame-padding);
  box-shadow: var(--oow-lexical-panel-analysis-glow);
}

/* gradient样式：渐变文字效果 */
.contextual-analysis[data-style="gradient"] {
  background: transparent;
  border: none;
  border-radius: 0;
  padding: 0;
  box-shadow: none;
  background-image: var(--oow-lexical-panel-analysis-gradient);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}

/* 加载指示器样式 */
.context-loader {
  display: var(--oow-lexical-panel-loader-display);
  padding: var(--oow-lexical-panel-loader-padding);
}

.context-loader.visible {
  display: var(--oow-lexical-panel-loader-display-visible);
}

/* Equalizer 动画样式 */
.eq {
  display: var(--oow-lexical-panel-eq-display);
  grid-auto-flow: var(--oow-lexical-panel-eq-auto-flow);
  gap: var(--oow-lexical-panel-eq-gap);
  justify-content: var(--oow-lexical-panel-eq-justify-content);
  align-items: var(--oow-lexical-panel-eq-align-items);
  height: var(--oow-lexical-panel-eq-height);
}

.bar {
  width: var(--oow-lexical-panel-bar-width);
  border-radius: var(--oow-lexical-panel-bar-border-radius);
  background: var(--oow-lexical-panel-bar-bg);
  box-shadow: var(--oow-lexical-panel-bar-box-shadow);
  animation: var(--oow-lexical-panel-bar-animation);
}

.b1 { animation-delay: var(--oow-lexical-panel-bar-1-delay); }
.b2 { animation-delay: var(--oow-lexical-panel-bar-2-delay); }
.b3 { animation-delay: var(--oow-lexical-panel-bar-3-delay); }
.b4 { animation-delay: var(--oow-lexical-panel-bar-4-delay); }
.b5 { animation-delay: var(--oow-lexical-panel-bar-5-delay); }

/* 动画关键帧 */
@keyframes oow-eq {
  0%, 100% {
    height: var(--oow-lexical-panel-bar-height-start);
    filter: saturate(var(--oow-lexical-panel-bar-filter-saturate-start));
  }
  40% {
    height: var(--oow-lexical-panel-bar-height-middle);
    filter: saturate(var(--oow-lexical-panel-bar-filter-saturate-middle));
  }
  60% {
    height: var(--oow-lexical-panel-bar-height-end);
  }
}/*
 * Base Markdown Panel Component
 * Markdown 面板基类组件 - 提供通用的 Markdown 内容渲染样式
 * 可被继承的子组件（如 InformationPanel）使用
 */

/* 基础 Markdown 面板样式 - 设计师主题创作接口 */
.base-markdown-panel {
  /* 整体布局 */
  --oow-base-markdown-panel-bg: transparent;
  --oow-base-markdown-panel-padding: 0;
  --oow-base-markdown-panel-margin: 0;
  --oow-base-markdown-panel-min-height: 50px;
  --oow-base-markdown-panel-display: block;
  --oow-base-markdown-panel-font-family: inherit;
  --oow-base-markdown-panel-line-height: 1.6;
  --oow-base-markdown-panel-color: inherit;
  --oow-base-markdown-panel-transition: var(--oow-animation-base, 0.25s);

  /* 内容区域样式 */
  --oow-base-markdown-panel-content-padding: var(--spacing-3) var(--spacing-4);
  --oow-base-markdown-panel-content-bg: transparent;
  --oow-base-markdown-panel-content-border: none;
  --oow-base-markdown-panel-content-border-radius: 0;
  --oow-base-markdown-panel-content-max-width: 100%;
  --oow-base-markdown-panel-content-box-sizing: border-box;

  /* 标题样式 */
  --oow-base-markdown-panel-heading-weight: 700;
  --oow-base-markdown-panel-heading-color: var(--text-color);
  --oow-base-markdown-panel-heading-margin-top: 1em;
  --oow-base-markdown-panel-heading-margin-bottom: 0.5em;
  --oow-base-markdown-panel-h1-size: 1.5em;
  --oow-base-markdown-panel-h2-size: 1.3em;
  --oow-base-markdown-panel-h3-size: 1.1em;
  --oow-base-markdown-panel-h4-size: 1em;
  --oow-base-markdown-panel-h5-size: 0.9em;
  --oow-base-markdown-panel-h6-size: 0.8em;

  /* 段落样式 */
  --oow-base-markdown-panel-paragraph-margin-bottom: 0.8em;
  --oow-base-markdown-panel-paragraph-line-height: 1.6;
  --oow-base-markdown-panel-paragraph-color: inherit;
  --oow-base-markdown-panel-paragraph-text-align: left;
  --oow-base-markdown-panel-paragraph-indent: 0;

  /* 列表样式 */
  --oow-base-markdown-panel-list-padding-left: 20px;
  --oow-base-markdown-panel-list-margin-bottom: 1em;
  --oow-base-markdown-panel-list-item-margin-bottom: 0.4em;
  --oow-base-markdown-panel-list-item-color: inherit;
  --oow-base-markdown-panel-list-item-line-height: 1.5;

  /* 代码样式 */
  --oow-base-markdown-panel-code-bg: rgba(0,0,0,0.1);
  --oow-base-markdown-panel-code-border-radius: 4px;
  --oow-base-markdown-panel-code-padding: 2px 4px;
  --oow-base-markdown-panel-code-font-family: var(--font-family-mono, 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace);
  --oow-base-markdown-panel-code-color: inherit;
  --oow-base-markdown-panel-code-font-size: 0.9em;
  --oow-base-markdown-panel-code-border: none;

  /* 预格式化文本样式 */
  --oow-base-markdown-panel-pre-bg: rgba(0,0,0,0.1);
  --oow-base-markdown-panel-pre-border-radius: 6px;
  --oow-base-markdown-panel-pre-padding: 12px;
  --oow-base-markdown-panel-pre-white-space: pre-wrap;
  --oow-base-markdown-panel-pre-word-break: break-all;
  --oow-base-markdown-panel-pre-font-family: var(--font-family-mono, 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace);
  --oow-base-markdown-panel-pre-font-size: 0.9em;
  --oow-base-markdown-panel-pre-line-height: 1.4;

  /* 引用样式 */
  --oow-base-markdown-panel-blockquote-border-left: 3px solid var(--accent-1);
  --oow-base-markdown-panel-blockquote-padding-left: 12px;
  --oow-base-markdown-panel-blockquote-margin-left: 0;
  --oow-base-markdown-panel-blockquote-margin-right: 0;
  --oow-base-markdown-panel-blockquote-margin-top: 1em;
  --oow-base-markdown-panel-blockquote-margin-bottom: 1em;
  --oow-base-markdown-panel-blockquote-color: var(--muted);
  --oow-base-markdown-panel-blockquote-font-style: italic;
  --oow-base-markdown-panel-blockquote-bg: transparent;

  /* 错误消息样式 */
  --oow-base-markdown-panel-error-color: #ff6b6b;
  --oow-base-markdown-panel-error-weight: bold;
  --oow-base-markdown-panel-error-font-size: inherit;
  --oow-base-markdown-panel-error-margin: 10px 0;
  --oow-base-markdown-panel-error-padding: 8px 12px;
  --oow-base-markdown-panel-error-bg: rgba(255,107,107,0.1);
  --oow-base-markdown-panel-error-border-radius: 4px;
  --oow-base-markdown-panel-error-border: 1px solid rgba(255,107,107,0.3);

  /* 流式错误指示器样式 */
  --oow-base-markdown-panel-stream-error-color: #f44336;
  --oow-base-markdown-panel-stream-error-padding: 5px;
  --oow-base-markdown-panel-stream-error-margin: 5px 0;
  --oow-base-markdown-panel-stream-error-border-left: 3px solid #f44336;
  --oow-base-markdown-panel-stream-error-background: transparent;
  --oow-base-markdown-panel-stream-error-font-size: 0.9em;
  --oow-base-markdown-panel-stream-error-font-weight: 500;

  /* 内容结束标记样式 */
  --oow-base-markdown-panel-end-marker-height: 1px;
  --oow-base-markdown-panel-end-marker-bg: linear-gradient(to right, transparent, #ccc, transparent);
  --oow-base-markdown-panel-end-marker-margin: 10px 0;
  --oow-base-markdown-panel-end-marker-opacity: 0.3;
  --oow-base-markdown-panel-end-marker-width: 100%;
  --oow-base-markdown-panel-end-display: block;

  /* 加载状态样式 */
  --oow-base-markdown-panel-loading-opacity: 0.7;
  --oow-base-markdown-panel-loading-filter: blur(1px);
  --oow-base-markdown-panel-loading-pointer-events: none;
  --oow-base-markdown-panel-loading-transition: opacity 0.3s ease;

  /* 空状态样式 */
  --oow-base-markdown-panel-empty-text: 'No content available';
  --oow-base-markdown-panel-empty-color: var(--muted);
  --oow-base-markdown-panel-empty-font-style: italic;
  --oow-base-markdown-panel-empty-text-align: center;
  --oow-base-markdown-panel-empty-padding: 20px;
  --oow-base-markdown-panel-empty-min-height: 100px;
  --oow-base-markdown-panel-empty-display: flex;
  --oow-base-markdown-panel-empty-align-items: center;
  --oow-base-markdown-panel-empty-justify-content: center;

  /* 链接样式 */
  --oow-base-markdown-panel-link-color: var(--accent-1);
  --oow-base-markdown-panel-link-decoration: underline;
  --oow-base-markdown-panel-link-hover-color: var(--accent-2);
  --oow-base-markdown-panel-link-hover-decoration: none;
  --oow-base-markdown-panel-link-transition: color 0.2s ease;
  --oow-base-markdown-panel-link-visited-color: var(--accent-1);

  /* 强调文本样式 */
  --oow-base-markdown-panel-strong-weight: bold;
  --oow-base-markdown-panel-strong-color: inherit;
  --oow-base-markdown-panel-em-style: italic;
  --oow-base-markdown-panel-em-color: inherit;
  --oow-base-markdown-panel-mark-bg: rgba(255,255,0,0.2);
  --oow-base-markdown-panel-mark-color: inherit;
  --oow-base-markdown-panel-mark-padding: 1px 2px;
  --oow-base-markdown-panel-mark-border-radius: 2px;

  /* 分隔线样式 */
  --oow-base-markdown-panel-hr-height: 1px;
  --oow-base-markdown-panel-hr-bg: var(--ring);
  --oow-base-markdown-panel-hr-margin: 2em 0;
  --oow-base-markdown-panel-hr-opacity: 0.5;
  --oow-base-markdown-panel-hr-border: none;

  /* 表格样式 */
  --oow-base-markdown-panel-table-border-collapse: collapse;
  --oow-base-markdown-panel-table-width: 100%;
  --oow-base-markdown-panel-table-margin: 1em 0;
  --oow-base-markdown-panel-table-border: 1px solid var(--ring);
  --oow-base-markdown-panel-th-bg: rgba(0,0,0,0.05);
  --oow-base-markdown-panel-th-padding: 8px 12px;
  --oow-base-markdown-panel-th-text-align: left;
  --oow-base-markdown-panel-th-font-weight: 600;
  --oow-base-markdown-panel-td-padding: 8px 12px;
  --oow-base-markdown-panel-td-border: 1px solid var(--ring);
  --oow-base-markdown-panel-tr-hover-bg: rgba(0,0,0,0.02);

  /* 图片样式 */
  --oow-base-markdown-panel-img-max-width: 100%;
  --oow-base-markdown-panel-img-height: auto;
  --oow-base-markdown-panel-img-border-radius: 4px;
  --oow-base-markdown-panel-img-margin: 1em 0;
  --oow-base-markdown-panel-img-display: block;

  /* 响应式设计 */
  --oow-base-markdown-panel-mobile-padding: 12px;
  --oow-base-markdown-panel-mobile-font-size: 0.95em;
  --oow-base-markdown-panel-tablet-padding: 16px;
  --oow-base-markdown-panel-tablet-font-size: 1em;
  --oow-base-markdown-panel-desktop-padding: 20px;
  --oow-base-markdown-panel-desktop-font-size: 1.05em;
  --oow-base-markdown-panel-breakpoint-mobile: 480px;
  --oow-base-markdown-panel-breakpoint-tablet: 768px;
  --oow-base-markdown-panel-breakpoint-desktop: 1024px;

  /* 深色模式支持 */
  --oow-base-markdown-panel-dark-code-bg: rgba(255,255,255,0.1);
  --oow-base-markdown-panel-dark-pre-bg: rgba(255,255,255,0.1);
  --oow-base-markdown-panel-dark-blockquote-color: #ccc;
  --oow-base-markdown-panel-dark-hr-bg: rgba(255,255,255,0.2);
  --oow-base-markdown-panel-dark-th-bg: rgba(255,255,255,0.1);
  --oow-base-markdown-panel-dark-tr-hover-bg: rgba(255,255,255,0.05);

  /* 可访问性增强 */
  --oow-base-markdown-panel-focus-outline: 2px solid var(--accent-1);
  --oow-base-markdown-panel-focus-outline-offset: 2px;
  --oow-base-markdown-panel-high-contrast-text: #000;
  --oow-base-markdown-panel-high-contrast-bg: #fff;
  --oow-base-markdown-panel-screen-reader-only: none;
  --oow-base-markdown-panel-skip-link-bg: var(--accent-1);
  --oow-base-markdown-panel-skip-link-color: #fff;

  /* 打印样式 */
  --oow-base-markdown-panel-print-color: #000;
  --oow-base-markdown-panel-print-bg: #fff;
  --oow-base-markdown-panel-print-font-size: 12pt;
  --oow-base-markdown-panel-print-line-height: 1.4;
  --oow-base-markdown-panel-print-hide-end-marker: true;
  --oow-base-markdown-panel-print-hide-stream-error: true;

  /* 性能优化 */
  --oow-base-markdown-panel-will-change: auto;
  --oow-base-markdown-panel-transform: none;
  --oow-base-markdown-panel-backface-visibility: visible;
  --oow-base-markdown-panel-contain: layout;

  /* 内容分组样式 */
  --oow-base-markdown-panel-group-margin: 16px 0;
  --oow-base-markdown-panel-group-padding: 12px;
  --oow-base-markdown-panel-group-border: 1px solid rgba(0,0,0,0.05);
  --oow-base-markdown-panel-group-border-radius: 8px;
  --oow-base-markdown-panel-group-bg: rgba(0,0,0,0.02);

  /* 微交互增强 */
  --oow-base-markdown-panel-hover-transform: translateY(-1px);
  --oow-base-markdown-panel-hover-shadow: 0 2px 8px rgba(0,0,0,0.1);
  --oow-base-markdown-panel-transition-quick: 0.15s ease;
  --oow-base-markdown-panel-transition-smooth: 0.3s ease;

  /* 无障碍访问 */
  --oow-base-markdown-panel-role: region;
  --oow-base-markdown-panel-aria-label: 'Markdown content';
  --oow-base-markdown-panel-aria-live: polite;
  --oow-base-markdown-panel-aria-busy: false;

  /* 代码块高亮样式 */
  --oow-base-markdown-panel-code-block-bg: #282c34;
  --oow-base-markdown-panel-code-block-color: #abb2bf;
  --oow-base-markdown-panel-code-block-padding: 16px;
  --oow-base-markdown-panel-code-block-border-radius: 6px;
  --oow-base-markdown-panel-code-block-font-family: var(--font-family-mono, 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace);
  --oow-base-markdown-panel-code-block-font-size: 0.9em;
  --oow-base-markdown-panel-code-block-line-height: 1.5;
  --oow-base-markdown-panel-code-block-overflow: auto;

  /* 行内代码高亮 */
  --oow-base-markdown-panel-code-inline-bg: rgba(0,0,0,0.08);
  --oow-base-markdown-panel-code-inline-color: #e06c75;
  --oow-base-markdown-panel-code-inline-padding: 2px 4px;
  --oow-base-markdown-panel-code-inline-border-radius: 3px;
  --oow-base-markdown-panel-code-inline-font-size: 0.9em;

  /* 语法高亮颜色 */
  --oow-base-markdown-panel-syntax-keyword: #c678dd;
  --oow-base-markdown-panel-syntax-string: #98c379;
  --oow-base-markdown-panel-syntax-number: #d19a66;
  --oow-base-markdown-panel-syntax-comment: #5c6370;
  --oow-base-markdown-panel-syntax-function: #61afef;
  --oow-base-markdown-panel-syntax-variable: #e06c75;
  --oow-base-markdown-panel-syntax-class: #e5c07b;
}

/* 应用变量到基类组件 */
.base-markdown-panel {
  background: var(--oow-base-markdown-panel-bg);
  padding: var(--oow-base-markdown-panel-padding);
  margin: var(--oow-base-markdown-panel-margin);
  min-height: var(--oow-base-markdown-panel-min-height);
  display: var(--oow-base-markdown-panel-display);
  font-family: var(--oow-base-markdown-panel-font-family);
  line-height: var(--oow-base-markdown-panel-line-height);
  color: var(--oow-base-markdown-panel-color);
  transition: var(--oow-base-markdown-panel-transition);
  will-change: var(--oow-base-markdown-panel-will-change);
  transform: var(--oow-base-markdown-panel-transform);
  backface-visibility: var(--oow-base-markdown-panel-backface-visibility);
  contain: var(--oow-base-markdown-panel-contain);
  overflow-wrap: break-word; /* Force long words to wrap */
  overflow-x: hidden; /* Prevent horizontal scrollbars */
}

/* 内容区域 */
.base-markdown-panel .markdown-content {
  padding: var(--oow-base-markdown-panel-content-padding);
  background: var(--oow-base-markdown-panel-content-bg);
  border: var(--oow-base-markdown-panel-content-border);
  border-radius: var(--oow-base-markdown-panel-content-border-radius);
  max-width: var(--oow-base-markdown-panel-content-max-width);
  box-sizing: var(--oow-base-markdown-panel-content-box-sizing);
}

/* 标题样式 */
.base-markdown-panel h1,
.base-markdown-panel h2,
.base-markdown-panel h3,
.base-markdown-panel h4,
.base-markdown-panel h5,
.base-markdown-panel h6 {
  font-weight: var(--oow-base-markdown-panel-heading-weight);
  color: var(--oow-base-markdown-panel-heading-color);
  margin-top: var(--oow-base-markdown-panel-heading-margin-top);
  margin-bottom: var(--oow-base-markdown-panel-heading-margin-bottom);
}

.base-markdown-panel h1 { font-size: var(--oow-base-markdown-panel-h1-size); }
.base-markdown-panel h2 { font-size: var(--oow-base-markdown-panel-h2-size); }
.base-markdown-panel h3 { font-size: var(--oow-base-markdown-panel-h3-size); }
.base-markdown-panel h4 { font-size: var(--oow-base-markdown-panel-h4-size); }
.base-markdown-panel h5 { font-size: var(--oow-base-markdown-panel-h5-size); }
.base-markdown-panel h6 { font-size: var(--oow-base-markdown-panel-h6-size); }

/* 段落样式 */
.base-markdown-panel p {
  margin-bottom: var(--oow-base-markdown-panel-paragraph-margin-bottom);
  line-height: var(--oow-base-markdown-panel-paragraph-line-height);
  color: var(--oow-base-markdown-panel-paragraph-color);
  text-align: var(--oow-base-markdown-panel-paragraph-text-align);
  text-indent: var(--oow-base-markdown-panel-paragraph-indent);
}

/* 列表样式 */
.base-markdown-panel ul,
.base-markdown-panel ol {
  padding-left: var(--oow-base-markdown-panel-list-padding-left);
  margin-bottom: var(--oow-base-markdown-panel-list-margin-bottom);
}

.base-markdown-panel li {
  margin-bottom: var(--oow-base-markdown-panel-list-item-margin-bottom);
  color: var(--oow-base-markdown-panel-list-item-color);
`,mt=`  line-height: var(--oow-base-markdown-panel-list-item-line-height);
}

/* 代码样式 */
.base-markdown-panel code {
  background-color: var(--oow-base-markdown-panel-code-bg);
  border-radius: var(--oow-base-markdown-panel-code-border-radius);
  padding: var(--oow-base-markdown-panel-code-padding);
  font-family: var(--oow-base-markdown-panel-code-font-family);
  color: var(--oow-base-markdown-panel-code-color);
  font-size: var(--oow-base-markdown-panel-code-font-size);
  border: var(--oow-base-markdown-panel-code-border);
}

.base-markdown-panel pre {
  background-color: var(--oow-base-markdown-panel-pre-bg);
  border-radius: var(--oow-base-markdown-panel-pre-border-radius);
  padding: var(--oow-base-markdown-panel-pre-padding);
  white-space: var(--oow-base-markdown-panel-pre-white-space);
  word-break: var(--oow-base-markdown-panel-pre-word-break);
  font-family: var(--oow-base-markdown-panel-pre-font-family);
  font-size: var(--oow-base-markdown-panel-pre-font-size);
  line-height: var(--oow-base-markdown-panel-pre-line-height);
}

/* 引用样式 */
.base-markdown-panel blockquote {
  border-left: var(--oow-base-markdown-panel-blockquote-border-left);
  padding-left: var(--oow-base-markdown-panel-blockquote-padding-left);
  margin-left: var(--oow-base-markdown-panel-blockquote-margin-left);
  margin-right: var(--oow-base-markdown-panel-blockquote-margin-right);
  margin-top: var(--oow-base-markdown-panel-blockquote-margin-top);
  margin-bottom: var(--oow-base-markdown-panel-blockquote-margin-bottom);
  color: var(--oow-base-markdown-panel-blockquote-color);
  font-style: var(--oow-base-markdown-panel-blockquote-font-style);
  background: var(--oow-base-markdown-panel-blockquote-bg);
}

/* 错误消息样式 */
.base-markdown-panel .error-message {
  color: var(--oow-base-markdown-panel-error-color);
  font-weight: var(--oow-base-markdown-panel-error-weight);
  font-size: var(--oow-base-markdown-panel-error-font-size);
  margin: var(--oow-base-markdown-panel-error-margin);
  padding: var(--oow-base-markdown-panel-error-padding);
  background: var(--oow-base-markdown-panel-error-bg);
  border-radius: var(--oow-base-markdown-panel-error-border-radius);
  border: var(--oow-base-markdown-panel-error-border);
}

/* 流式错误指示器样式 */
.base-markdown-panel .stream-error-indicator {
  color: var(--oow-base-markdown-panel-stream-error-color);
  padding: var(--oow-base-markdown-panel-stream-error-padding);
  margin: var(--oow-base-markdown-panel-stream-error-margin);
  border-left: var(--oow-base-markdown-panel-stream-error-border-left);
  background: var(--oow-base-markdown-panel-stream-error-background);
  font-size: var(--oow-base-markdown-panel-stream-error-font-size);
  font-weight: var(--oow-base-markdown-panel-stream-error-font-weight);
}

/* 内容结束标记样式 */
.base-markdown-panel .content-end-marker {
  height: var(--oow-base-markdown-panel-end-marker-height);
  background: var(--oow-base-markdown-panel-end-marker-bg);
  margin: var(--oow-base-markdown-panel-end-marker-margin);
  opacity: var(--oow-base-markdown-panel-end-marker-opacity);
  width: var(--oow-base-markdown-panel-end-marker-width);
  display: var(--oow-base-markdown-panel-end-display);
}

/* 加载状态样式 */
.base-markdown-panel.loading {
  opacity: var(--oow-base-markdown-panel-loading-opacity);
  filter: var(--oow-base-markdown-panel-loading-filter);
  pointer-events: var(--oow-base-markdown-panel-loading-pointer-events);
  transition: var(--oow-base-markdown-panel-loading-transition);
}

/* 空状态样式 */
.base-markdown-panel.empty {
  display: var(--oow-base-markdown-panel-empty-display);
  align-items: var(--oow-base-markdown-panel-empty-align-items);
  justify-content: var(--oow-base-markdown-panel-empty-justify-content);
  min-height: var(--oow-base-markdown-panel-empty-min-height);
}

.base-markdown-panel.empty::before {
  content: var(--oow-base-markdown-panel-empty-text);
  color: var(--oow-base-markdown-panel-empty-color);
  font-style: var(--oow-base-markdown-panel-empty-font-style);
  text-align: var(--oow-base-markdown-panel-empty-text-align);
  padding: var(--oow-base-markdown-panel-empty-padding);
}

/* 链接样式 */
.base-markdown-panel a {
  color: var(--oow-base-markdown-panel-link-color);
  text-decoration: var(--oow-base-markdown-panel-link-decoration);
  transition: var(--oow-base-markdown-panel-link-transition);
}

.base-markdown-panel a:hover {
  color: var(--oow-base-markdown-panel-link-hover-color);
  text-decoration: var(--oow-base-markdown-panel-link-hover-decoration);
}

.base-markdown-panel a:visited {
  color: var(--oow-base-markdown-panel-link-visited-color);
}

/* 强调文本样式 */
.base-markdown-panel strong {
  font-weight: var(--oow-base-markdown-panel-strong-weight);
  color: var(--oow-base-markdown-panel-strong-color);
}

.base-markdown-panel em {
  font-style: var(--oow-base-markdown-panel-em-style);
  color: var(--oow-base-markdown-panel-em-color);
}

.base-markdown-panel mark {
  background: var(--oow-base-markdown-panel-mark-bg);
  color: var(--oow-base-markdown-panel-mark-color);
  padding: var(--oow-base-markdown-panel-mark-padding);
  border-radius: var(--oow-base-markdown-panel-mark-border-radius);
}

/* 分隔线样式 */
.base-markdown-panel hr {
  height: var(--oow-base-markdown-panel-hr-height);
  background: var(--oow-base-markdown-panel-hr-bg);
  margin: var(--oow-base-markdown-panel-hr-margin);
  opacity: var(--oow-base-markdown-panel-hr-opacity);
  border: var(--oow-base-markdown-panel-hr-border);
}

/* 表格样式 */
.base-markdown-panel table {
  border-collapse: var(--oow-base-markdown-panel-table-border-collapse);
  width: var(--oow-base-markdown-panel-table-width);
  margin: var(--oow-base-markdown-panel-table-margin);
  border: var(--oow-base-markdown-panel-table-border);
}

.base-markdown-panel th {
  background: var(--oow-base-markdown-panel-th-bg);
  padding: var(--oow-base-markdown-panel-th-padding);
  text-align: var(--oow-base-markdown-panel-th-text-align);
  font-weight: var(--oow-base-markdown-panel-th-font-weight);
}

.base-markdown-panel td {
  padding: var(--oow-base-markdown-panel-td-padding);
  border: var(--oow-base-markdown-panel-td-border);
}

.base-markdown-panel tr:hover {
  background: var(--oow-base-markdown-panel-tr-hover-bg);
}

/* 图片样式 */
.base-markdown-panel img {
  max-width: var(--oow-base-markdown-panel-img-max-width);
  height: var(--oow-base-markdown-panel-img-height);
  border-radius: var(--oow-base-markdown-panel-img-border-radius);
  margin: var(--oow-base-markdown-panel-img-margin);
  display: var(--oow-base-markdown-panel-img-display);
}

/* 响应式设计 */
@media (max-width: 480px) {
  .base-markdown-panel {
    padding: var(--oow-base-markdown-panel-mobile-padding);
    font-size: var(--oow-base-markdown-panel-mobile-font-size);
  }
}

@media (min-width: 481px) and (max-width: 768px) {
  .base-markdown-panel {
    padding: var(--oow-base-markdown-panel-tablet-padding);
    font-size: var(--oow-base-markdown-panel-tablet-font-size);
  }
}

@media (min-width: 769px) {
  .base-markdown-panel {
    padding: var(--oow-base-markdown-panel-desktop-padding);
    font-size: var(--oow-base-markdown-panel-desktop-font-size);
  }
}

/* 深色模式支持 */
@media (prefers-color-scheme: dark) {
  .base-markdown-panel code {
    background-color: var(--oow-base-markdown-panel-dark-code-bg, rgba(255,255,255,0.1));
  }

  .base-markdown-panel pre {
    background-color: var(--oow-base-markdown-panel-dark-pre-bg, rgba(255,255,255,0.1));
  }

  .base-markdown-panel blockquote {
    color: var(--oow-base-markdown-panel-dark-blockquote-color, #ccc);
  }

  .base-markdown-panel hr {
    background: var(--oow-base-markdown-panel-dark-hr-bg, rgba(255,255,255,0.2));
  }

  .base-markdown-panel th {
    background: var(--oow-base-markdown-panel-dark-th-bg, rgba(255,255,255,0.1));
  }

  .base-markdown-panel tr:hover {
    background: var(--oow-base-markdown-panel-dark-tr-hover-bg, rgba(255,255,255,0.05));
  }
}

/* 可访问性增强 */
.base-markdown-panel:focus {
  outline: var(--oow-base-markdown-panel-focus-outline);
  outline-offset: var(--oow-base-markdown-panel-focus-outline-offset);
}

@media (prefers-contrast: high) {
  .base-markdown-panel {
    color: var(--oow-base-markdown-panel-high-contrast-text);
    background: var(--oow-base-markdown-panel-high-contrast-bg);
  }
}

.base-markdown-panel .sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
  display: var(--oow-base-markdown-panel-screen-reader-only);
}

/* 跳过链接样式 */
.base-markdown-panel .skip-link {
  position: absolute;
  top: -40px;
  left: 6px;
  background: var(--oow-base-markdown-panel-skip-link-bg);
  color: var(--oow-base-markdown-panel-skip-link-color);
  padding: 8px;
  text-decoration: none;
  border-radius: 4px;
  z-index: 1000;
}

.base-markdown-panel .skip-link:focus {
  top: 6px;
}

/* 打印样式 */
@media print {
  .base-markdown-panel {
    color: var(--oow-base-markdown-panel-print-color);
    background: var(--oow-base-markdown-panel-print-bg);
    font-size: var(--oow-base-markdown-panel-print-font-size);
    line-height: var(--oow-base-markdown-panel-print-line-height);
  }

  .base-markdown-panel .content-end-marker {
    display: var(--oow-base-markdown-panel-print-hide-end-marker, none);
  }

  .base-markdown-panel .stream-error-indicator {
    display: var(--oow-base-markdown-panel-print-hide-stream-error, none);
  }
}

/* 微交互增强 */
.base-markdown-panel:hover {
  transform: var(--oow-base-markdown-panel-hover-transform);
  box-shadow: var(--oow-base-markdown-panel-hover-shadow);
  transition: var(--oow-base-markdown-panel-transition-smooth);
}

/* 内容分组样式 */
.base-markdown-panel .content-group {
  margin: var(--oow-base-markdown-panel-group-margin);
  padding: var(--oow-base-markdown-panel-group-padding);
  border: var(--oow-base-markdown-panel-group-border);
  border-radius: var(--oow-base-markdown-panel-group-border-radius);
  background: var(--oow-base-markdown-panel-group-bg);
}

/* 无障碍访问属性 */
.base-markdown-panel[role="region"] {
  role: var(--oow-base-markdown-panel-role);
}

.base-markdown-panel[aria-label] {
  aria-label: var(--oow-base-markdown-panel-aria-label);
}

.base-markdown-panel[aria-live] {
  aria-live: var(--oow-base-markdown-panel-aria-live);
}

.base-markdown-panel[aria-busy="true"] {
  aria-busy: var(--oow-base-markdown-panel-aria-busy);
}

/* 代码块高亮样式 */
.base-markdown-panel pre code {
  background: var(--oow-base-markdown-panel-code-block-bg);
  color: var(--oow-base-markdown-panel-code-block-color);
  padding: var(--oow-base-markdown-panel-code-block-padding);
  border-radius: var(--oow-base-markdown-panel-code-block-border-radius);
  font-family: var(--oow-base-markdown-panel-code-block-font-family);
  font-size: var(--oow-base-markdown-panel-code-block-font-size);
  line-height: var(--oow-base-markdown-panel-code-block-line-height);
  overflow: var(--oow-base-markdown-panel-code-block-overflow);
  display: block;
}

/* 行内代码样式 */
.base-markdown-panel :not(pre) > code {
  background: var(--oow-base-markdown-panel-code-inline-bg);
  color: var(--oow-base-markdown-panel-code-inline-color);
  padding: var(--oow-base-markdown-panel-code-inline-padding);
  border-radius: var(--oow-base-markdown-panel-code-inline-border-radius);
  font-size: var(--oow-base-markdown-panel-code-inline-font-size);
}

/* 语法高亮样式 */
.base-markdown-panel .token.keyword {
  color: var(--oow-base-markdown-panel-syntax-keyword);
}

.base-markdown-panel .token.string {
  color: var(--oow-base-markdown-panel-syntax-string);
}

.base-markdown-panel .token.number {
  color: var(--oow-base-markdown-panel-syntax-number);
}

.base-markdown-panel .token.comment {
  color: var(--oow-base-markdown-panel-syntax-comment);
}

.base-markdown-panel .token.function {
  color: var(--oow-base-markdown-panel-syntax-function);
}

.base-markdown-panel .token.variable {
  color: var(--oow-base-markdown-panel-syntax-variable);
}

.base-markdown-panel .token.class-name {
  color: var(--oow-base-markdown-panel-syntax-class);
}

/* 继承组件的样式支持 */
.information-panel {
  /* 继承所有基础样式 */
  /* 可以通过 CSS 变量覆盖特定样式 */
}

/* 为继承组件提供变量覆盖接口 */
.information-panel {
  --oow-base-markdown-panel-aria-label: 'Information content';
  --oow-base-markdown-panel-empty-text: 'No information available';
}/*
 * Etymology Panel Component
 * 词源面板组件 - 显示词汇词源和历史发展信息
 */

/* 组件专用变量 - 设计师主题创作接口 */
.etymology-panel {
  /* 整体布局 */
  --oow-etymology-panel-bg: transparent;
  --oow-etymology-panel-padding: 0;
  --oow-etymology-panel-margin: 0;
  --oow-etymology-panel-min-height: 50px;
  --oow-etymology-panel-display: block;
  --oow-etymology-panel-font-family: inherit;
  --oow-etymology-panel-line-height: 1.6;
  --oow-etymology-panel-color: inherit;
  --oow-etymology-panel-transition: var(--oow-animation-base, 0.25s);

  /* 内容区域变量 */
  --oow-etymology-panel-content-padding: 0;
  --oow-etymology-panel-content-bg: transparent;
  --oow-etymology-panel-content-border: none;
  --oow-etymology-panel-content-border-radius: 0;
  --oow-etymology-panel-content-max-width: 100%;
  --oow-etymology-panel-content-box-sizing: border-box;

  /* 标题变量 */
  --oow-etymology-panel-heading-weight: 700;
  --oow-etymology-panel-heading-color: var(--text-color);
  --oow-etymology-panel-heading-margin-top: 1em;
  --oow-etymology-panel-heading-margin-bottom: 0.5em;
  --oow-etymology-panel-h1-size: 1.5em;
  --oow-etymology-panel-h2-size: 1.3em;
  --oow-etymology-panel-h3-size: 1.1em;

  /* 段落变量 */
  --oow-etymology-panel-paragraph-margin-bottom: 0.8em;
  --oow-etymology-panel-paragraph-line-height: 1.6;
  --oow-etymology-panel-paragraph-color: inherit;

  /* 列表变量 */
  --oow-etymology-panel-list-padding-left: 0;
  --oow-etymology-panel-list-margin-bottom: 1em;
  --oow-etymology-panel-list-item-margin-bottom: 0.4em;
  --oow-etymology-panel-list-item-color: inherit;

  /* 代码变量 */
  --oow-etymology-panel-code-bg: rgba(0,0,0,0.1);
  --oow-etymology-panel-code-border-radius: 4px;
  --oow-etymology-panel-code-padding: 2px 4px;
  --oow-etymology-panel-code-font-family: monospace;
  --oow-etymology-panel-code-color: inherit;
  --oow-etymology-panel-code-font-size: 0.9em;

  /* 预格式化文本变量 */
  --oow-etymology-panel-pre-bg: rgba(0,0,0,0.1);
  --oow-etymology-panel-pre-border-radius: 6px;
  --oow-etymology-panel-pre-padding: 12px;
  --oow-etymology-panel-pre-white-space: pre-wrap;
  --oow-etymology-panel-pre-word-break: break-all;

  /* 引用块变量 */
  --oow-etymology-panel-blockquote-border-left: 3px solid var(--accent-1);
  --oow-etymology-panel-blockquote-padding-left: 12px;
  --oow-etymology-panel-blockquote-margin-left: 0;
  --oow-etymology-panel-blockquote-color: var(--muted);
  --oow-etymology-panel-blockquote-font-style: normal;

  /* 错误信息变量 */
  --oow-etymology-panel-error-color: #ff6b6b;
  --oow-etymology-panel-error-weight: bold;
  --oow-etymology-panel-error-font-size: inherit;
  --oow-etymology-panel-error-margin: 10px 0;

  /* 流式错误指示器变量 */
  --oow-etymology-panel-stream-error-color: #f44336;
  --oow-etymology-panel-stream-error-padding: 5px;
  --oow-etymology-panel-stream-error-margin: 5px 0;
  --oow-etymology-panel-stream-error-border-left: 3px solid #f44336;
  --oow-etymology-panel-stream-error-background: transparent;
  --oow-etymology-panel-stream-error-font-size: 0.9em;

  /* 内容结束标记变量 */
  --oow-etymology-panel-end-marker-height: 1px;
  --oow-etymology-panel-end-marker-bg: linear-gradient(to right, transparent, #ccc, transparent);
  --oow-etymology-panel-end-marker-margin: 10px 0;
  --oow-etymology-panel-end-marker-opacity: 0.3;
  --oow-etymology-panel-end-marker-width: 100%;

  /* 加载状态变量 */
  --oow-etymology-panel-loading-opacity: 0.7;
  --oow-etymology-panel-loading-filter: blur(1px);
  --oow-etymology-panel-loading-pointer-events: none;

  /* 空状态变量 */
  --oow-etymology-panel-empty-text: 'No etymology information available';
  --oow-etymology-panel-empty-color: var(--muted);
  --oow-etymology-panel-empty-font-style: italic;
  --oow-etymology-panel-empty-text-align: center;
  --oow-etymology-panel-empty-padding: 0;

  /* 链接变量 */
  --oow-etymology-panel-link-color: var(--accent-1);
  --oow-etymology-panel-link-decoration: underline;
  --oow-etymology-panel-link-hover-color: var(--accent-2);
  --oow-etymology-panel-link-hover-decoration: none;
  --oow-etymology-panel-link-transition: color 0.2s ease;

  /* 强调文本变量 */
  --oow-etymology-panel-strong-weight: bold;
  --oow-etymology-panel-strong-color: inherit;
  --oow-etymology-panel-em-style: italic;
  --oow-etymology-panel-em-color: inherit;

  /* 水平线变量 */
  --oow-etymology-panel-hr-height: 1px;
  --oow-etymology-panel-hr-bg: var(--ring);
  --oow-etymology-panel-hr-margin: 1em 0;
  --oow-etymology-panel-hr-opacity: 0.5;

  /* 高亮变量 */
  --oow-etymology-panel-highlight-bg: var(--accent-2);
  --oow-etymology-panel-highlight-color: var(--panel-bg);
  --oow-etymology-panel-highlight-border-radius: 3px;
  --oow-etymology-panel-highlight-padding: 0px 3px;
`,ht=`
  /* 响应式设计变量 */
  --oow-etymology-panel-mobile-padding: 0;
  --oow-etymology-panel-mobile-font-size: 0.95em;
  --oow-etymology-panel-tablet-padding: 0;
  --oow-etymology-panel-tablet-font-size: 1em;
  --oow-etymology-panel-desktop-padding: 0;
  --oow-etymology-panel-desktop-font-size: 1.05em;
  --oow-etymology-panel-breakpoint-mobile: 480px;
  --oow-etymology-panel-breakpoint-tablet: 768px;
  --oow-etymology-panel-breakpoint-desktop: 1024px;

  /* 深色模式支持 */
  --oow-etymology-panel-dark-code-bg: rgba(255,255,255,0.1);
  --oow-etymology-panel-dark-pre-bg: rgba(255,255,255,0.1);
  --oow-etymology-panel-dark-blockquote-color: #ccc;
  --oow-etymology-panel-dark-hr-bg: rgba(255,255,255,0.2);

  /* 可访问性增强 */
  --oow-etymology-panel-focus-outline: 2px solid var(--accent-1);
  --oow-etymology-panel-focus-outline-offset: 2px;
  --oow-etymology-panel-high-contrast-text: #000;
  --oow-etymology-panel-high-contrast-bg: #fff;
  --oow-etymology-panel-screen-reader-only: none;

  /* 打印样式 */
  --oow-etymology-panel-print-color: #000;
  --oow-etymology-panel-print-bg: #fff;
  --oow-etymology-panel-print-font-size: 12pt;
  --oow-etymology-panel-print-line-height: 1.4;
  --oow-etymology-panel-print-hide-end-marker: true;

  /* 性能优化 */
  --oow-etymology-panel-will-change: auto;
  --oow-etymology-panel-transform: none;
  --oow-etymology-panel-backface-visibility: visible;
  --oow-etymology-panel-contain: layout;

  /* 内容分组样式 */
  --oow-etymology-panel-group-margin: 16px 0;
  --oow-etymology-panel-group-padding: 12px;
  --oow-etymology-panel-group-border: 1px solid rgba(0,0,0,0.05);
  --oow-etymology-panel-group-border-radius: 8px;
  --oow-etymology-panel-group-bg: rgba(0,0,0,0.02);

  /* 微交互增强 */
  --oow-etymology-panel-hover-transform: translateY(-1px);
  --oow-etymology-panel-hover-shadow: 0 2px 8px rgba(0,0,0,0.1);
  --oow-etymology-panel-transition-quick: 0.15s ease;
  --oow-etymology-panel-transition-smooth: 0.3s ease;

  /* 无障碍访问 */
  --oow-etymology-panel-role: region;
  --oow-etymology-panel-aria-label: 'Etymology content';
  --oow-etymology-panel-aria-live: polite;
  --oow-etymology-panel-aria-busy: false;
}

/* 应用变量到组件 */
.etymology-panel {
  background: var(--oow-etymology-panel-bg);
  padding: var(--oow-etymology-panel-padding);
  margin: var(--oow-etymology-panel-margin);
  min-height: var(--oow-etymology-panel-min-height);
  display: var(--oow-etymology-panel-display);
  font-family: var(--oow-etymology-panel-font-family);
  line-height: var(--oow-etymology-panel-line-height);
  color: var(--oow-etymology-panel-color);
  transition: var(--oow-etymology-panel-transition);
  will-change: var(--oow-etymology-panel-will-change);
  transform: var(--oow-etymology-panel-transform);
  backface-visibility: var(--oow-etymology-panel-backface-visibility);
  contain: var(--oow-etymology-panel-contain);
  /* 继承Info Panel的变量系统 */
  --oow-info-panel-heading-color: var(--oow-etymology-panel-heading-color);
  --oow-info-panel-heading-weight: var(--oow-etymology-panel-heading-weight);
  --oow-info-panel-heading-margin-top: var(--oow-etymology-panel-heading-margin-top);
  --oow-info-panel-heading-margin-bottom: var(--oow-etymology-panel-heading-margin-bottom);
  --oow-info-panel-paragraph-color: var(--oow-etymology-panel-paragraph-color);
  --oow-info-panel-paragraph-margin-bottom: var(--oow-etymology-panel-paragraph-margin-bottom);
  --oow-info-panel-line-height: var(--oow-etymology-panel-line-height);
  --oow-info-panel-letter-spacing: 0;
  --oow-info-panel-font-family: var(--oow-etymology-panel-font-family);
  --oow-info-panel-list-color: var(--oow-etymology-panel-list-item-color);
  --oow-info-panel-blockquote-color: var(--oow-etymology-panel-blockquote-color);
  --oow-info-panel-blockquote-border: var(--oow-etymology-panel-blockquote-border-left);
  --oow-info-panel-code-color: var(--oow-etymology-panel-code-color);
  --oow-info-panel-code-bg: var(--oow-etymology-panel-code-bg);
  --oow-info-panel-link-color: var(--oow-etymology-panel-link-color);
  --oow-info-panel-link-hover: var(--oow-etymology-panel-link-hover-color);
}

/* 内容区域 */
.etymology-panel-content {
  padding: var(--oow-etymology-panel-content-padding);
  background: var(--oow-etymology-panel-content-bg);
  border: var(--oow-etymology-panel-content-border);
  border-radius: var(--oow-etymology-panel-content-border-radius);
  max-width: var(--oow-etymology-panel-content-max-width);
  box-sizing: var(--oow-etymology-panel-content-box-sizing);
}

/* 标题样式 */
.etymology-panel h1,
.etymology-panel h2,
.etymology-panel h3,
.etymology-panel h4,
.etymology-panel h5,
.etymology-panel h6 {
  font-weight: var(--oow-etymology-panel-heading-weight);
  color: var(--oow-etymology-panel-heading-color);
  margin-top: var(--oow-etymology-panel-heading-margin-top);
  margin-bottom: var(--oow-etymology-panel-heading-margin-bottom);
}

.etymology-panel h1 { font-size: var(--oow-etymology-panel-h1-size); }
.etymology-panel h2 { font-size: var(--oow-etymology-panel-h2-size); }
.etymology-panel h3 { font-size: var(--oow-etymology-panel-h3-size); }

/* 段落样式 */
.etymology-panel p {
  margin-bottom: var(--oow-etymology-panel-paragraph-margin-bottom);
  line-height: var(--oow-etymology-panel-paragraph-line-height);
  color: var(--oow-etymology-panel-paragraph-color);
}

/* 列表样式 */
.etymology-panel ul,
.etymology-panel ol {
  padding-left: var(--oow-etymology-panel-list-padding-left);
  margin-bottom: var(--oow-etymology-panel-list-margin-bottom);
}

.etymology-panel li {
  margin-bottom: var(--oow-etymology-panel-list-item-margin-bottom);
  color: var(--oow-etymology-panel-list-item-color);
}

/* 代码样式 */
.etymology-panel code {
  background-color: var(--oow-etymology-panel-code-bg);
  border-radius: var(--oow-etymology-panel-code-border-radius);
  padding: var(--oow-etymology-panel-code-padding);
  font-family: var(--oow-etymology-panel-code-font-family);
  color: var(--oow-etymology-panel-code-color);
  font-size: var(--oow-etymology-panel-code-font-size);
}

.etymology-panel pre {
  background-color: var(--oow-etymology-panel-pre-bg);
  border-radius: var(--oow-etymology-panel-pre-border-radius);
  padding: var(--oow-etymology-panel-pre-padding);
  white-space: var(--oow-etymology-panel-pre-white-space);
  word-break: var(--oow-etymology-panel-pre-word-break);
}

/* 引用样式 */
.etymology-panel blockquote {
  border-left: var(--oow-etymology-panel-blockquote-border-left);
  padding-left: var(--oow-etymology-panel-blockquote-padding-left);
  margin-left: var(--oow-etymology-panel-blockquote-margin-left);
  color: var(--oow-etymology-panel-blockquote-color);
  font-style: var(--oow-etymology-panel-blockquote-font-style);
}

/* 错误消息样式 */
.etymology-panel .error-message {
  color: var(--oow-etymology-panel-error-color);
  font-weight: var(--oow-etymology-panel-error-weight);
  font-size: var(--oow-etymology-panel-error-font-size);
  margin: var(--oow-etymology-panel-error-margin);
}

/* 流式错误指示器样式 */
.etymology-panel .stream-error-indicator {
  color: var(--oow-etymology-panel-stream-error-color);
  padding: var(--oow-etymology-panel-stream-error-padding);
  margin: var(--oow-etymology-panel-stream-error-margin);
  border-left: var(--oow-etymology-panel-stream-error-border-left);
  background: var(--oow-etymology-panel-stream-error-background);
  font-size: var(--oow-etymology-panel-stream-error-font-size);
}

/* 内容结束标记样式 */
.etymology-panel .content-end-marker {
  height: var(--oow-etymology-panel-end-marker-height);
  background: var(--oow-etymology-panel-end-marker-bg);
  margin: var(--oow-etymology-panel-end-marker-margin);
  opacity: var(--oow-etymology-panel-end-marker-opacity);
  width: var(--oow-etymology-panel-end-marker-width);
}

/* 加载状态样式 */
.etymology-panel.loading {
  opacity: var(--oow-etymology-panel-loading-opacity);
  filter: var(--oow-etymology-panel-loading-filter);
  pointer-events: var(--oow-etymology-panel-loading-pointer-events);
}

/* 空状态样式 */
.etymology-panel.empty::before {
  content: var(--oow-etymology-panel-empty-text);
  color: var(--oow-etymology-panel-empty-color);
  font-style: var(--oow-etymology-panel-empty-font-style);
  text-align: var(--oow-etymology-panel-empty-text-align);
  padding: var(--oow-etymology-panel-empty-padding);
  display: block;
}

/* 链接样式 */
.etymology-panel a {
  color: var(--oow-etymology-panel-link-color);
  text-decoration: var(--oow-etymology-panel-link-decoration);
  transition: var(--oow-etymology-panel-link-transition);
}

.etymology-panel a:hover {
  color: var(--oow-etymology-panel-link-hover-color);
  text-decoration: var(--oow-etymology-panel-link-hover-decoration);
}

/* 强调文本样式 */
.etymology-panel strong {
  font-weight: var(--oow-etymology-panel-strong-weight);
  color: var(--oow-etymology-panel-strong-color);
}

.etymology-panel em {
  font-style: var(--oow-etymology-panel-em-style);
  color: var(--oow-etymology-panel-em-color);
}

/* 分隔线样式 */
.etymology-panel hr {
  height: var(--oow-etymology-panel-hr-height);
  background: var(--oow-etymology-panel-hr-bg);
  margin: var(--oow-etymology-panel-hr-margin);
  opacity: var(--oow-etymology-panel-hr-opacity);
  border: none;
}

/* 高亮样式 */
.etymology-panel .highlight {
  background-color: var(--oow-etymology-panel-highlight-bg);
  color: var(--oow-etymology-panel-highlight-color);
  border-radius: var(--oow-etymology-panel-highlight-border-radius);
  padding: var(--oow-etymology-panel-highlight-padding);
}

/* 响应式设计 */
@media (max-width: 480px) {
  .etymology-panel {
    padding: var(--oow-etymology-panel-mobile-padding);
    font-size: var(--oow-etymology-panel-mobile-font-size);
  }
}

@media (min-width: 481px) and (max-width: 768px) {
  .etymology-panel {
    padding: var(--oow-etymology-panel-tablet-padding);
    font-size: var(--oow-etymology-panel-tablet-font-size);
  }
}

@media (min-width: 769px) {
  .etymology-panel {
    padding: var(--oow-etymology-panel-desktop-padding);
    font-size: var(--oow-etymology-panel-desktop-font-size);
  }
}

/* 深色模式支持 */
@media (prefers-color-scheme: dark) {
  .etymology-panel code {
    background-color: var(--oow-etymology-panel-dark-code-bg, rgba(255,255,255,0.1));
  }

  .etymology-panel pre {
    background-color: var(--oow-etymology-panel-dark-pre-bg, rgba(255,255,255,0.1));
  }

  .etymology-panel blockquote {
    color: var(--oow-etymology-panel-dark-blockquote-color, #ccc);
  }

  .etymology-panel hr {
    background: var(--oow-etymology-panel-dark-hr-bg, rgba(255,255,255,0.2));
  }
}

/* 可访问性增强 */
.etymology-panel:focus {
  outline: var(--oow-etymology-panel-focus-outline);
  outline-offset: var(--oow-etymology-panel-focus-outline-offset);
}

@media (prefers-contrast: high) {
  .etymology-panel {
    color: var(--oow-etymology-panel-high-contrast-text);
    background: var(--oow-etymology-panel-high-contrast-bg);
  }
}

.etymology-panel .sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
  display: var(--oow-etymology-panel-screen-reader-only);
}

/* 打印样式 */
@media print {
  .etymology-panel {
    color: var(--oow-etymology-panel-print-color);
    background: var(--oow-etymology-panel-print-bg);
    font-size: var(--oow-etymology-panel-print-font-size);
    line-height: var(--oow-etymology-panel-print-line-height);
  }

  .etymology-panel .content-end-marker {
    display: var(--oow-etymology-panel-print-hide-end-marker, none);
  }
}

/* 微交互增强 */
.etymology-panel:hover {
  transform: var(--oow-etymology-panel-hover-transform);
  box-shadow: var(--oow-etymology-panel-hover-shadow);
  transition: var(--oow-etymology-panel-transition-smooth);
}

/* 内容分组样式 */
.etymology-panel .content-group {
  margin: var(--oow-etymology-panel-group-margin);
  padding: var(--oow-etymology-panel-group-padding);
  border: var(--oow-etymology-panel-group-border);
  border-radius: var(--oow-etymology-panel-group-border-radius);
  background: var(--oow-etymology-panel-group-bg);
}

/* 无障碍访问属性 */
.etymology-panel[role="region"] {
  role: var(--oow-etymology-panel-role);
}

.etymology-panel[aria-label] {
  aria-label: var(--oow-etymology-panel-aria-label);
}

.etymology-panel[aria-live] {
  aria-live: var(--oow-etymology-panel-aria-live);
}

.etymology-panel[aria-busy="true"] {
  aria-busy: var(--oow-etymology-panel-aria-busy);
}/*
 * /components/markdown-highlight.css
 *
 * Highlight System
 *
 * This file styles semantic HTML elements generated by streaming-markdown
 * to make them visually distinct, creating a cohesive "highlight" experience
 * without a dedicated .highlight class.
 */

/* --- Headings --- */
.part2-content h1, .part2-content h2, .part2-content h3, .part2-content h4, .part2-content h5, .part2-content h6 {
  color: var(--oow-highlight-heading-color);
  font-weight: var(--oow-highlight-heading-font-weight);
  margin-top: var(--oow-highlight-heading-margin-top);
  margin-bottom: var(--oow-highlight-heading-margin-bottom);
}

.part2-content h1 { font-size: var(--oow-highlight-h1-font-size); }
.part2-content h2 { font-size: var(--oow-highlight-h2-font-size); }
.part2-content h3 { font-size: var(--oow-highlight-h3-font-size); }
.part2-content h4 { font-size: var(--oow-highlight-h4-font-size); }
.part2-content h5 { font-size: var(--oow-highlight-h5-font-size); }
.part2-content h6 { font-size: var(--oow-highlight-h6-font-size); }

/* --- Strong / Bold --- */
/* Styles for **text** or __text__ */
.part2-content strong {
  color: var(--oow-highlight-strong-color);
  font-weight: var(--oow-highlight-strong-font-weight);
  text-shadow: var(--oow-highlight-strong-text-shadow);
  transition: var(--oow-highlight-transition);
}

.part2-content strong:hover {
  text-shadow: var(--oow-highlight-strong-glow);
  transform: var(--oow-highlight-hover-scale);
}

/* --- Emphasis / Italic --- */
/* Styles for *text* or _text_ */
.part2-content em {
  color: var(--oow-highlight-em-color);
  font-style: var(--oow-highlight-em-font-style);
  transition: var(--oow-highlight-transition);
}

.part2-content em:hover {
  text-shadow: var(--oow-highlight-em-glow);
}

/* --- Inline Code --- */
/* Styles for \`code\` */
/* Targets <code> within <p> or <li> to avoid styling <pre><code> blocks */
.part2-content p > code,
.part2-content li > code {
  color: var(--oow-highlight-code-color);
  background-color: var(--oow-highlight-code-bg);
  border: 1px solid var(--oow-highlight-code-border-color);
  padding: var(--oow-code-padding);
  border-radius: var(--oow-code-border-radius);
  font-family: var(--oow-highlight-code-font-family);
  font-size: var(--oow-highlight-code-font-size);
  transition: var(--oow-highlight-transition);
}

.part2-content p > code:hover,
.part2-content li > code:hover {
  box-shadow: var(--oow-highlight-code-glow);
}

/* --- Links --- */
/* Styles for [text](url) */
.part2-content a {
  color: var(--oow-highlight-link-color);
  text-decoration: var(--oow-highlight-link-decoration);
  text-decoration-thickness: var(--oow-highlight-link-decoration-thickness);
  text-underline-offset: var(--oow-highlight-link-decoration-offset);
  transition: var(--oow-highlight-transition);
  border-radius: var(--radius-base);
}

.part2-content a:hover {
  color: var(--oow-highlight-link-hover-color);
  background-color: var(--oow-highlight-link-hover-bg);
  transform: var(--oow-highlight-link-hover-transform);
}

/* --- Blockquotes --- */
.part2-content blockquote {
  margin: var(--oow-highlight-blockquote-margin);
  padding: var(--oow-highlight-blockquote-padding);
  border-left: var(--oow-highlight-blockquote-border-left);
  color: var(--oow-highlight-blockquote-color);
  background-color: var(--oow-highlight-blockquote-bg);
}

/* --- Horizontal Rules --- */
.part2-content hr {
  border: 0;
  height: var(--oow-highlight-hr-height);
  background-color: var(--oow-highlight-hr-bg);
  margin: var(--oow-highlight-hr-margin);
}

/* --- Preformatted Text --- */
.part2-content pre {
  padding: var(--oow-highlight-pre-padding);
  background-color: var(--oow-highlight-pre-bg);
  border-radius: var(--oow-highlight-pre-border-radius);
  font-family: var(--oow-highlight-pre-font-family);
  font-size: var(--oow-highlight-pre-font-size);
  white-space: pre-wrap;
  word-break: break-all;
}

/* --- Tables --- */
.part2-content table {
  width: 100%;
  border-collapse: collapse;
  margin: var(--oow-highlight-table-margin);
}

.part2-content th, .part2-content td {
  border: var(--oow-highlight-table-border);
  padding: var(--oow-highlight-table-cell-padding);
  text-align: left;
}

.part2-content th {
  background-color: var(--oow-highlight-table-header-bg);
  color: var(--oow-highlight-table-header-color);
  font-weight: var(--oow-highlight-table-header-font-weight);
}

/* --- List Markers --- */
/* Styles for <ul>, <ol>, <li> */
.part2-content ul,
.part2-content ol {
`,gt=`  /* Using existing padding from modal.css */
  margin: 0.8em 0;
}

.part2-content li {
  padding-left: 0.5em;
}

/* Style the bullet points or numbers */
.part2-content li::marker {
  color: var(--oow-highlight-marker-color);
  font-weight: bold;
}
/* 组件特定CSS变量 - 设计师创作接口 */
.pcss3t {
  /* 基础间距变量 */
  --oow-tabs-margin: 0;
  --oow-tabs-max-width: 100%;
  --oow-tab-padding-y: 8px;
  --oow-tab-padding-x: 12px;
  --oow-tab-gap: 16px;
  --oow-content-padding: 16px;

  /* 字体系统变量 */
  --oow-tabs-font-family: inherit;
  --oow-tabs-font-size: 14px;
  --oow-tabs-line-height: 1.4;
  --oow-tabs-font-weight-base: 500;

  /* 颜色系统变量 (使用全局主题变量) */
  --oow-tabs-text-color: var(--text-color);
  --oow-tabs-text-muted: var(--muted);
  --oow-tabs-bg: transparent;
  --oow-tabs-bg-hover: rgba(255, 255, 255, 0.05);
  --oow-tabs-bg-active: transparent;
  --oow-tabs-content-bg: var(--panel-bg);
  --oow-tabs-border-color: var(--ring);
  --oow-tabs-accent-color: var(--accent-1);

  /* 边框和阴影变量 */
  --oow-tabs-border-width: 1px;
  --oow-tabs-active-border-width: 3px;
  --oow-tabs-border-radius: 8px;
  --oow-tabs-shadow: none;
  --oow-tabs-shadow-active: inset 0 -2px 4px rgba(0, 0, 0, 0.1);
  --oow-tabs-bg-active: rgba(255, 255, 255, 0.02);

  /* 动画和过渡变量 */
  --oow-tabs-transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  --oow-tabs-opacity-transition: opacity 0.3s ease;
  --oow-tabs-transform-transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  --oow-tabs-transform-scale: 0.95;
  --oow-tabs-transform-scale-active: 1;

  /* 焦点和交互变量 */
  --oow-tabs-focus-outline: 2px solid var(--oow-tabs-accent-color);
  --oow-tabs-focus-outline-offset: -2px;
  --oow-tabs-cursor: pointer;
  --oow-tabs-cursor-active: pointer;

  /* 响应式断点变量 */
  --oow-tabs-mobile-breakpoint: 600px;
  --oow-tabs-mobile-font-size: 14px;
  --oow-tabs-mobile-padding-y: 8px;
  --oow-tabs-mobile-padding-x: 10px;
}

/* 基础tabs容器样式 */
.pcss3t {
  position: relative;
  margin: var(--oow-tabs-margin);
  width: 100%;
  max-width: var(--oow-tabs-max-width);
  font-family: var(--oow-tabs-font-family);
  font-size: var(--oow-tabs-font-size);
  line-height: var(--oow-tabs-line-height);
  color: var(--oow-tabs-text-color);
  text-align: left;
  border-bottom: var(--oow-tabs-border-width) solid var(--oow-tabs-border-color);
}

/* 隐藏radio按钮 */
.pcss3t > input {
  display: none;
}

/* 标签按钮样式 */
.pcss3t > label {
  display: inline-block;
  margin: 0 var(--oow-tab-gap) 0 0;
  padding: var(--oow-tab-padding-y) var(--oow-tab-padding-x);
  font-size: var(--oow-tabs-font-size-base);
  font-weight: var(--oow-tabs-font-weight-base);
  text-align: center;
  color: var(--oow-tabs-text-muted);
  background: var(--oow-tabs-bg);
  border: none;
  border-bottom: var(--oow-tabs-active-border-width) solid transparent;
  margin-bottom: calc(-1 * var(--oow-tabs-border-width));
  border-radius: var(--oow-tabs-border-radius) var(--oow-tabs-border-radius) 0 0;
  cursor: var(--oow-tabs-cursor);
  transition: var(--oow-tabs-transition);
  user-select: none;
  position: relative;
  z-index: 1;
}

.pcss3t > label:hover {
  color: var(--oow-tabs-text-color);
  transform: none;
  box-shadow: none;
  z-index: 1;
}

/* 选中状态的标签按钮 */
.pcss3t > input:checked + label {
  color: var(--oow-tabs-accent-color);
  font-weight: 600;
  background: var(--oow-tabs-bg);
  border-bottom-color: var(--oow-tabs-accent-color);
  cursor: var(--oow-tabs-cursor-active);
  box-shadow: none;
  transform: none;
  z-index: 1;
}

/* 状态指示器 - 使用伪元素创建直观的状态条 */
.pcss3t > input:checked + label::after {
  content: '';
  position: absolute;
  bottom: calc(-1 * var(--oow-tabs-active-border-width) - 1px);
  left: 50%;
  transform: translateX(-50%);
  width: 80%;
  height: 2px;
  background: var(--oow-tabs-accent-color);
  border-radius: 1px;
  opacity: 0.8;
  animation: tab-state-indicator 0.3s ease-out;
}

@keyframes tab-state-indicator {
  0% {
    width: 0%;
    opacity: 0;
  }
  100% {
    width: 80%;
    opacity: 0.8;
  }
}

/* 内容区域样式 */
.pcss3t > ul {
  position: relative;
  display: block;
  padding: 0;
  background: var(--oow-tabs-content-bg);
  border: none;
  list-style: none;
  margin: 0;
}

/* 内容面板样式 */
.pcss3t > ul > li {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  display: none;
  padding: 0;
  opacity: 0;
  transition: var(--oow-tabs-opacity-transition);
}

/* 选中状态的内容面板 */
.pcss3t > .tab-content-first:checked ~ ul > .tab-content-first,
.pcss3t > .tab-content-2:checked ~ ul > .tab-content-2,
.pcss3t > .tab-content-3:checked ~ ul > .tab-content-3,
.pcss3t > .tab-content-last:checked ~ ul > .tab-content-last {
  display: block;
  position: relative;
  opacity: 1;
  z-index: 1;
}

/* Typography样式 (使用主题变量) */
.typography {
  font-size: 14px;
  line-height: 1.6;
  color: var(--text-color);
}

.typography h1,
.typography h2,
.typography h3,
.typography h4,
.typography h5,
.typography h6 {
  margin: 0 0 15px 0;
  font-weight: 600;
  color: var(--text-color);
}

.typography h1 { font-size: 24px; }
.typography h2 { font-size: 20px; }
.typography h3 { font-size: 18px; }

.typography p {
  margin: 0 0 15px 0;
}

.typography a {
  color: var(--accent-1);
  text-decoration: none;
}

.typography a:hover {
  text-decoration: underline;
}

/* 主题化tab设计 - 每个主题都有独特的视觉语言 */

/* Basic主题 - 极简平面风格 */
.oow-popover[data-theme="basic"] .pcss3t > label {
  color: #666666;
}

.oow-popover[data-theme="basic"] .pcss3t > label:hover {
  color: #333333;
}

.oow-popover[data-theme="basic"] .pcss3t > input:checked + label {
  color: #0ea5e9;
  font-weight: 600;
}

.oow-popover[data-theme="basic"] .pcss3t > input:checked + label::after {
  background: linear-gradient(90deg, #0ea5e9, #22c55e);
  height: 3px;
}

/* Pro主题 - 专业立体风格 */
.oow-popover[data-theme="pro"] .pcss3t > label {
  color: #9ca3af;
  font-weight: 500;
}

.oow-popover[data-theme="pro"] .pcss3t > label:hover {
  color: #f9fafb;
  background: rgba(59, 130, 246, 0.1);
  border-radius: 6px 6px 0 0;
}

.oow-popover[data-theme="pro"] .pcss3t > input:checked + label {
  color: #3b82f6;
  font-weight: 600;
  background: rgba(59, 130, 246, 0.15);
  border-radius: 6px 6px 0 0;
}

.oow-popover[data-theme="pro"] .pcss3t > input:checked + label::after {
  background: linear-gradient(90deg, #3b82f6, #10b981);
  height: 4px;
  box-shadow: 0 2px 4px rgba(59, 130, 246, 0.3);
}

/* Creative主题 - 艺术创意风格 */
.oow-popover[data-theme="creative"] .pcss3t > label {
  color: #718096;
  font-style: italic;
  border: 2px dashed transparent;
  border-radius: 10px 10px 0 0;
}

.oow-popover[data-theme="creative"] .pcss3t > label:hover {
  color: #2d3748;
  border: 2px dashed #ed8936;
  background: rgba(255, 255, 255, 0.8);
}

.oow-popover[data-theme="creative"] .pcss3t > input:checked + label {
  color: #ed8936;
  font-weight: 700;
  font-style: normal;
  background: linear-gradient(135deg, #ed8936, #4299e1, #9f7aea);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  border: 2px solid #ed8936;
  border-radius: 10px 10px 0 0;
}

.oow-popover[data-theme="creative"] .pcss3t > input:checked + label::after {
  background: linear-gradient(90deg, #ed8936, #4299e1, #9f7aea);
  height: 3px;
  border-radius: 2px;
}

/* Aurora主题 - 梦幻光效风格 */
.oow-popover[data-theme="aurora"] .pcss3t > label {
  color: #a5b4fc;
  text-shadow: none;
  position: relative;
  overflow: hidden;
}

.oow-popover[data-theme="aurora"] .pcss3t > label::before {
  content: '';
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: radial-gradient(circle at 20% 30%, rgba(159, 122, 234, 0.1) 0px, transparent 50px);
  opacity: 0;
  transition: opacity 0.3s ease;
}

.oow-popover[data-theme="aurora"] .pcss3t > label:hover::before {
  opacity: 1;
}

.oow-popover[data-theme="aurora"] .pcss3t > label:hover {
  color: #c084fc;
  text-shadow: 0 0 8px rgba(159, 122, 234, 0.3);
}

.oow-popover[data-theme="aurora"] .pcss3t > input:checked + label {
  color: #4ade80;
  font-weight: 700;
  text-shadow: 0 0 12px rgba(74, 222, 128, 0.4);
  background: linear-gradient(135deg, #4ade80, #60a5fa, #f472b6, #fbbf24);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.oow-popover[data-theme="aurora"] .pcss3t > input:checked + label::after {
  background: linear-gradient(90deg, #4ade80, #60a5fa, #f472b6, #fbbf24);
  height: 4px;
  box-shadow: 0 2px 8px rgba(74, 222, 128, 0.4);
  animation: aurora-tab-indicator 2s ease-in-out infinite;
}

@keyframes aurora-tab-indicator {
  0%, 100% {
    transform: translateX(-50%) scaleX(0.8);
    box-shadow: 0 2px 8px rgba(74, 222, 128, 0.4);
  }
  50% {
    transform: translateX(-50%) scaleX(1);
    box-shadow: 0 2px 12px rgba(74, 222, 128, 0.6);
  }
}

/* Cyberpunk主题 - 科技霓虹风格 */
.oow-popover[data-theme="cyberpunk"] .pcss3t > label {
  color: #b5179e;
  font-family: 'Courier New', monospace;
  letter-spacing: 1px;
  background: rgba(114, 9, 183, 0.05);
  border-radius: 6px 6px 0 0;
}

.oow-popover[data-theme="cyberpunk"] .pcss3t > label:hover {
  color: #f72585;
  background: rgba(114, 9, 183, 0.1);
  box-shadow: 0 0 10px rgba(247, 37, 133, 0.2);
  text-shadow: 0 0 5px rgba(247, 37, 133, 0.3);
}

.oow-popover[data-theme="cyberpunk"] .pcss3t > input:checked + label {
  color: #ff006e;
  font-weight: 700;
  font-family: 'Orbitron', 'Courier New', monospace;
  letter-spacing: 2px;
  background: rgba(114, 9, 183, 0.2);
  border: 1px solid rgba(247, 37, 133, 0.3);
  border-radius: 6px 6px 0 0;
  text-shadow: 0 0 8px rgba(247, 37, 133, 0.4);
  box-shadow: 0 0 15px rgba(247, 37, 133, 0.3);
}

.oow-popover[data-theme="cyberpunk"] .pcss3t > input:checked + label::after {
  background: linear-gradient(90deg, #ff006e, #4361ee, #4cc9f0);
  height: 3px;
  box-shadow: 0 2px 6px rgba(247, 37, 133, 0.5);
  animation: cyberpunk-tab-pulse 1.5s ease-in-out infinite;
}

@keyframes cyberpunk-tab-pulse {
  0%, 100% {
    opacity: 0.7;
    transform: translateX(-50%) scaleX(0.9);
  }
  50% {
    opacity: 1;
    transform: translateX(-50%) scaleX(1.1);
  }
}

/* Galaxy主题 - 宇宙深邃风格 */
.oow-popover[data-theme="galaxy"] .pcss3t > label {
  color: #a5b4fc;
  background: rgba(129, 140, 248, 0.05);
  border-radius: 8px 8px 0 0;
}

.oow-popover[data-theme="galaxy"] .pcss3t > label:hover {
  color: #e0e7ff;
  background: rgba(129, 140, 248, 0.1);
  text-shadow: 0 0 5px rgba(192, 132, 252, 0.2);
}

.oow-popover[data-theme="galaxy"] .pcss3t > input:checked + label {
  color: #c084fc;
  font-weight: 700;
  background: linear-gradient(135deg, rgba(192, 132, 252, 0.15), rgba(232, 121, 249, 0.1));
  border-radius: 8px 8px 0 0;
  text-shadow: 0 0 10px rgba(192, 132, 252, 0.3);
  position: relative;
  overflow: hidden;
}

.oow-popover[data-theme="galaxy"] .pcss3t > input:checked + label::after {
  background: linear-gradient(90deg, #c084fc, #e879f9, #f472b6, #a78bfa);
  height: 4px;
  border-radius: 2px;
  box-shadow: 0 2px 8px rgba(192, 132, 252, 0.4);
  animation: galaxy-tab-stardust 3s linear infinite;
}

/* 添加星星效果 */
.oow-popover[data-theme="galaxy"] .pcss3t > input:checked + label::before {
  content: '';
  position: absolute;
  top: -10px;
  right: 10px;
  width: 4px;
  height: 4px;
  background: white;
  border-radius: 50%;
  box-shadow:
    20px 20px 0 2px white,
    40px 40px 0 1px white,
    -20px 30px 0 1px white;
  animation: galaxy-stars 15s linear infinite;
}

@keyframes galaxy-tab-stardust {
  0% {
    width: 0%;
    opacity: 0;
  }
  100% {
    width: 85%;
    opacity: 0.9;
  }
}

/* Neon主题 - 赛博朋克风格 */
.oow-popover[data-theme="neon"] .pcss3t > label {
  color: #00cc33;
  background: rgba(0, 255, 65, 0.05);
  border: 1px solid rgba(0, 255, 65, 0.1);
  border-radius: 6px 6px 0 0;
  text-shadow: none;
}

.oow-popover[data-theme="neon"] .pcss3t > label:hover {
  color: #00ff41;
  background: rgba(0, 255, 65, 0.1);
  border-color: rgba(0, 255, 65, 0.3);
  text-shadow: 0 0 6px rgba(0, 255, 65, 0.3);
  transform: none;
}

.oow-popover[data-theme="neon"] .pcss3t > input:checked + label {
  color: #ffbe0b;
  font-weight: 700;
  background: linear-gradient(135deg, rgba(255, 190, 11, 0.1), rgba(255, 0, 110, 0.1));
  border: 2px solid #ffbe0b;
  border-radius: 6px 6px 0 0;
  text-shadow: 0 0 10px rgba(255, 190, 11, 0.5), 0 0 20px rgba(255, 0, 110, 0.3);
  box-shadow: 0 0 20px rgba(255, 190, 11, 0.2);
  position: relative;
  overflow: hidden;
}

.oow-popover[data-theme="neon"] .pcss3t > input:checked + label::after {
  background: linear-gradient(90deg, #ffbe0b, #ff006e, #00d9ff);
  height: 4px;
  border-radius: 2px;
  box-shadow: 0 2px 10px rgba(255, 190, 11, 0.6);
  animation: neon-tab-glow 2s ease-in-out infinite;
}

/* 添加霓虹管效果 */
.oow-popover[data-theme="neon"] .pcss3t > input:checked + label::before {
  content: '';
  position: absolute;
`,_t=`  top: -2px;
  left: -2px;
  right: -2px;
  bottom: -2px;
  background: linear-gradient(135deg, rgba(255, 190, 11, 0.05), rgba(255, 0, 110, 0.05));
  border: 1px solid rgba(255, 190, 11, 0.2);
  border-radius: 8px 8px 0 0;
  z-index: -1;
}

@keyframes neon-tab-glow {
  0%, 100% {
    box-shadow: 0 2px 10px rgba(255, 190, 11, 0.6);
  }
  50% {
    box-shadow: 0 2px 15px rgba(255, 190, 11, 0.8);
  }
}

.pcss3t-effect-scale > .tab-content-first:checked ~ ul > .tab-content-first,
.pcss3t-effect-scale > .tab-content-2:checked ~ ul > .tab-content-2,
.pcss3t-effect-scale > .tab-content-3:checked ~ ul > .tab-content-3,
.pcss3t-effect-scale > .tab-content-last:checked ~ ul > .tab-content-last {
  transform: scale(var(--oow-tabs-transform-scale-active));
}

/* Theme-1样式 - 继承blue-print设计 */
.pcss3t-theme-1 > label {
  background: linear-gradient(to bottom, var(--oow-tabs-gradient-bg-start), var(--oow-tabs-gradient-bg-end));
  border-color: var(--oow-tabs-border-color);
  color: var(--oow-tabs-text-muted);
}

.pcss3t-theme-1 > label:hover {
  background: linear-gradient(to bottom, var(--oow-tabs-gradient-bg-hover-start), var(--oow-tabs-gradient-bg-hover-end));
  color: var(--oow-tabs-text-color);
}

.pcss3t-theme-1 > input:checked + label {
  background: linear-gradient(to bottom, var(--oow-tabs-gradient-bg-active-start), var(--oow-tabs-gradient-bg-active-end));
  color: var(--oow-tabs-text-color);
  border-color: var(--oow-tabs-border-color);
}

.pcss3t-theme-1 > ul {
  background: var(--oow-tabs-content-bg);
  border-color: var(--oow-tabs-border-color);
  box-shadow: var(--oow-tabs-shadow);
}

/* 响应式设计 */
@media (max-width: var(--oow-tabs-mobile-breakpoint)) {
  .pcss3t {
    font-size: var(--oow-tabs-mobile-font-size);
  }

  .pcss3t > label {
    padding: var(--oow-tabs-mobile-padding-y) var(--oow-tabs-mobile-padding-x);
    font-size: var(--oow-tabs-mobile-font-size-base);
  }

  .pcss3t > ul {
    padding: var(--oow-tabs-mobile-padding-y) var(--oow-tabs-mobile-padding-x);
  }

  .pcss3t > ul > li {
    padding: var(--oow-tabs-mobile-padding-y) var(--oow-tabs-mobile-padding-x);
  }
}

/* 无障碍访问增强 */
.pcss3t > label:focus {
  outline: var(--oow-tabs-focus-outline);
  outline-offset: var(--oow-tabs-focus-outline-offset);
}

/* 减少动画偏好 */
@media (prefers-reduced-motion: reduce) {
  .pcss3t > label,
  .pcss3t > ul > li,
  .pcss3t-effect-scale > ul > li {
    transition: none;
  }

  .pcss3t-effect-scale > ul > li {
    transform: none;
  }
}

/*
 * ===============================================
 * 设计师主题创作指南
 * ===============================================
 *
 * 1. 创建新主题: 只需覆盖CSS变量即可
 * 2. 支持的定制维度: 8大类 50+ 变量
 * 3. 示例主题创建:
 *
 * .oow-popover[data-theme="ocean"] .pcss3t {
 *   --oow-tabs-text-color: #0066cc;
 *   --oow-tabs-accent-color: #00aaff;
 *   --oow-tabs-bg: linear-gradient(135deg, #e6f3ff, #cce7ff);
 *   --oow-tabs-shadow: 0 4px 20px rgba(0, 102, 204, 0.2);
 *   --oow-tabs-border-radius: 8px;
 * }
 *
 * 4. 无障碍访问支持:
 *    - 键盘导航:focus样式可通过变量定制
 *    - 高对比度模式支持
 *    - 减少动画偏好支持
 *
 * 5. 响应式设计:
 *    - 移动端断点可通过变量调整
 *    - 触摸友好的间距和大小
 *//*
 * Tooltip Component Styles
 * 简洁优雅的tooltip样式，跟随主题变化
 */

/* Tooltip基础样式 - 使用CSS变量实现主题适配 */
.oow-tooltip {
  --tooltip-bg: rgba(0, 0, 0, 0.85);
  --tooltip-color: white;
  --tooltip-border: transparent;
  --tooltip-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);

  position: absolute;
  background: var(--tooltip-bg);
  color: var(--tooltip-color);
  border: 1px solid var(--tooltip-border);
  padding: 6px 10px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 500;
  line-height: 1.2;
  white-space: nowrap;
  z-index: 1000;
  opacity: 0;
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  pointer-events: none;
  box-shadow: var(--tooltip-shadow);
  top: calc(100% + 8px);
  left: 50%;
  transform: translateX(-50%);
}

/* Tooltip显示状态 */
.oow-tooltip.visible {
  opacity: 1;
}

/* Tooltip箭头指示器 */
.oow-tooltip::after {
  content: '';
  position: absolute;
  bottom: 100%;
  left: 50%;
  transform: translateX(-50%) rotate(45deg);
  width: 8px;
  height: 8px;
  background: var(--tooltip-bg);
  border: 1px solid var(--tooltip-border);
  z-index: -1;
}

/* 主题适配的tooltip样式 */
.oow-popover[data-theme="basic"] .oow-tooltip {
  --tooltip-bg: rgba(14, 165, 233, 0.9);
  --tooltip-color: white;
  --tooltip-border: rgba(14, 165, 233, 0.3);
  --tooltip-shadow: 0 4px 12px rgba(14, 165, 233, 0.2);
}

.oow-popover[data-theme="pro"] .oow-tooltip {
  --tooltip-bg: rgba(31, 41, 55, 0.95);
  --tooltip-color: rgba(249, 250, 251, 0.95);
  --tooltip-border: rgba(107, 114, 128, 0.4);
  --tooltip-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
}

.oow-popover[data-theme="creative"] .oow-tooltip {
  --tooltip-bg: rgba(237, 137, 54, 0.9);
  --tooltip-color: white;
  --tooltip-border: rgba(237, 137, 54, 0.5);
  --tooltip-shadow: 0 4px 16px rgba(237, 137, 54, 0.3);
}

.oow-popover[data-theme="aurora"] .oow-tooltip {
  --tooltip-bg: rgba(26, 26, 46, 0.95);
  --tooltip-color: rgba(240, 248, 255, 0.95);
  --tooltip-border: rgba(167, 139, 250, 0.4);
  --tooltip-shadow: 0 4px 16px rgba(167, 139, 250, 0.3);
}

.oow-popover[data-theme="cyberpunk"] .oow-tooltip {
  --tooltip-bg: rgba(10, 1, 26, 0.95);
  --tooltip-color: rgba(247, 37, 133, 0.9);
  --tooltip-border: rgba(114, 9, 183, 0.5);
  --tooltip-shadow: 0 4px 16px rgba(247, 37, 133, 0.4);
}

.oow-popover[data-theme="galaxy"] .oow-tooltip {
  --tooltip-bg: rgba(8, 10, 32, 0.95);
  --tooltip-color: rgba(224, 231, 255, 0.95);
  --tooltip-border: rgba(129, 140, 248, 0.4);
  --tooltip-shadow: 0 4px 16px rgba(192, 132, 252, 0.3);
}

.oow-popover[data-theme="neon"] .oow-tooltip {
  --tooltip-bg: rgba(0, 0, 0, 0.95);
  --tooltip-color: rgba(0, 255, 65, 0.95);
  --tooltip-border: rgba(0, 255, 65, 0.6);
  --tooltip-shadow: 0 4px 16px rgba(0, 255, 65, 0.4);
}/*
 * Collapsible Section Component
 * 可折叠内容区域组件
 */

/* 组件专用变量 - 设计师主题创作接口 */
.collapsible-section {
  /* 整体布局 */
  --oow-collapsible-section-padding: var(--spacing-3);
  --oow-collapsible-section-border-radius: var(--radius-md);
  --oow-collapsible-section-gap: var(--spacing-2);
  --oow-collapsible-section-transition: var(--oow-animation-base, 0.25s);

  /* 头部样式 */
  --oow-collapsible-section-header-padding: var(--spacing-2) var(--spacing-4);
  --oow-collapsible-section-header-gap: var(--spacing-2);
  --oow-collapsible-section-header-bg: transparent;
  --oow-collapsible-section-header-border: none;
  --oow-collapsible-section-header-border-radius: 0;

  /* 标题样式 */
  --oow-collapsible-section-title-size: 1.2em;  /* 保持原始大小 */
  --oow-collapsible-section-title-weight: 700;  /* 保持原始字重 */
  --oow-collapsible-section-title-color: var(--text-color);  /* 保持原始颜色 */
  --oow-collapsible-section-title-letter-spacing: normal;
  --oow-collapsible-section-title-text-shadow: 0 1px 0 rgba(0,0,0,0.4);  /* 保持原始阴影 */

  /* 音标样式 */
  --oow-collapsible-section-phonetic-size: 1.2em;  /* 保持原始大小 */
  --oow-collapsible-section-phonetic-color: #555;  /* 保持原始颜色 */
  --oow-collapsible-section-phonetic-margin-left: var(--spacing-1);

  /* 发音按钮样式 */
  --oow-collapsible-section-speaker-font-size: 16px;  /* 保持原始字体大小 */
  --oow-collapsible-section-speaker-bg: none;  /* 保持原始背景 */
  --oow-collapsible-section-speaker-border: none;  /* 保持原始边框 */
  --oow-collapsible-section-speaker-cursor: pointer;  /* 保持原始鼠标样式 */
  --oow-collapsible-section-speaker-padding: 0;  /* 保持原始内边距 */

  /* 切换按钮样式 */
  --oow-collapsible-section-toggle-size: 24px;
  --oow-collapsible-section-toggle-color: var(--oow-muted);
  --oow-collapsible-section-toggle-hover-color: var(--oow-accent-primary);
  --oow-collapsible-section-toggle-padding: var(--spacing-1);
  --oow-collapsible-section-toggle-border-radius: var(--radius-sm);
  --oow-collapsible-section-toggle-bg: transparent;
  --oow-collapsible-section-toggle-hover-bg: var(--oow-bg-secondary);
  --oow-collapsible-section-toggle-transition: var(--oow-animation-fast, 0.15s);
  --oow-collapsible-section-toggle-icon-size: 12px;

  /* 内容区域样式 */
  --oow-collapsible-section-content-padding: var(--spacing-3) var(--spacing-4);  /* 保持原始内边距 */
  --oow-collapsible-section-content-transition: opacity var(--oow-animation-base, 0.25s) ease-out;  /* 保持原始过渡 */
  --oow-collapsible-section-content-overflow: visible;  /* 保持原始溢出设置 */
  --oow-collapsible-section-content-opacity: 1;  /* 保持原始透明度 */
  --oow-collapsible-section-content-box-sizing: border-box;  /* 保持原始盒模型 */
  --oow-collapsible-section-content-max-width: 100%;  /* 保持原始最大宽度 */

  /* 折叠状态样式 */
  --oow-collapsible-section-collapsed-content-max-height: 0;
  --oow-collapsible-section-collapsed-content-opacity: 0;
  --oow-collapsible-section-collapsed-toggle-rotation: -90deg;

  /* 展开状态样式 */
  --oow-collapsible-section-expanded-content-max-height: var(--oow-collapsible-section-content-max-height);
  --oow-collapsible-section-expanded-content-opacity: 1;
  --oow-collapsible-section-expanded-toggle-rotation: 0deg;

  /* 布局对齐方式 */
  --oow-collapsible-section-header-justify-content: space-between;
  --oow-collapsible-section-header-align-items: center;
  --oow-collapsible-section-header-left-align-items: center;
  --oow-collapsible-section-header-right-align-items: center;

  /* 动画缓动函数 */
  --oow-collapsible-section-transition-easing: ease-in-out;
  --oow-collapsible-section-toggle-transition-easing: ease-in-out;  /* 保持原始缓动函数 */

  /* SVG 图标定制 */
  --oow-collapsible-section-toggle-svg-width: 12;
  --oow-collapsible-section-toggle-svg-height: 12;
  --oow-collapsible-section-toggle-svg-viewbox: 0 0 12 12;
  --oow-collapsible-section-toggle-svg-path: 'M3 4.5L6 7.5L9 4.5';
  --oow-collapsible-section-toggle-svg-stroke-width: 1.5;
  --oow-collapsible-section-toggle-svg-stroke-linecap: round;
  --oow-collapsible-section-toggle-svg-stroke-linejoin: round;

  /* 交互细节 */
  --oow-collapsible-section-pointer-events-collapsed: none;
  --oow-collapsible-section-pointer-events-expanded: auto;

  /* 可访问性 */
  --oow-collapsible-section-aria-label-toggle: 'Toggle section';
  --oow-collapsible-section-aria-label-speaker: 'Pronounce';

  /* 初始状态 */
  --oow-collapsible-section-initial-state: expanded; /* expanded | collapsed */

  /* 按钮行为 */
  --oow-collapsible-section-toggle-stop-propagation: true;
}

/* 应用变量到组件 */
.collapsible-section {
  padding: var(--oow-collapsible-section-padding);
  border-radius: var(--oow-collapsible-section-border-radius);
  gap: var(--oow-collapsible-section-gap);
  transition: var(--oow-collapsible-section-transition);
}

/* 头部样式 */
.section-header {
  padding: var(--oow-collapsible-section-header-padding);
  display: flex;
  align-items: var(--oow-collapsible-section-header-align-items);
  justify-content: var(--oow-collapsible-section-header-justify-content);
  gap: var(--oow-collapsible-section-header-gap);
  background: var(--oow-collapsible-section-header-bg);
  border: var(--oow-collapsible-section-header-border);
  border-radius: var(--oow-collapsible-section-header-border-radius);
}

.header-left {
  display: flex;
  align-items: var(--oow-collapsible-section-header-left-align-items);
  gap: var(--oow-collapsible-section-header-gap);
}

.header-right {
  display: flex;
  align-items: var(--oow-collapsible-section-header-right-align-items);
  gap: var(--oow-collapsible-section-header-gap);
}

/* 标题样式 */
.section-title {
  font-size: var(--oow-collapsible-section-title-size);
  font-weight: var(--oow-collapsible-section-title-weight);
  color: var(--oow-collapsible-section-title-color);
  letter-spacing: var(--oow-collapsible-section-title-letter-spacing);
  text-shadow: var(--oow-collapsible-section-title-text-shadow);
}

/* 音标样式 */
.section-phonetic {
  font-size: var(--oow-collapsible-section-phonetic-size);
  color: var(--oow-collapsible-section-phonetic-color);
  margin-left: var(--oow-collapsible-section-phonetic-margin-left);
}

/* 发音按钮样式 */
.speaker-btn {
  background: var(--oow-collapsible-section-speaker-bg);
  border: var(--oow-collapsible-section-speaker-border);
  cursor: var(--oow-collapsible-section-speaker-cursor);
  font-size: var(--oow-collapsible-section-speaker-font-size);
  padding: var(--oow-collapsible-section-speaker-padding);
}

/* 切换按钮样式 */
.section-toggle-btn {
  width: var(--oow-collapsible-section-toggle-size);
  height: var(--oow-collapsible-section-toggle-size);
  color: var(--oow-collapsible-section-toggle-color);
  padding: var(--oow-collapsible-section-toggle-padding);
  border-radius: var(--oow-collapsible-section-toggle-border-radius);
  background: var(--oow-collapsible-section-toggle-bg);
  border: none;
  cursor: pointer;
  transition: var(--oow-collapsible-section-toggle-transition);
  display: flex;
  align-items: center;
  justify-content: center;
}

.section-toggle-btn:hover {
  color: var(--oow-collapsible-section-toggle-hover-color);
  background: var(--oow-collapsible-section-toggle-hover-bg);
}

.section-toggle-btn svg {
  width: var(--oow-collapsible-section-toggle-icon-size);
  height: var(--oow-collapsible-section-toggle-icon-size);
  transition: transform 0.2s ease-in-out;  /* 保持原始动画设置 */
}

/* 内容区域样式 */
.section-content {
  padding: var(--oow-collapsible-section-content-padding);
  transition: var(--oow-collapsible-section-content-transition);
  overflow: var(--oow-collapsible-section-content-overflow);
  opacity: var(--oow-collapsible-section-content-opacity);
  box-sizing: var(--oow-collapsible-section-content-box-sizing);
  max-width: var(--oow-collapsible-section-content-max-width);
}

/* 折叠状态 */
.collapsible-section.is-collapsed .section-content {
  max-height: 0;  /* 保持原始最大高度 */
  padding-top: 0;  /* 保持原始顶部内边距 */
  padding-bottom: 0;  /* 保持原始底部内边距 */
  opacity: 0;  /* 保持原始透明度 */
  pointer-events: none;  /* 保持原始指针事件 */
}

.collapsible-section.is-collapsed .section-toggle-btn svg {
  transform: rotate(var(--oow-collapsible-section-collapsed-toggle-rotation));
}

/* 展开状态 */
.collapsible-section.is-expanded .section-content {
  max-height: var(--oow-collapsible-section-expanded-content-max-height);
  opacity: var(--oow-collapsible-section-expanded-content-opacity);
}

.collapsible-section.is-expanded .section-toggle-btn svg {
  transform: rotate(var(--oow-collapsible-section-expanded-toggle-rotation));
}`,vt=`/* Aurora wave effect */
.oow-popover[data-theme="aurora"]::before {
  content: '';
  position: absolute;
  top: -50%;
  left: -50%;
  right: -50%;
  bottom: -50%;
  background: linear-gradient(
    135deg,
    transparent 25%,
    rgba(74, 222, 128, 0.15) 35%,
    rgba(96, 165, 250, 0.15) 45%,
    rgba(244, 114, 182, 0.15) 55%,
    rgba(251, 191, 36, 0.15) 65%,
    transparent 75%
  );
  animation: aurora-wave 12s ease-in-out infinite;
  pointer-events: none;
  z-index: 0;
  opacity: 0.8;
}

@keyframes aurora-wave {
  0%, 100% {
    transform: rotate(0deg) translateY(0) scale(1);
  }
  25% {
    transform: rotate(90deg) translateY(10px) scale(1.05);
  }
  50% {
    transform: rotate(180deg) translateY(20px) scale(1.1);
  }
  75% {
    transform: rotate(270deg) translateY(10px) scale(1.05);
  }
}

.oow-popover[data-theme="aurora"] > * {
  position: relative;
  z-index: 1;
}

.oow-popover[data-theme="aurora"] .header-title {
  background: linear-gradient(135deg, var(--accent-1), var(--accent-2), var(--accent-3), var(--accent-4));
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  font-weight: 800;
  font-size: 1.2em;
  letter-spacing: 1px;
  text-shadow: 0 0 15px rgba(167, 139, 250, 0.3);
  animation: aurora-glow 3s ease-in-out infinite alternate;
}

@keyframes aurora-glow {
  0%, 100% {
    text-shadow: 0 0 15px rgba(167, 139, 250, 0.3);
  }
  50% {
    text-shadow: 0 0 25px rgba(167, 139, 250, 0.5), 0 0 35px rgba(96, 165, 250, 0.2);
  }
}

.oow-popover[data-theme="aurora"] .header-logo {
  background: linear-gradient(135deg, var(--accent-1), var(--accent-2));
  border: 2px solid var(--ring);
  color: #1a1a2e;
  font-weight: 900;
  font-size: 1.1em;
  text-shadow: 0 0 10px rgba(167, 139, 250, 0.4);
  animation: aurora-pulse 2s infinite;
}

/* === Aurora主题专属文字动效关键帧 === */

/* 极光流动效果 - 模拟北极光的自然流动 */
@keyframes aurora-flow {
  0% {
    background-position: 0% 50%;
    opacity: 0.8;
  }
  25% {
    background-position: 25% 25%;
    opacity: 0.9;
  }
  50% {
    background-position: 50% 75%;
    opacity: 1;
  }
  75% {
    background-position: 75% 25%;
    opacity: 0.85;
  }
  100% {
    background-position: 100% 50%;
    opacity: 0.8;
  }
}

/* 极光波纹效果 - 模拟极光的波纹扩散 */
@keyframes aurora-ripple {
  0% {
    box-shadow: 0 0 0 0 rgba(74, 222, 128, 0.4),
                0 0 0 0 rgba(96, 165, 250, 0.3);
    opacity: 1;
  }
  50% {
    box-shadow: 0 0 20px 10px rgba(74, 222, 128, 0.2),
                0 0 30px 15px rgba(96, 165, 250, 0.15);
    opacity: 0.8;
  }
  100% {
    box-shadow: 0 0 30px 20px rgba(74, 222, 128, 0),
                0 0 40px 30px rgba(96, 165, 250, 0);
    opacity: 0.6;
  }
}

/* 色彩呼吸效果 - 模拟极光的色彩变化 */
@keyframes aurora-breathe {
  0%, 100% {
    filter: hue-rotate(0deg) brightness(1);
    transform: scale(1);
  }
  25% {
    filter: hue-rotate(60deg) brightness(1.1);
    transform: scale(1.02);
  }
  50% {
    filter: hue-rotate(120deg) brightness(0.95);
    transform: scale(0.98);
  }
  75% {
    filter: hue-rotate(180deg) brightness(1.05);
    transform: scale(1.01);
  }
}

/* 星光闪烁效果 - 模拟极光中的星光 */
@keyframes aurora-shimmer {
  0%, 100% {
    opacity: 1;
    text-shadow: 0 0 5px currentColor;
  }
  20% {
    opacity: 0.7;
    text-shadow: 0 0 10px currentColor;
  }
  40% {
    opacity: 0.9;
    text-shadow: 0 0 8px currentColor;
  }
  60% {
    opacity: 0.8;
    text-shadow: 0 0 12px currentColor;
  }
  80% {
    opacity: 0.95;
    text-shadow: 0 0 6px currentColor;
  }
}

/* 色彩变换效果 - 模拟极光的渐变变化 */
@keyframes aurora-gradient-shift {
  0% {
    background: linear-gradient(45deg,
      rgba(74, 222, 128, 0.3),
      rgba(96, 165, 250, 0.3),
      rgba(244, 114, 182, 0.3));
  }
  25% {
    background: linear-gradient(45deg,
      rgba(96, 165, 250, 0.3),
      rgba(244, 114, 182, 0.3),
      rgba(251, 191, 36, 0.3));
  }
  50% {
    background: linear-gradient(45deg,
      rgba(244, 114, 182, 0.3),
      rgba(251, 191, 36, 0.3),
      rgba(192, 132, 252, 0.3));
  }
  75% {
    background: linear-gradient(45deg,
      rgba(251, 191, 36, 0.3),
      rgba(192, 132, 252, 0.3),
      rgba(74, 222, 128, 0.3));
  }
  100% {
    background: linear-gradient(45deg,
      rgba(192, 132, 252, 0.3),
      rgba(74, 222, 128, 0.3),
      rgba(96, 165, 250, 0.3));
  }
}

/* 光带流动效果 - 模拟极光的光带移动 */
@keyframes aurora-light-band {
  0% {
    background-position: -200% center;
    opacity: 0;
  }
  20% {
    opacity: 0.6;
  }
  80% {
    opacity: 0.6;
  }
  100% {
    background-position: 200% center;
    opacity: 0;
  }
}

/* 极光尾迹效果 - 模拟极光的尾迹 */
@keyframes aurora-trail {
  0% {
    transform: translateX(-100%);
    opacity: 0;
  }
  20% {
    opacity: 0.8;
  }
  80% {
    opacity: 0.8;
  }
  100% {
    transform: translateX(100%);
    opacity: 0;
  }
}

@keyframes aurora-pulse {
  0%, 100% {
    text-shadow: 0 0 10px rgba(167, 139, 250, 0.4);
  }
  50% {
    text-shadow: 0 0 20px rgba(167, 139, 250, 0.6), 0 0 30px rgba(96, 165, 250, 0.3);
  }
}

.oow-popover[data-theme="aurora"] .section-title {
  background: linear-gradient(135deg, var(--accent-2), var(--accent-3), var(--accent-4));
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  font-weight: 700;
  font-size: 1.1em;
  letter-spacing: 0.5px;
  text-shadow: 0 0 8px rgba(96, 165, 250, 0.2);
}

.oow-popover[data-theme="aurora"] .def-item .pos {
  color: var(--accent-3);
  font-weight: 700;
  text-shadow: 0 0 6px rgba(244, 114, 182, 0.2);
}

.oow-popover[data-theme="aurora"] .def-item .meaning {
  color: var(--text-color);
  line-height: 1.5;
}

.oow-popover[data-theme="aurora"] .def-item .example {
  color: var(--muted);
  border-left: 3px solid var(--accent-2);
  padding-left: 12px;
  background: rgba(96, 165, 250, 0.08);
  border-radius: 0 4px 4px 0;
  margin-left: 2px;
}

.oow-popover[data-theme="aurora"] .eq .bar {
  background: linear-gradient(180deg, var(--accent-1), var(--accent-2), var(--accent-3), var(--accent-4));
  box-shadow: 0 2px 15px rgba(167, 139, 250, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.2);
  border-radius: 8px;
  height: 8px;
}

.oow-popover[data-theme="aurora"] .text-translation {
  background: linear-gradient(135deg, var(--accent-1), var(--accent-4));
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  font-weight: 600;
  text-shadow: 0 0 12px rgba(251, 191, 36, 0.3);
}

`,yt=`/* === Aurora主题性能和体验优化 === */

/* 性能优化 - GPU加速 */
.oow-popover[data-theme="aurora"] .info-panel-content,
.oow-popover[data-theme="aurora"] .etymology-panel {
  transform: translateZ(0);
  backface-visibility: hidden;
  perspective: 1000px;
}

/* 移动端性能优化 */
@media (max-width: 768px) {
  .oow-popover[data-theme="aurora"] .info-panel-content *,
  .oow-popover[data-theme="aurora"] .etymology-panel * {
    animation-duration: 4s !important;
  }

  .oow-popover[data-theme="aurora"] .info-panel-content strong::after,
  .oow-popover[data-theme="aurora"] .etymology-panel strong::after,
  .oow-popover[data-theme="aurora"] .info-panel-content p::after,
  .oow-popover[data-theme="aurora"] .etymology-panel p::after {
    display: none;
  }
}

/* 用户偏好减少动画 */
@media (prefers-reduced-motion: reduce) {
  .oow-popover[data-theme="aurora"] .info-panel-content *,
  .oow-popover[data-theme="aurora"] .etymology-panel * {
    animation: none !important;
    background: transparent !important;
  }
}

`,bt=`/* Aurora主题的translation和contextual-analysis样式 */
.oow-popover[data-theme="aurora"] .translation[data-style="gradient"] {
  background: transparent;
  border: none;
  border-radius: 0;
  padding: 0;
  box-shadow: none;
  background-image: linear-gradient(135deg, var(--accent-1), var(--accent-4));
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}

.oow-popover[data-theme="aurora"] .contextual-analysis[data-style="framed"] {
  background: rgba(167, 139, 250, 0.1);
  border: 1px solid rgba(167, 139, 250, 0.2);
  border-radius: 6px;
  padding: 10px 12px;
  box-shadow: 0 2px 8px rgba(167, 139, 250, 0.1);
}

.oow-popover[data-theme="aurora"] .translation .text {
  font-weight: 600;
  text-shadow: 0 0 12px rgba(251, 191, 36, 0.3);
}

.oow-popover[data-theme="aurora"] .contextual-analysis .text {
  color: #d0e0ff;
  font-weight: 400;
}

/* Aurora主题的Info Panel和Etymology Panel样式 */
.oow-popover[data-theme="aurora"] .info-panel-content,
.oow-popover[data-theme="aurora"] .etymology-panel {
  /* 梦幻光效风格：使用渐变文字效果和柔和的发光，营造星空般的阅读体验 */
  --oow-info-panel-heading-color: #f0f8ff;
  --oow-info-panel-heading-weight: 600;
  --oow-info-panel-heading-margin-top: 1.2em;
  --oow-info-panel-heading-margin-bottom: 0.6em;
  --oow-info-panel-paragraph-color: #f0f8ff;
  --oow-info-panel-paragraph-margin-bottom: 0.9em;
  --oow-info-panel-line-height: 1.6;
  --oow-info-panel-letter-spacing: 0.01em;
  --oow-info-panel-font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  --oow-info-panel-list-color: #f0f8ff;
  --oow-info-panel-blockquote-color: #d0e0ff;
  --oow-info-panel-blockquote-border: #a78bfa;
  --oow-info-panel-code-color: #f472b6;
  --oow-info-panel-code-bg: rgba(255,255,255,0.08);
  --oow-info-panel-link-color: #4ade80;
  --oow-info-panel-link-hover: #fbbf24;
}

/* === Aurora主题文字动效 - 极光梦幻效果 === */

/* 标题极光带流动效果 */
.oow-popover[data-theme="aurora"] .info-panel-content h1,
.oow-popover[data-theme="aurora"] .info-panel-content h2,
.oow-popover[data-theme="aurora"] .info-panel-content h3,
.oow-popover[data-theme="aurora"] .info-panel-content h4,
.oow-popover[data-theme="aurora"] .info-panel-content h5,
.oow-popover[data-theme="aurora"] .info-panel-content h6,
.oow-popover[data-theme="aurora"] .etymology-panel h1,
.oow-popover[data-theme="aurora"] .etymology-panel h2,
.oow-popover[data-theme="aurora"] .etymology-panel h3,
.oow-popover[data-theme="aurora"] .etymology-panel h4,
.oow-popover[data-theme="aurora"] .etymology-panel h5,
.oow-popover[data-theme="aurora"] .etymology-panel h6 {
  background: linear-gradient(
    45deg,
    var(--accent-1, #4ade80),
    var(--accent-2, #60a5fa),
    var(--accent-3, #f472b6),
    var(--accent-4, #fbbf24),
    var(--accent-5, #c084fc)
  );
  background-size: 200% 200%;
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: aurora-flow 8s ease-in-out infinite, aurora-glow 4s ease-in-out infinite 2s;
  position: relative;
  will-change: background-position, text-shadow;
  transform: translateZ(0);
}

/* 标题极光带延迟 - 模拟极光的自然流动序列 */
.oow-popover[data-theme="aurora"] .info-panel-content h1,
.oow-popover[data-theme="aurora"] .etymology-panel h1 {
  animation-delay: 0s, 2s;
}

.oow-popover[data-theme="aurora"] .info-panel-content h2,
.oow-popover[data-theme="aurora"] .etymology-panel h2 {
  animation-delay: 0.3s, 2.3s;
}

.oow-popover[data-theme="aurora"] .info-panel-content h3,
.oow-popover[data-theme="aurora"] .etymology-panel h3 {
  animation-delay: 0.6s, 2.6s;
}

.oow-popover[data-theme="aurora"] .info-panel-content h4,
.oow-popover[data-theme="aurora"] .info-panel-content h5,
.oow-popover[data-theme="aurora"] .info-panel-content h6,
.oow-popover[data-theme="aurora"] .etymology-panel h4,
.oow-popover[data-theme="aurora"] .etymology-panel h5,
.oow-popover[data-theme="aurora"] .etymology-panel h6 {
  animation-delay: 0.9s, 2.9s;
}

/* 标题星光闪烁效果 */
.oow-popover[data-theme="aurora"] .info-panel-content h1::before,
.oow-popover[data-theme="aurora"] .info-panel-content h2::before,
.oow-popover[data-theme="aurora"] .etymology-panel h1::before,
.oow-popover[data-theme="aurora"] .etymology-panel h2::before {
  content: '';
  position: absolute;
  top: 50%;
  left: -20px;
  width: 6px;
  height: 6px;
  background: radial-gradient(circle, var(--accent-1, #4ade80), transparent);
  border-radius: 50%;
  animation: aurora-shimmer 2s ease-in-out infinite;
  transform: translateY(-50%);
  opacity: 0.6;
}

/* 段落渐变流动效果 */
.oow-popover[data-theme="aurora"] .info-panel-content p,
.oow-popover[data-theme="aurora"] .etymology-panel p {
  background: linear-gradient(
    90deg,
    transparent 0%,
    rgba(74, 222, 128, 0.1) 20%,
    rgba(96, 165, 250, 0.1) 40%,
    rgba(244, 114, 182, 0.1) 60%,
    rgba(251, 191, 36, 0.1) 80%,
    transparent 100%
  );
  background-size: 200% 100%;
  animation: aurora-flow 12s ease-in-out infinite;
  padding: 2px 0;
  border-radius: 4px;
  position: relative;
  will-change: background-position;
}

/* 段落星光点缀 */
.oow-popover[data-theme="aurora"] .info-panel-content p::after,
.oow-popover[data-theme="aurora"] .etymology-panel p::after {
  content: '✦';
  position: absolute;
  top: 10px;
  right: 10px;
  color: var(--accent-4, #fbbf24);
  font-size: 0.8em;
  animation: aurora-shimmer 3s ease-in-out infinite;
  opacity: 0.4;
  pointer-events: none;
}

/* === Aurora主题文字动效 - 综合效果 === */

/* 列表光带尾巴效果 */
.oow-popover[data-theme="aurora"] .info-panel-content ul li,
.oow-popover[data-theme="aurora"] .info-panel-content ol li,
.oow-popover[data-theme="aurora"] .etymology-panel ul li,
.oow-popover[data-theme="aurora"] .etymology-panel ol li {
  position: relative;
  padding-left: 20px;
  animation: aurora-breathe 6s ease-in-out infinite;
  will-change: transform, filter;
}

/* 列表项极光尾巴 */
.oow-popover[data-theme="aurora"] .info-panel-content ul li::before,
.oow-popover[data-theme="aurora"] .info-panel-content ol li::before,
.oow-popover[data-theme="aurora"] .etymology-panel ul li::before,
.oow-popover[data-theme="aurora"] .etymology-panel ol li::before {
  content: '';
  position: absolute;
  left: -10px;
  top: 50%;
  width: 0;
  height: 2px;
  background: linear-gradient(
    90deg,
    transparent,
    var(--accent-1, #4ade80),
    var(--accent-2, #60a5fa),
    var(--accent-3, #f472b6)
  );
  animation: aurora-trail 3s ease-in-out infinite;
  transform: translateY(-50%);
  transition: width 0.3s ease;
}

/* 列表项悬停增强 */
.oow-popover[data-theme="aurora"] .info-panel-content ul li:hover::before,
.oow-popover[data-theme="aurora"] .info-panel-content ol li:hover::before,
.oow-popover[data-theme="aurora"] .etymology-panel ul li:hover::before,
.oow-popover[data-theme="aurora"] .etymology-panel ol li:hover::before {
  width: 15px;
  animation-duration: 1.5s;
}

/* 强调文本星光闪烁效果 */
.oow-popover[data-theme="aurora"] .info-panel-content strong,
.oow-popover[data-theme="aurora"] .etymology-panel strong {
  color: var(--accent-1, #4ade80);
  font-weight: 700;
  animation: aurora-shimmer 2.5s ease-in-out infinite;
  position: relative;
  display: inline-block;
  will-change: opacity, text-shadow;
}

/* 强调文本星光点 */
.oow-popover[data-theme="aurora"] .info-panel-content strong::after,
.oow-popover[data-theme="aurora"] .etymology-panel strong::after {
  content: '✧';
  position: absolute;
  top: -8px;
  right: -8px;
  color: var(--accent-1, #4ade80);
  font-size: 0.7em;
  animation: aurora-shimmer 2s ease-in-out infinite;
  opacity: 0.6;
}

/* 斜体文本梦幻效果 */
.oow-popover[data-theme="aurora"] .info-panel-content em,
.oow-popover[data-theme="aurora"] .etymology-panel em {
  color: var(--accent-3, #f472b6);
  font-style: italic;
  animation: aurora-breathe 4s ease-in-out infinite;
  animation-delay: 0.5s;
  position: relative;
  display: inline-block;
}

/* 链接光带追踪效果 */
.oow-popover[data-theme="aurora"] .info-panel-content a,
.oow-popover[data-theme="aurora"] .etymology-panel a {
  color: var(--accent-1, #4ade80);
  text-decoration: none;
  position: relative;
  transition: all 0.3s ease;
  padding: 2px 4px;
  border-radius: 4px;
}

.oow-popover[data-theme="aurora"] .info-panel-content a::before,
.oow-popover[data-theme="aurora"] .etymology-panel a::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(
    90deg,
    transparent,
    rgba(74, 222, 128, 0.2),
    rgba(96, 165, 250, 0.2),
    rgba(244, 114, 182, 0.2),
    transparent
  );
  background-size: 200% 100%;
  background-position: 100% 50%;
  animation: aurora-light-band 4s ease-in-out infinite;
  border-radius: 4px;
  z-index: -1;
  transition: background-position 0.3s ease;
}

.oow-popover[data-theme="aurora"] .info-panel-content a:hover,
.oow-popover[data-theme="aurora"] .etymology-panel a:hover {
  color: var(--accent-2, #60a5fa);
  animation: aurora-ripple 1s ease-out;
}

.oow-popover[data-theme="aurora"] .info-panel-content a:hover::before,
.oow-popover[data-theme="aurora"] .etymology-panel a:hover::before {
  background-position: 0% 50%;
  animation-duration: 2s;
}

/* 代码块极光效果 */
.oow-popover[data-theme="aurora"] .info-panel-content code,
.oow-popover[data-theme="aurora"] .etymology-panel code {
  color: var(--accent-3, #f472b6);
  background: linear-gradient(
    45deg,
    rgba(244, 114, 182, 0.1),
    rgba(251, 191, 36, 0.1),
    rgba(74, 222, 128, 0.1)
  );
  background-size: 200% 200%;
  animation: aurora-gradient-shift 6s ease-in-out infinite;
  padding: 3px 6px;
  border-radius: 4px;
  border: 1px solid rgba(244, 114, 182, 0.3);
  font-family: 'SF Mono', 'Monaco', monospace;
  position: relative;
  will-change: background;
}

/* 引用块光斑效果 */
.oow-popover[data-theme="aurora"] .info-panel-content blockquote,
.oow-popover[data-theme="aurora"] .etymology-panel blockquote {
  border-left: 3px solid var(--ring, #a78bfa);
  padding-left: 15px;
  margin: 1.5em 0;
  background: linear-gradient(
    90deg,
    rgba(167, 139, 250, 0.05),
    rgba(74, 222, 128, 0.03),
    rgba(96, 165, 250, 0.05)
  );
  position: relative;
  animation: aurora-gradient-shift 8s ease-in-out infinite;
  will-change: background;
}

/* 引用块光斑装饰 */
.oow-popover[data-theme="aurora"] .info-panel-content blockquote::before,
.oow-popover[data-theme="aurora"] .etymology-panel blockquote::before {
  content: '◈';
  position: absolute;
  top: 10px;
  left: 10px;
  color: var(--ring, #a78bfa);
  font-size: 1.2em;
  animation: aurora-shimmer 3s ease-in-out infinite;
  opacity: 0.6;
}

/* 表格极光边框效果 */
.oow-popover[data-theme="aurora"] .info-panel-content table,
.oow-popover[data-theme="aurora"] .etymology-panel table {
  border: 2px solid var(--ring, #a78bfa);
  border-radius: 8px;
  overflow: hidden;
  animation: aurora-gradient-shift 10s ease-in-out infinite;
  will-change: border-color, box-shadow;
  box-shadow: 0 0 20px rgba(167, 139, 250, 0.2);
}

.oow-popover[data-theme="aurora"] .info-panel-content table th,
.oow-popover[data-theme="aurora"] .etymology-panel table th {
  background: linear-gradient(
    135deg,
    var(--accent-1, #4ade80),
    var(--accent-2, #60a5fa)
  );
  color: white;
  font-weight: 700;
  animation: aurora-glow 4s ease-in-out infinite;
}

/* 分割线极光流动效果 */
.oow-popover[data-theme="aurora"] .info-panel-content hr,
.oow-popover[data-theme="aurora"] .etymology-panel hr {
  border: none;
  height: 2px;
  background: linear-gradient(
    90deg,
    transparent,
    var(--accent-1, #4ade80),
    var(--accent-2, #60a5fa),
    var(--accent-3, #f472b6),
    var(--accent-4, #fbbf24),
    var(--accent-5, #c084fc),
    transparent
  );
  background-size: 200% 100%;
  animation: aurora-flow 5s linear infinite;
  margin: 2em 0;
  position: relative;
  will-change: background-position;
}

`,xt=`/*
 * Origin of Words - Aurora Theme (Premium)
 * 极光主题 - 付费梦幻极光主题
 * 100% original style with ORIGINAL variable names
 */

/* Theme Variables - CRITICAL: Use original variable names */
.oow-popover[data-theme="aurora"] {
  --panel-bg: #1a1a2e;
  --text-color: #f0f8ff;
  --muted: #d0e0ff;
  --ring: #a78bfa; /* violet-400 */
  --accent-1: #4ade80; /* green-400 */
  --accent-2: #60a5fa; /* blue-400 */
  --accent-3: #f472b6; /* pink-400 */
  --accent-4: #fbbf24; /* yellow-500 */
  --accent-5: #c084fc; /* violet-400 */
  backdrop-filter: blur(25px);
  background: linear-gradient(135deg, #1a1a2e, #16213e, #0f3460) !important;
  border: 1px solid rgba(167, 139, 250, 0.3);
  box-shadow: 0 0 60px rgba(167, 139, 250, 0.4), inset 0 0 50px rgba(147, 197, 253, 0.15);

  /* Unified Button Styles */
  --oow-button-bg: rgba(167, 139, 250, 0.15);
  --oow-button-hover-bg: linear-gradient(135deg, var(--accent-1), var(--accent-2));
  --oow-button-color: var(--text-color);
  --oow-button-hover-color: #1a1a2e;
  --oow-button-radius: 8px;
  --oow-button-transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  /* Enhanced Markdown Highlight Styles */
  --oow-highlight-heading-color: var(--text-color);
  --oow-highlight-heading-font-weight: 600;
  --oow-highlight-heading-margin-top: 1.2em;
  --oow-highlight-heading-margin-bottom: 0.6em;
  --oow-highlight-h1-font-size: 1.6em;
  --oow-highlight-h2-font-size: 1.35em;
  --oow-highlight-h3-font-size: 1.2em;
  --oow-highlight-h4-font-size: 1.1em;
  --oow-highlight-h5-font-size: 1em;
  --oow-highlight-h6-font-size: 0.9em;
  --oow-highlight-strong-color: var(--accent-1);
  --oow-highlight-strong-font-weight: 700;
  --oow-highlight-em-color: var(--accent-2);
  --oow-highlight-em-font-style: italic;
  --oow-highlight-code-color: var(--accent-3);
  --oow-highlight-code-bg: rgba(255,255,255,0.08);
  --oow-highlight-code-border-color: var(--ring);
  --oow-highlight-link-color: var(--accent-1);
  --oow-highlight-link-decoration: underline;
  --oow-highlight-link-decoration-thickness: 2px;
  --oow-highlight-link-hover-color: var(--accent-4);
  --oow-highlight-blockquote-margin: 1.2em 0;
  --oow-highlight-blockquote-padding: 0.8em 1.2em;
  --oow-highlight-blockquote-border-left: 5px solid var(--ring);
  --oow-highlight-blockquote-color: var(--muted);
  --oow-highlight-blockquote-bg: rgba(255,255,255,0.06);
  --oow-highlight-hr-height: 2px;
  --oow-highlight-hr-bg: linear-gradient(90deg, var(--accent-1), var(--accent-2), var(--accent-3));
  --oow-highlight-hr-margin: 1.8em 0;
  --oow-highlight-pre-padding: 1.2em;
  --oow-highlight-pre-bg: rgba(0,0,0,0.1);
  --oow-highlight-pre-border-radius: 8px;
  --oow-highlight-pre-font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  --oow-highlight-pre-font-size: 0.95em;
  --oow-highlight-table-margin: 1.8em 0;
  --oow-highlight-table-border: 2px solid var(--ring);
  --oow-highlight-table-cell-padding: 0.6em 0.9em;
  --oow-highlight-table-header-bg: rgba(255,255,255,0.1);
  --oow-highlight-table-header-color: var(--text-color);
  --oow-highlight-table-header-font-weight: 700;
}

`,St=`/* === Trigger Button - Aurora Theme === */
.oow-selection-trigger-button[data-theme="aurora"] {
  background: linear-gradient(135deg, #1a1a2e, #16213e);
  border: 1px solid #a78bfa;
  box-shadow: 0 0 20px rgba(167, 139, 250, 0.5);
  color: #f0f8ff;
  transition: all 0.3s ease;
  border-radius: 6px;
  font-weight: 600;
  text-shadow: 0 0 8px rgba(167, 139, 250, 0.3);
}

.oow-selection-trigger-button[data-theme="aurora"]:hover {
  background: linear-gradient(135deg, #1a1a2e, #16213e);
  color: #f0f8ff;
  box-shadow: 0 0 35px rgba(147, 197, 253, 0.7);
  transform: scale(1.12);
  text-shadow: 0 0 12px rgba(147, 197, 253, 0.5);
}

.oow-selection-trigger-button[data-theme="aurora"].activated {
  background: linear-gradient(135deg, #1a1a2e, #16213e);
  border: 3px solid #F44336;
  box-shadow: 0 0 45px rgba(244, 67, 54, 0.7);
  color: #f0f8ff;
  animation: aurora-button-pulse 1.5s infinite;
}

@keyframes aurora-button-pulse {
  0%, 100% {
    box-shadow: 0 0 40px var(--accent-3);
  }
  50% {
    box-shadow: 0 0 50px var(--accent-3), 0 0 60px rgba(96, 165, 250, 0.4);
  }
}
`,Ct=`/* === Basic主题专属简约入门动效关键帧 === */

/* 简约淡入 - 模拟基础元素的简单显现 */
@keyframes basic-fade-in {
  0% {
    opacity: 0;
    transform: translateY(5px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 入门滑动 - 模拟基础元素的滑动进入 */
@keyframes basic-slide-in {
  0% {
    opacity: 0;
    transform: translateX(10px);
  }
  100% {
    opacity: 1;
    transform: translateX(0);
  }
}

/* 简洁强调 - 模拟基础的强调效果 */
@keyframes basic-emphasis {
  0%, 100% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.02);
  }
}

/* 入门渐变 - 模拟基础的色彩渐变 */
@keyframes basic-gradient-shift {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}

/* 简约下划线 - 模拟基础的下划线动画 */
@keyframes basic-underline-grow {
  0% {
    width: 0;
    opacity: 0;
  }
  50% {
    opacity: 0.5;
  }
  100% {
    width: 100%;
    opacity: 1;
  }
}

/* 入门脉冲 - 模拟基础的脉冲效果 */
@keyframes basic-pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.8;
  }
}

/* 简洁闪烁 - 模拟基础的闪烁效果 */
@keyframes basic-blink {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.6;
  }
}

/* 入门过渡 - 模拟基础的过渡效果 */
@keyframes basic-transition {
  0% {
    opacity: 0;
    transform: scale(0.98);
  }
  100% {
    opacity: 1;
    transform: scale(1);
  }
}

/* === Basic主题专属简约入门动效应用 === */

/* 简约淡入 - 标题基础展示 */
.oow-popover[data-theme="basic"] .info-panel-content h1,
.oow-popover[data-theme="basic"] .info-panel-content h2,
.oow-popover[data-theme="basic"] .info-panel-content h3,
.oow-popover[data-theme="basic"] .info-panel-content h4,
.oow-popover[data-theme="basic"] .info-panel-content h5,
.oow-popover[data-theme="basic"] .info-panel-content h6,
.oow-popover[data-theme="basic"] .etymology-panel h1,
.oow-popover[data-theme="basic"] .etymology-panel h2,
.oow-popover[data-theme="basic"] .etymology-panel h3,
.oow-popover[data-theme="basic"] .etymology-panel h4,
.oow-popover[data-theme="basic"] .etymology-panel h5,
.oow-popover[data-theme="basic"] .etymology-panel h6 {
  animation: basic-fade-in 0.6s ease-out forwards;
  color: var(--oow-info-panel-heading-color);
  font-weight: var(--oow-info-panel-heading-weight);
  position: relative;
  transform: translateZ(0);
}

.oow-popover[data-theme="basic"] .info-panel-content h1::after,
.oow-popover[data-theme="basic"] .info-panel-content h2::after,
.oow-popover[data-theme="basic"] .info-panel-content h3::after,
.oow-popover[data-theme="basic"] .etymology-panel h1::after,
.oow-popover[data-theme="basic"] .etymology-panel h2::after,
.oow-popover[data-theme="basic"] .etymology-panel h3::after {
  content: '';
  position: absolute;
  bottom: -2px;
  left: 0;
  width: 0;
  height: 1px;
  background: var(--accent-1);
  animation: basic-underline-grow 1s ease-out 0.3s forwards;
}

/* 入门滑动 - 段落基础展示 */
.oow-popover[data-theme="basic"] .info-panel-content p,
.oow-popover[data-theme="basic"] .etymology-panel p {
  animation: basic-slide-in 0.5s ease-out forwards;
  color: var(--oow-info-panel-paragraph-color);
  line-height: var(--oow-info-panel-line-height);
  transform: translateZ(0);
}

/* 简洁强调 - 链接基础交互 */
.oow-popover[data-theme="basic"] .info-panel-content a,
.oow-popover[data-theme="basic"] .etymology-panel a {
  color: var(--oow-info-panel-link-color);
  text-decoration: none;
  position: relative;
  transition: all 0.2s ease;
  animation: basic-pulse 4s ease-in-out infinite;
  transform: translateZ(0);
}

.oow-popover[data-theme="basic"] .info-panel-content a::before,
.oow-popover[data-theme="basic"] .etymology-panel a::before {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 0;
  height: 1px;
  background: var(--oow-info-panel-link-color);
  transition: width 0.2s ease;
}

.oow-popover[data-theme="basic"] .info-panel-content a:hover,
.oow-popover[data-theme="basic"] .etymology-panel a:hover {
  color: var(--oow-info-panel-link-hover);
  animation: basic-emphasis 0.3s ease-in-out infinite;
}

.oow-popover[data-theme="basic"] .info-panel-content a:hover::before,
.oow-popover[data-theme="basic"] .etymology-panel a:hover::before {
  width: 100%;
}

/* 入门渐变 - 列表项基础展示 */
.oow-popover[data-theme="basic"] .info-panel-content ul li,
.oow-popover[data-theme="basic"] .info-panel-content ol li,
.oow-popover[data-theme="basic"] .etymology-panel ul li,
.oow-popover[data-theme="basic"] .etymology-panel ol li {
  animation: basic-slide-in 0.6s ease-out forwards;
  position: relative;
  padding-left: 16px;
  margin-bottom: 0.5em;
  color: var(--oow-info-panel-list-color);
  transform: translateZ(0);
}

.oow-popover[data-theme="basic"] .info-panel-content ul li::before,
.oow-popover[data-theme="basic"] .info-panel-content ol li::before,
.oow-popover[data-theme="basic"] .etymology-panel ul li::before,
.oow-popover[data-theme="basic"] .etymology-panel ol li::before {
  content: '•';
  position: absolute;
  left: 0;
  color: var(--accent-1);
  font-weight: 700;
  animation: basic-blink 3s ease-in-out infinite;
}

/* 简洁强调 - 强调文字 */
.oow-popover[data-theme="basic"] .info-panel-content strong,
.oow-popover[data-theme="basic"] .etymology-panel strong {
  color: var(--accent-2);
  font-weight: 600;
  animation: basic-emphasis 2s ease-in-out infinite;
  transform: translateZ(0);
}

/* 简约斜体效果 - 斜体文字 */
.oow-popover[data-theme="basic"] .info-panel-content em,
.oow-popover[data-theme="basic"] .etymology-panel em {
  color: var(--accent-1);
  font-style: italic;
  animation: basic-fade-in 0.4s ease-out forwards;
  transform: translateZ(0);
}

/* 入门代码块 - 基础代码展示 */
.oow-popover[data-theme="basic"] .info-panel-content code,
.oow-popover[data-theme="basic"] .etymology-panel code {
  background: var(--oow-info-panel-code-bg);
  color: var(--oow-info-panel-code-color);
  padding: 0.2em 0.4em;
  border-radius: 3px;
  font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  border: 1px solid rgba(14, 165, 233, 0.2);
  animation: basic-fade-in 0.3s ease-out forwards;
  transform: translateZ(0);
}

/* 简约引用块 - 基础引用设计 */
.oow-popover[data-theme="basic"] .info-panel-content blockquote,
.oow-popover[data-theme="basic"] .etymology-panel blockquote {
  margin: var(--oow-highlight-blockquote-margin);
  padding: var(--oow-highlight-blockquote-padding);
  border-left: 3px solid var(--oow-info-panel-blockquote-border);
  background: var(--oow-highlight-blockquote-bg);
  color: var(--oow-info-panel-blockquote-color);
  border-radius: 0 3px 3px 0;
  animation: basic-fade-in 0.7s ease-out forwards;
  transform: translateZ(0);
}

/* 简洁分隔线 - 基础分隔效果 */
.oow-popover[data-theme="basic"] .info-panel-content hr,
.oow-popover[data-theme="basic"] .etymology-panel hr {
  border: none;
  height: var(--oow-highlight-hr-height);
  background: var(--oow-highlight-hr-bg);
  margin: var(--oow-highlight-hr-margin);
  animation: basic-transition 0.8s ease-out forwards;
  transform: translateZ(0);
}

/* 入门预格式化文本 - 基础代码展示 */
.oow-popover[data-theme="basic"] .info-panel-content pre,
.oow-popover[data-theme="basic"] .etymology-panel pre {
  background: var(--oow-highlight-pre-bg);
  border: 1px solid var(--ring);
  border-radius: var(--oow-highlight-pre-border-radius);
  padding: var(--oow-highlight-pre-padding);
  overflow-x: auto;
  font-family: var(--oow-highlight-pre-font-family);
  font-size: var(--oow-highlight-pre-font-size);
  color: var(--text-color);
  animation: basic-fade-in 0.9s ease-out forwards;
  transform: translateZ(0);
}

/* 简约表格 - 基础表格设计 */
.oow-popover[data-theme="basic"] .info-panel-content table,
.oow-popover[data-theme="basic"] .etymology-panel table {
  width: 100%;
  border-collapse: collapse;
  margin: var(--oow-highlight-table-margin);
  border: var(--oow-highlight-table-border);
  border-radius: 4px;
  overflow: hidden;
  animation: basic-transition 1s ease-out forwards;
  transform: translateZ(0);
}

.oow-popover[data-theme="basic"] .info-panel-content table th,
.oow-popover[data-theme="basic"] .etymology-panel table th {
  background: var(--oow-highlight-table-header-bg);
  color: var(--oow-highlight-table-header-color);
  font-weight: var(--oow-highlight-table-header-font-weight);
  padding: var(--oow-highlight-table-cell-padding);
  text-align: left;
  border-bottom: 1px solid var(--accent-1);
  animation: basic-fade-in 0.8s ease-out forwards;
}

.oow-popover[data-theme="basic"] .info-panel-content table td,
.oow-popover[data-theme="basic"] .etymology-panel table td {
  padding: var(--oow-highlight-table-cell-padding);
  border-bottom: 1px solid rgba(14, 165, 233, 0.1);
  color: var(--text-color);
  animation: basic-slide-in 0.6s ease-out forwards;
}

.oow-popover[data-theme="basic"] .info-panel-content table tr:hover td,
.oow-popover[data-theme="basic"] .etymology-panel table tr:hover td {
  background: rgba(14, 165, 233, 0.05);
  animation: basic-pulse 1s ease-in-out infinite;
}

/* 性能优化 - GPU加速 */
@media (min-width: 768px) {
  .oow-popover[data-theme="basic"] .info-panel-content *,
  .oow-popover[data-theme="basic"] .etymology-panel * {
    transform: translateZ(0);
    will-change: transform, opacity;
  }
}

/* 减少动效 - 无障碍支持 */
@media (prefers-reduced-motion: reduce) {
  .oow-popover[data-theme="basic"] .info-panel-content *,
  .oow-popover[data-theme="basic"] .etymology-panel * {
    animation: none !important;
  }
}`,wt=`/* Basic主题的translation和contextual-analysis样式 */
.oow-popover[data-theme="basic"] .translation[data-style="subtle"] {
  /* subtle样式：保持简洁，仅通过颜色区分 */
}

.oow-popover[data-theme="basic"] .contextual-analysis[data-style="subtle"] {
  /* subtle样式：保持简洁，仅通过颜色区分 */
}

.oow-popover[data-theme="basic"] .translation .text {
  color: #1e3a8a;
  font-weight: 700;
}

.oow-popover[data-theme="basic"] .contextual-analysis .text {
  color: #4b5563;
  font-weight: 400;
}

/* Basic主题的Info Panel和Etymology Panel样式 */
.oow-popover[data-theme="basic"] .info-panel-content,
.oow-popover[data-theme="basic"] .etymology-panel {
  /* 极简纯净风格：保持干净简洁的阅读体验 */
  --oow-info-panel-heading-color: #1e3a8a;
  --oow-info-panel-heading-weight: 600;
  --oow-info-panel-heading-margin-top: 1.2em;
  --oow-info-panel-heading-margin-bottom: 0.6em;
  --oow-info-panel-paragraph-color: #333333;
  --oow-info-panel-paragraph-margin-bottom: 0.9em;
  --oow-info-panel-line-height: 1.7;
  --oow-info-panel-letter-spacing: 0.02em;
  --oow-info-panel-font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  --oow-info-panel-list-color: #333333;
  --oow-info-panel-blockquote-color: #666666;
  --oow-info-panel-blockquote-border: #0ea5e9;
  --oow-info-panel-code-color: #d6336c;
  --oow-info-panel-code-bg: rgba(0, 0, 0, 0.05);
  --oow-info-panel-link-color: #0ea5e9;
  --oow-info-panel-link-hover: #22c55e;
}

`,Tt=`/*
 * Origin of Words - Basic Theme (Free)
 * 基本主题 - 免费简约主题
 * 100% original style with ORIGINAL variable names
 */

/* Theme Variables - CRITICAL: Use original variable names */
.oow-popover[data-theme="basic"] {
  --panel-bg: #ffffff;
  --text-color: #333333;
  --muted: #666666;
  --ring: #0ea5e9;
  --accent-1: #0ea5e9;
  --accent-2: #22c55e;
  --accent-3: #fb923c;
  background: var(--panel-bg) !important;
  border: 1px solid rgba(14, 165, 233, 0.2);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);

  /* Unified Button Styles */
  --oow-button-bg: var(--accent-1);
  --oow-button-hover-bg: #0d95d3;
  --oow-button-color: white;
  --oow-button-hover-color: white;
  --oow-button-radius: 6px;
  --oow-button-transition: all 0.2s ease;

  /* Enhanced Markdown Highlight Styles */
  --oow-highlight-heading-color: var(--text-color);
  --oow-highlight-heading-font-weight: 600;
  --oow-highlight-heading-margin-top: 1.2em;
  --oow-highlight-heading-margin-bottom: 0.6em;
  --oow-highlight-h1-font-size: 1.5em;
  --oow-highlight-h2-font-size: 1.25em;
  --oow-highlight-h3-font-size: 1.1em;
  --oow-highlight-h4-font-size: 1em;
  --oow-highlight-h5-font-size: 0.9em;
  --oow-highlight-h6-font-size: 0.8em;
  --oow-highlight-strong-color: var(--accent-2);
  --oow-highlight-strong-font-weight: 600;
  --oow-highlight-em-color: var(--accent-1);
  --oow-highlight-em-font-style: italic;
  --oow-highlight-code-color: #d6336c;
  --oow-highlight-code-bg: rgba(0, 0, 0, 0.05);
  --oow-highlight-code-border-color: var(--ring);
  --oow-highlight-link-color: var(--accent-1);
  --oow-highlight-link-decoration: underline;
  --oow-highlight-link-decoration-thickness: 1px;
  --oow-highlight-link-hover-color: var(--accent-2);
  --oow-highlight-blockquote-margin: 1.2em 0;
  --oow-highlight-blockquote-padding: 0.6em 1em;
  --oow-highlight-blockquote-border-left: 3px solid var(--accent-1);
  --oow-highlight-blockquote-color: var(--muted);
  --oow-highlight-blockquote-bg: rgba(14, 165, 233, 0.05);
  --oow-highlight-hr-height: 1px;
  --oow-highlight-hr-bg: var(--accent-1);
  --oow-highlight-hr-margin: 1.5em 0;
  --oow-highlight-pre-padding: 1em;
  --oow-highlight-pre-bg: rgba(0, 0, 0, 0.05);
  --oow-highlight-pre-border-radius: 6px;
  --oow-highlight-pre-font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  --oow-highlight-pre-font-size: 0.9em;
  --oow-highlight-table-margin: 1.5em 0;
  --oow-highlight-table-border: 1px solid var(--accent-1);
  --oow-highlight-table-cell-padding: 0.5em 0.75em;
  --oow-highlight-table-header-bg: rgba(14, 165, 233, 0.1);
  --oow-highlight-table-header-color: var(--text-color);
  --oow-highlight-table-header-font-weight: 600;
}

`,Et=`/* === Trigger Button - Basic Theme === */
.oow-selection-trigger-button[data-theme="basic"] {
  background: #0d95d3; /* A darker blue for better contrast */
  border: 1px solid #0d95d3;
  box-shadow: 0 2px 8px rgba(14, 165, 233, 0.3);
  color: white;
  border-radius: 6px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.oow-selection-trigger-button[data-theme="basic"]:hover {
  background: #0d95d3; /* Keep background unified */
  border-color: #0d95d3; /* Keep border unified on hover */
  box-shadow: 0 4px 12px rgba(14, 165, 233, 0.4); /* Keep hover glow */
  transform: translateY(-1px); /* Keep hover transform */
}

.oow-selection-trigger-button[data-theme="basic"].activated {
  background: #0d95d3; /* Keep background unified */
  border: 4px dotted #333333; /* Dark, thick, dotted border for high contrast */
  box-shadow: 0 2px 10px rgba(51, 51, 51, 0.4); /* Matching dark glow */
  color: white;
}

`,Dt=`/* === Creative主题专属艺术化动效关键帧 === */

/* 创意画笔描边 - 模拟画笔手绘效果 */
@keyframes creative-brush-stroke {
  0% {
    stroke-dashoffset: 1000;
    opacity: 0;
  }
  20% {
    opacity: 0.3;
  }
  80% {
    opacity: 0.8;
  }
  100% {
    stroke-dashoffset: 0;
    opacity: 1;
  }
}

/* 艺术调色板混合 - 模拟颜料混合效果 */
@keyframes creative-color-mix {
  0% {
    background-position: 0% 50%;
    filter: hue-rotate(0deg);
  }
  25% {
    background-position: 25% 25%;
    filter: hue-rotate(10deg);
  }
  50% {
    background-position: 75% 75%;
    filter: hue-rotate(-5deg);
  }
  75% {
    background-position: 100% 50%;
    filter: hue-rotate(8deg);
  }
  100% {
    background-position: 0% 50%;
    filter: hue-rotate(0deg);
  }
}

/* 创意波浪流动 - 模拟艺术创作灵感流动 */
@keyframes creative-wave-flow {
  0% {
    background-position: 0% 0%;
    transform: translateY(0) rotateZ(0deg);
  }
  33% {
    background-position: 100% 100%;
    transform: translateY(-2px) rotateZ(0.5deg);
  }
  66% {
    background-position: 50% 50%;
    transform: translateY(1px) rotateZ(-0.3deg);
  }
  100% {
    background-position: 0% 0%;
    transform: translateY(0) rotateZ(0deg);
  }
}

/* 艺术渐变显现 - 模拟色彩逐渐渲染 */
@keyframes creative-gradient-reveal {
  0% {
    background-size: 200% 200%;
    background-position: 100% 50%;
    opacity: 0;
    transform: scale(0.95) translateY(5px);
  }
  50% {
    background-size: 200% 200%;
    background-position: 50% 0%;
    opacity: 0.8;
    transform: scale(1.02) translateY(-1px);
  }
  100% {
    background-size: 200% 200%;
    background-position: 0% 50%;
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}

/* 创意手写签名 - 模拟手写签名效果 */
@keyframes creative-handwrite {
  0% {
    clip-path: inset(0 100% 0 0);
    opacity: 0;
  }
  20% {
    opacity: 0.2;
  }
  80% {
    opacity: 0.9;
  }
  100% {
    clip-path: inset(0 0 0 0);
    opacity: 1;
  }
}

/* 艺术灵感闪烁 - 模拟创意灵感迸发 */
@keyframes creative-inspiration-sparkle {
  0%, 100% {
    text-shadow:
      0 0 5px rgba(237, 137, 54, 0.2),
      0 0 10px rgba(237, 137, 54, 0.1);
    transform: scale(1);
  }
  25% {
    text-shadow:
      0 0 8px rgba(237, 137, 54, 0.4),
      0 0 16px rgba(66, 153, 225, 0.2);
    transform: scale(1.02);
  }
  50% {
    text-shadow:
      0 0 12px rgba(159, 122, 234, 0.3),
      0 0 20px rgba(237, 137, 54, 0.2);
    transform: scale(1.03);
  }
  75% {
    text-shadow:
      0 0 6px rgba(66, 153, 225, 0.3),
      0 0 12px rgba(159, 122, 234, 0.2);
    transform: scale(1.01);
  }
}

/* 艺术渐变漂移 - 模拟色彩渐变流动 */
@keyframes creative-gradient-drift {
  0% {
    background-position: 0% 50%;
    filter: brightness(1) saturate(1);
  }
  50% {
    background-position: 100% 50%;
    filter: brightness(1.1) saturate(1.2);
  }
  100% {
    background-position: 0% 50%;
    filter: brightness(1) saturate(1);
  }
}

/* === Creative主题专属文字动效应用 === */

/* 艺术画笔描边 - 标题手绘效果 */
.oow-popover[data-theme="creative"] .info-panel-content h1,
.oow-popover[data-theme="creative"] .info-panel-content h2,
.oow-popover[data-theme="creative"] .info-panel-content h3,
.oow-popover[data-theme="creative"] .info-panel-content h4,
.oow-popover[data-theme="creative"] .info-panel-content h5,
.oow-popover[data-theme="creative"] .info-panel-content h6,
.oow-popover[data-theme="creative"] .etymology-panel h1,
.oow-popover[data-theme="creative"] .etymology-panel h2,
.oow-popover[data-theme="creative"] .etymology-panel h3,
.oow-popover[data-theme="creative"] .etymology-panel h4,
.oow-popover[data-theme="creative"] .etymology-panel h5,
.oow-popover[data-theme="creative"] .etymology-panel h6 {
  background: linear-gradient(135deg, var(--accent-1), var(--accent-2), var(--accent-3));
  background-size: 200% 200%;
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: creative-gradient-reveal 2s ease-out forwards, creative-gradient-drift 4s ease-in-out infinite;
  font-weight: 800;
  position: relative;
  transform: translateZ(0);
}

/* 艺术调色板混合 - 段落色彩流动 */
.oow-popover[data-theme="creative"] .info-panel-content p,
.oow-popover[data-theme="creative"] .etymology-panel p {
  background: linear-gradient(90deg,
    var(--text-color) 0%,
    var(--accent-1) 25%,
    var(--accent-2) 50%,
    var(--accent-3) 75%,
    var(--text-color) 100%);
  background-size: 200% 100%;
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: creative-color-mix 8s ease-in-out infinite;
  font-weight: 500;
  line-height: 1.7;
  transform: translateZ(0);
}

/* 创意灵感闪烁 - 链接交互效果 */
.oow-popover[data-theme="creative"] .info-panel-content a,
.oow-popover[data-theme="creative"] .etymology-panel a {
  color: var(--oow-info-panel-link-color);
  text-decoration: none;
  position: relative;
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  font-weight: 600;
  animation: creative-inspiration-sparkle 3s ease-in-out infinite;
}

.oow-popover[data-theme="creative"] .info-panel-content a::before,
.oow-popover[data-theme="creative"] .etymology-panel a::before {
  content: '';
  position: absolute;
  bottom: -2px;
  left: 0;
  width: 100%;
  height: 3px;
  background: linear-gradient(90deg, var(--accent-1), var(--accent-2), var(--accent-3));
  border-radius: 2px;
  transform: scaleX(0);
  transform-origin: left;
  transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  animation: creative-wave-flow 2s ease-in-out infinite;
}

.oow-popover[data-theme="creative"] .info-panel-content a:hover,
.oow-popover[data-theme="creative"] .etymology-panel a:hover {
  color: var(--oow-info-panel-link-hover);
  transform: translateY(-2px);
}

.oow-popover[data-theme="creative"] .info-panel-content a:hover::before,
.oow-popover[data-theme="creative"] .etymology-panel a:hover::before {
  transform: scaleX(1);
}

/* 艺术手写效果 - 列表项创意编号 */
.oow-popover[data-theme="creative"] .info-panel-content ul li,
.oow-popover[data-theme="creative"] .info-panel-content ol li,
.oow-popover[data-theme="creative"] .etymology-panel ul li,
.oow-popover[data-theme="creative"] .etymology-panel ol li {
  animation: creative-handwrite 1.5s ease-out forwards;
  position: relative;
  padding-left: 25px;
  margin-bottom: 0.8em;
  transform: translateZ(0);
}

.oow-popover[data-theme="creative"] .info-panel-content ul li::before,
.oow-popover[data-theme="creative"] .info-panel-content ol li::before,
.oow-popover[data-theme="creative"] .etymology-panel ul li::before,
.oow-popover[data-theme="creative"] .etymology-panel ol li::before {
  content: counter(list-item);
  position: absolute;
  left: 0;
  top: 0;
  width: 20px;
  height: 20px;
  background: linear-gradient(135deg, var(--accent-1), var(--accent-2));
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.75em;
  font-weight: 700;
  animation: creative-inspiration-sparkle 4s ease-in-out infinite;
}

/* 艺术强调效果 - 粗体文字 */
.oow-popover[data-theme="creative"] .info-panel-content strong,
.oow-popover[data-theme="creative"] .etymology-panel strong {
  background: linear-gradient(135deg, var(--accent-1), var(--accent-2));
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  font-weight: 700;
  animation: creative-gradient-reveal 1.5s ease-out forwards;
  position: relative;
  transform: translateZ(0);
}

.oow-popover[data-theme="creative"] .info-panel-content strong::after,
.oow-popover[data-theme="creative"] .etymology-panel strong::after {
  content: '';
  position: absolute;
  bottom: -1px;
  left: 0;
  width: 100%;
  height: 2px;
  background: linear-gradient(90deg, var(--accent-1), var(--accent-2));
  border-radius: 1px;
  opacity: 0.6;
  animation: creative-wave-flow 3s ease-in-out infinite;
}

/* 艺术斜体效果 - 斜体文字 */
.oow-popover[data-theme="creative"] .info-panel-content em,
.oow-popover[data-theme="creative"] .etymology-panel em {
  color: var(--accent-3);
  font-style: italic;
  font-weight: 500;
  animation: creative-wave-flow 4s ease-in-out infinite;
  transform: translateZ(0);
}

/* 艺术代码块 - 创意代码展示 */
.oow-popover[data-theme="creative"] .info-panel-content code,
.oow-popover[data-theme="creative"] .etymology-panel code {
  background: linear-gradient(135deg,
    var(--oow-info-panel-code-bg) 0%,
    rgba(237, 137, 54, 0.1) 50%,
    var(--oow-info-panel-code-bg) 100%);
  color: var(--oow-info-panel-code-color);
  padding: 0.3em 0.6em;
  border-radius: 8px;
  font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  border: 2px solid transparent;
  background-clip: padding-box;
  position: relative;
  animation: creative-gradient-reveal 1s ease-out forwards, creative-gradient-drift 5s ease-in-out infinite;
  transform: translateZ(0);
}

.oow-popover[data-theme="creative"] .info-panel-content code::before,
.oow-popover[data-theme="creative"] .etymology-panel code::before {
  content: '';
  position: absolute;
  inset: -2px;
  background: linear-gradient(135deg, var(--accent-1), var(--accent-2), var(--accent-3));
  border-radius: 10px;
  z-index: -1;
  animation: creative-gradient-drift 6s linear infinite;
}

/* 艺术引用块 - 创意引用设计 */
.oow-popover[data-theme="creative"] .info-panel-content blockquote,
.oow-popover[data-theme="creative"] .etymology-panel blockquote {
  margin: var(--oow-highlight-blockquote-margin);
  padding: var(--oow-highlight-blockquote-padding);
  border-left: 5px solid var(--oow-info-panel-blockquote-border);
  background:
    linear-gradient(135deg, rgba(237, 137, 54, 0.05) 0%, rgba(66, 153, 225, 0.05) 100%),
    var(--oow-info-panel-code-bg);
  color: var(--oow-info-panel-blockquote-color);
  border-radius: 0 12px 12px 0;
  position: relative;
  animation: creative-gradient-reveal 1.5s ease-out forwards;
  transform: translateZ(0);
}

.oow-popover[data-theme="creative"] .info-panel-content blockquote::before,
.oow-popover[data-theme="creative"] .etymology-panel blockquote::before {
  content: '🎨';
  position: absolute;
  top: -15px;
  left: 15px;
  font-size: 2em;
  opacity: 0.6;
  animation: creative-inspiration-sparkle 4s ease-in-out infinite;
}

/* 艺术分隔线 - 创意分隔效果 */
.oow-popover[data-theme="creative"] .info-panel-content hr,
.oow-popover[data-theme="creative"] .etymology-panel hr {
  border: none;
  height: 3px;
  background: linear-gradient(90deg,
    transparent 0%,
    var(--accent-1) 20%,
    var(--accent-2) 50%,
    var(--accent-3) 80%,
    transparent 100%);
  border-radius: 2px;
  margin: 2.5em 0;
  animation: creative-gradient-drift 3s ease-in-out infinite;
  position: relative;
}

.oow-popover[data-theme="creative"] .info-panel-content hr::after,
.oow-popover[data-theme="creative"] .etymology-panel hr::after {
  content: '✨';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: white;
  padding: 0 10px;
  font-size: 0.9em;
  animation: creative-inspiration-sparkle 2s ease-in-out infinite;
}

/* 艺术预格式化文本 - 创意代码展示 */
.oow-popover[data-theme="creative"] .info-panel-content pre,
.oow-popover[data-theme="creative"] .etymology-panel pre {
  background:
    repeating-linear-gradient(
      45deg,
      transparent,
      transparent 10px,
      rgba(237, 137, 54, 0.02) 10px,
      rgba(237, 137, 54, 0.02) 20px
    ),
    var(--oow-highlight-pre-bg);
  border: 2px solid var(--accent-1);
  border-radius: 12px;
  padding: var(--oow-highlight-pre-padding);
  overflow-x: auto;
  font-family: var(--oow-highlight-pre-font-family);
  font-size: var(--oow-highlight-pre-font-size);
  color: var(--text-color);
  position: relative;
  animation: creative-gradient-reveal 1.5s ease-out forwards;
  transform: translateZ(0);
}

.oow-popover[data-theme="creative"] .info-panel-content pre::before,
.oow-popover[data-theme="creative"] .etymology-panel pre::before {
  content: '🎯';
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 1.2em;
  opacity: 0.5;
  animation: creative-inspiration-sparkle 3s ease-in-out infinite;
}

/* 艺术表格 - 创意表格设计 */
.oow-popover[data-theme="creative"] .info-panel-content table,
.oow-popover[data-theme="creative"] .etymology-panel table {
  width: 100%;
  border-collapse: collapse;
  margin: var(--oow-highlight-table-margin);
  border: 2px solid var(--accent-1);
  border-radius: 12px;
  overflow: hidden;
  animation: creative-gradient-reveal 1.5s ease-out forwards;
  transform: translateZ(0);
}

.oow-popover[data-theme="creative"] .info-panel-content table th,
.oow-popover[data-theme="creative"] .etymology-panel table th {
  background: linear-gradient(135deg, var(--accent-1), var(--accent-2));
  color: white;
  font-weight: var(--oow-highlight-table-header-font-weight);
  padding: var(--oow-highlight-table-cell-padding);
  text-align: left;
  animation: creative-gradient-drift 4s ease-in-out infinite;
}

.oow-popover[data-theme="creative"] .info-panel-content table td,
.oow-popover[data-theme="creative"] .etymology-panel table td {
  padding: var(--oow-highlight-table-cell-padding);
  border-bottom: 1px solid rgba(237, 137, 54, 0.1);
  color: var(--text-color);
  animation: creative-handwrite 1s ease-out forwards;
}

.oow-popover[data-theme="creative"] .info-panel-content table tr:hover td,
.oow-popover[data-theme="creative"] .etymology-panel table tr:hover td {
  background: linear-gradient(90deg, rgba(237, 137, 54, 0.1) 0%, rgba(66, 153, 225, 0.1) 100%);
  animation: creative-wave-flow 1s ease-in-out infinite;
}

/* 性能优化 - GPU加速 */
@media (min-width: 768px) {
  .oow-popover[data-theme="creative"] .info-panel-content *,
  .oow-popover[data-theme="creative"] .etymology-panel * {
    transform: translateZ(0);
    will-change: transform, opacity;
  }
}

/* 减少动效 - 无障碍支持 */
@media (prefers-reduced-motion: reduce) {
  .oow-popover[data-theme="creative"] .info-panel-content *,
  .oow-popover[data-theme="creative"] .etymology-panel * {
    animation: none !important;
    background: none !important;
    -webkit-text-fill-color: var(--text-color) !important;
  }
}`,Ot=`/* Creative主题的translation和contextual-analysis样式 */
.oow-popover[data-theme="creative"] .translation[data-style="gradient"] {
  background: transparent;
  border: none;
  border-radius: 0;
  padding: 0;
  box-shadow: none;
  background-image: linear-gradient(135deg, #ed8936, #4299e1, #9f7aea);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}

.oow-popover[data-theme="creative"] .contextual-analysis[data-style="gradient"] {
  background: transparent;
  border: none;
  border-radius: 0;
  padding: 0;
  box-shadow: none;
  background-image: linear-gradient(135deg, #4299e1, #9f7aea);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}

.oow-popover[data-theme="creative"] .translation .text {
  color: #2d3748;
  font-weight: 700;
}

.oow-popover[data-theme="creative"] .contextual-analysis .text {
  color: #4a5568;
  font-weight: 400;
}

/* Creative主题的Info Panel和Etymology Panel样式 */
.oow-popover[data-theme="creative"] .info-panel-content,
.oow-popover[data-theme="creative"] .etymology-panel {
  /* 艺术创意风格：使用手写体风格的标题字体，艺术化的排版 */
  --oow-info-panel-heading-color: #2d3748;
  --oow-info-panel-heading-weight: 700;
  --oow-info-panel-heading-margin-top: 1.4em;
  --oow-info-panel-heading-margin-bottom: 0.8em;
  --oow-info-panel-paragraph-color: #2d3748;
  --oow-info-panel-paragraph-margin-bottom: 1em;
  --oow-info-panel-line-height: 1.65;
  --oow-info-panel-letter-spacing: 0.02em;
  --oow-info-panel-font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  --oow-info-panel-list-color: #2d3748;
  --oow-info-panel-blockquote-color: #718096;
  --oow-info-panel-blockquote-border: #ed8936;
  --oow-info-panel-code-color: #e53e3e;
  --oow-info-panel-code-bg: rgba(255, 255, 255, 0.8);
  --oow-info-panel-link-color: #ed8936;
  --oow-info-panel-link-hover: #4299e1;
}

`,kt=`/*
 * Origin of Words - Creative Theme (Free)
 * 创意主题 - 免费创意主题
 * 100% original style with ORIGINAL variable names
 */

/* Theme Variables - CRITICAL: Use original variable names */
.oow-popover[data-theme="creative"] {
  --panel-bg: #ffffff;
  --text-color: #2d3748;
  --muted: #718096;
  --ring: #ed8936;
  --accent-1: #ed8936;
  --accent-2: #4299e1;
  --accent-3: #9f7aea;
  background: linear-gradient(135deg, #ffffff, #f7fafc) !important;
  border: 2px solid var(--accent-1);
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.12);
  border-radius: 12px;

  /* Unified Button Styles */
  --oow-button-bg: var(--accent-1);
  --oow-button-hover-bg: #dd6b20;
  --oow-button-color: white;
  --oow-button-hover-color: white;
  --oow-button-radius: 8px;
  --oow-button-transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  /* Enhanced Markdown Highlight Styles */
  --oow-highlight-heading-color: var(--text-color);
  --oow-highlight-heading-font-weight: 700;
  --oow-highlight-heading-margin-top: 1.4em;
  --oow-highlight-heading-margin-bottom: 0.8em;
  --oow-highlight-h1-font-size: 1.7em;
  --oow-highlight-h2-font-size: 1.4em;
  --oow-highlight-h3-font-size: 1.25em;
  --oow-highlight-h4-font-size: 1.15em;
  --oow-highlight-h5-font-size: 1.05em;
  --oow-highlight-h6-font-size: 0.95em;
  --oow-highlight-strong-color: var(--accent-2);
  --oow-highlight-strong-font-weight: 700;
  --oow-highlight-em-color: var(--accent-3);
  --oow-highlight-em-font-style: italic;
  --oow-highlight-code-color: #e53e3e;
  --oow-highlight-code-bg: rgba(255, 255, 255, 0.8);
  --oow-highlight-code-border-color: var(--ring);
  --oow-highlight-link-color: var(--accent-1);
  --oow-highlight-link-decoration: underline;
  --oow-highlight-link-decoration-thickness: 2px;
  --oow-highlight-link-hover-color: var(--accent-2);
  --oow-highlight-blockquote-margin: 1.4em 0;
  --oow-highlight-blockquote-padding: 1em 1.5em;
  --oow-highlight-blockquote-border-left: 5px solid var(--accent-1);
  --oow-highlight-blockquote-color: var(--muted);
  --oow-highlight-blockquote-bg: rgba(237, 137, 54, 0.1);
  --oow-highlight-hr-height: 3px;
  --oow-highlight-hr-bg: linear-gradient(90deg, var(--accent-1), var(--accent-2), var(--accent-3));
  --oow-highlight-hr-margin: 2em 0;
  --oow-highlight-pre-padding: 1.5em;
  --oow-highlight-pre-bg: rgba(255, 255, 255, 0.9);
  --oow-highlight-pre-border-radius: 10px;
  --oow-highlight-pre-font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  --oow-highlight-pre-font-size: 1em;
  --oow-highlight-table-margin: 2em 0;
  --oow-highlight-table-border: 2px solid var(--accent-1);
  --oow-highlight-table-cell-padding: 0.7em 1em;
  --oow-highlight-table-header-bg: rgba(237, 137, 54, 0.15);
  --oow-highlight-table-header-color: var(--text-color);
  --oow-highlight-table-header-font-weight: 700;
}

/* Creative wave background effect */
.oow-popover[data-theme="creative"]::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background:
    radial-gradient(circle at 20% 30%, rgba(237, 137, 54, 0.1) 0px, transparent 50px),
    radial-gradient(circle at 80% 70%, rgba(66, 153, 225, 0.1) 0px, transparent 50px),
    radial-gradient(circle at 50% 20%, rgba(159, 122, 234, 0.1) 0px, transparent 50px);
  z-index: 0;
  pointer-events: none;
}

.oow-popover[data-theme="creative"] > * {
  position: relative;
  z-index: 1;
}

`,At=`/* === Trigger Button - Creative Theme === */
.oow-selection-trigger-button[data-theme="creative"] {
  background: #2d3748; /* Unified dark background for high contrast */
  border: 2px solid transparent;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
  color: white;
  border-radius: 10px; /* Keep original default radius */
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.oow-selection-trigger-button[data-theme="creative"]:hover {
  background: #2d3748; /* Keep background unified */
  border-color: #718096; /* Use muted color for subtle hover feedback */
  box-shadow: 0 6px 28px rgba(0, 0, 0, 0.3);
  transform: translateY(-3px) scale(1.08);
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.oow-selection-trigger-button[data-theme="creative"].activated {
  background: #2d3748; /* Keep background unified */
  border-radius: 999px; /* Unique pill shape for activation */
  border: 4px double #9f7aea; /* Unique, high-contrast purple double border */
  box-shadow: 0 4px 20px rgba(159, 122, 234, 0.4); /* Matching purple glow */
  color: white;
  animation: none;
  transform: none;
}

`,jt=`/* Cyberpunk grid effect */
.oow-popover[data-theme="cyberpunk"]::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image:
    linear-gradient(rgba(114, 9, 183, 0.15) 1px, transparent 1px),
    linear-gradient(90deg, rgba(114, 9, 183, 0.15) 1px, transparent 1px),
    radial-gradient(circle at 20% 30%, rgba(247, 37, 133, 0.1) 2px, transparent 2px),
    radial-gradient(circle at 80% 70%, rgba(67, 97, 238, 0.1) 2px, transparent 2px);
  background-size: 25px 25px, 25px 25px, 50px 50px, 50px 50px;
  background-position: 0 0, 0 0, 25px 25px, 25px 25px;
  opacity: 0.4;
  pointer-events: none;
  z-index: 0;
  animation: cyberpunk-grid 8s linear infinite, cyberpunk-pulse 4s ease-in-out infinite alternate;
}

@keyframes cyberpunk-grid {
  from {
    background-position: 0 0, 0 0, 0 0, 0 0;
  }
  to {
    background-position: 25px 25px, 25px 25px, 25px 25px, 25px 25px;
  }
}

@keyframes cyberpunk-pulse {
  0%, 100% {
    opacity: 0.4;
  }
  50% {
    opacity: 0.6;
  }
}

.oow-popover[data-theme="cyberpunk"] > * {
  position: relative;
  z-index: 1;
}

.oow-popover[data-theme="cyberpunk"] .header-title {
  color: var(--accent-1);
  text-shadow: 0 0 15px rgba(247, 37, 133, 0.4), 2px 2px 0 var(--accent-2);
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 3px;
  font-size: 1.2em;
  animation: cyberpunk-glow 2s infinite alternate;
}

@keyframes cyberpunk-glow {
  0%, 100% {
    text-shadow: 0 0 15px rgba(247, 37, 133, 0.4), 2px 2px 0 var(--accent-2);
  }
  50% {
    text-shadow: 0 0 25px rgba(247, 37, 133, 0.6), 0 0 35px rgba(67, 97, 238, 0.3), 2px 2px 0 var(--accent-2);
  }
}

.oow-popover[data-theme="cyberpunk"] .header-logo {
  background: linear-gradient(135deg, var(--accent-1), var(--accent-2));
  border: 2px solid var(--ring);
  color: white;
  box-shadow: 0 0 25px var(--accent-1), inset 0 0 10px rgba(255, 255, 255, 0.3);
  font-weight: 800;
  font-size: 1.1em;
  border-radius: 6px;
  animation: cyberpunk-logo-pulse 1.5s infinite;
}

@keyframes cyberpunk-logo-pulse {
  0%, 100% {
    box-shadow: 0 0 25px var(--accent-1), inset 0 0 10px rgba(255, 255, 255, 0.3);
  }
  50% {
    box-shadow: 0 0 35px var(--accent-1), 0 0 45px var(--accent-2), inset 0 0 15px rgba(255, 255, 255, 0.5);
  }
}

.oow-popover[data-theme="cyberpunk"] .section-title {
  color: var(--accent-3);
  text-shadow: 0 0 12px rgba(76, 201, 240, 0.3);
  text-transform: uppercase;
  letter-spacing: 2px;
  font-weight: 700;
  font-size: 1.1em;
  background: linear-gradient(90deg, transparent 50%, rgba(76, 201, 240, 0.1) 50%);
  background-size: 200% 100%;
  animation: cyberpunk-text-scan 3s linear infinite;
}

@keyframes cyberpunk-text-scan {
  0% {
    background-position: 100% 0;
  }
  100% {
    background-position: -100% 0;
  }
}

.oow-popover[data-theme="cyberpunk"] .def-item .pos {
  color: var(--accent-2);
  text-shadow: 0 0 10px var(--accent-2);
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 1px;
  font-size: 0.9em;
}

.oow-popover[data-theme="cyberpunk"] .def-item .meaning {
  color: var(--text-color);
}

.oow-popover[data-theme="cyberpunk"] .def-item .example {
  color: var(--muted);
  border-left: 4px solid var(--accent-2);
  padding-left: 12px;
  background: rgba(67, 97, 238, 0.08);
  border-radius: 0 6px 6px 0;
  margin-left: 2px;
}

.oow-popover[data-theme="cyberpunk"] .eq .bar {
  background: linear-gradient(180deg, var(--accent-1), var(--accent-2), var(--accent-3));
  box-shadow: 0 0 20px var(--accent-1), inset 0 1px 0 rgba(255, 255, 255, 0.2);
  border-radius: 6px;
  height: 10px;
  animation: cyberpunk-bar-pulse 2s infinite;
}

@keyframes cyberpunk-bar-pulse {
  0%, 100% {
    box-shadow: 0 0 20px var(--accent-1), inset 0 1px 0 rgba(255, 255, 255, 0.2);
  }
  50% {
    box-shadow: 0 0 30px var(--accent-1), 0 0 40px var(--accent-2), inset 0 1px 0 rgba(255, 255, 255, 0.3);
    height: 12px;
  }
}

.oow-popover[data-theme="cyberpunk"] .modal-header {
  border-bottom: 3px solid var(--ring);
  background: rgba(114, 9, 183, 0.15);
}

`,Mt=`/* === Cyberpunk主题文字动效 - 标题扫描线显示 === */

/* 标题HUD扫描线动画 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content h1,
.oow-popover[data-theme="cyberpunk"] .info-panel-content h2,
.oow-popover[data-theme="cyberpunk"] .info-panel-content h3,
.oow-popover[data-theme="cyberpunk"] .info-panel-content h4,
.oow-popover[data-theme="cyberpunk"] .info-panel-content h5,
.oow-popover[data-theme="cyberpunk"] .info-panel-content h6,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h1,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h2,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h3,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h4,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h5,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h6 {
  animation: cyberpunk-hud-scan 0.8s ease-out forwards, cyberpunk-neon-flicker 3s ease-in-out infinite 1s;
  clip-path: polygon(0 0, 100% 0, 100% 0, 0 0);
  animation-fill-mode: forwards;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  position: relative;
  will-change: clip-path, opacity, text-shadow;
}

/* 标题扫描线延迟 - 模拟系统扫描序列 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content h1,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h1 {
  animation-delay: 0s, 1s;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content h2,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h2 {
  animation-delay: 0.2s, 1.3s;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content h3,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h3 {
  animation-delay: 0.4s, 1.6s;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content h4,
.oow-popover[data-theme="cyberpunk"] .info-panel-content h5,
.oow-popover[data-theme="cyberpunk"] .info-panel-content h6,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h4,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h5,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h6 {
  animation-delay: 0.6s, 1.9s;
}

/* 标题全息投影效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content h1::after,
.oow-popover[data-theme="cyberpunk"] .info-panel-content h2::after,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h1::after,
.oow-popover[data-theme="cyberpunk"] .etymology-panel h2::after {
  content: attr(data-text);
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  z-index: -1;
  animation: cyberpunk-hologram 4s ease-in-out infinite;
  opacity: 0.3;
  filter: blur(1px);
}

/* === Cyberpunk主题文字动效 - 段落数据流和故障艺术 === */

/* 段落数据流进入动画 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content p,
.oow-popover[data-theme="cyberpunk"] .etymology-panel p {
  animation: cyberpunk-glitch 0.3s ease-out forwards, cyberpunk-digital-noise 5s ease-in-out infinite 1s;
  opacity: 0;
  animation-fill-mode: forwards;
  position: relative;
  overflow: hidden;
  will-change: transform, filter, opacity;
  background: linear-gradient(
    90deg,
    transparent 0%,
    rgba(67, 97, 238, 0.1) 50%,
    transparent 100%
  );
  background-size: 200% 100%;
  background-position: 100% 50%;
}

/* 段落二进制码背景效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content p::before,
.oow-popover[data-theme="cyberpunk"] .etymology-panel p::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image:
    repeating-linear-gradient(
      0deg,
      transparent,
      transparent 2px,
      rgba(67, 97, 238, 0.03) 2px,
      rgba(67, 97, 238, 0.03) 4px
    );
  background-size: 100% 8px;
  animation: cyberpunk-matrix-rain 8s linear infinite;
  pointer-events: none;
  z-index: -1;
}

/* 段落数据流动画 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content p::after,
.oow-popover[data-theme="cyberpunk"] .etymology-panel p::after {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 2px;
  background: linear-gradient(
    90deg,
    transparent,
    rgba(247, 37, 133, 0.8),
    rgba(67, 97, 238, 0.8),
    transparent
  );
  animation: cyberpunk-data-flow 3s ease-in-out infinite;
  pointer-events: none;
  z-index: 1;
}

/* 段落延迟显示 - 模拟数据传输序列 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content p:nth-child(1),
.oow-popover[data-theme="cyberpunk"] .etymology-panel p:nth-child(1) {
  animation-delay: 0.3s, 1.5s;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content p:nth-child(2),
.oow-popover[data-theme="cyberpunk"] .etymology-panel p:nth-child(2) {
  animation-delay: 0.6s, 1.8s;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content p:nth-child(3),
.oow-popover[data-theme="cyberpunk"] .etymology-panel p:nth-child(3) {
  animation-delay: 0.9s, 2.1s;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content p:nth-child(n+4),
.oow-popover[data-theme="cyberpunk"] .etymology-panel p:nth-child(n+4) {
  animation-delay: 1.2s, 2.4s;
}

/* 段落悬停故障效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content p:hover,
.oow-popover[data-theme="cyberpunk"] .etymology-panel p:hover {
  animation: cyberpunk-glitch 0.1s ease-in-out infinite;
  background-position: 0% 50%;
  transition: background-position 0.3s ease;
}

/* === Cyberpunk主题文字动效 - 列表终端命令行效果 === */

/* 列表项终端显示动画 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content ul li,
.oow-popover[data-theme="cyberpunk"] .info-panel-content ol li,
.oow-popover[data-theme="cyberpunk"] .etymology-panel ul li,
.oow-popover[data-theme="cyberpunk"] .etymology-panel ol li {
  animation: cyberpunk-hud-scan 0.4s ease-out forwards;
  opacity: 0;
  animation-fill-mode: forwards;
  position: relative;
  padding-left: 20px;
  font-family: 'Courier New', monospace;
  will-change: clip-path, opacity;
}

/* 列表项命令行前缀 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content ul li::before,
.oow-popover[data-theme="cyberpunk"] .info-panel-content ol li::before,
.oow-popover[data-theme="cyberpunk"] .etymology-panel ul li::before,
.oow-popover[data-theme="cyberpunk"] .etymology-panel ol li::before {
  content: '>';
  position: absolute;
  left: 0;
  color: var(--accent-2, #4361ee);
  font-weight: bold;
  animation: cyberpunk-neon-flicker 2s ease-in-out infinite;
  animation-delay: calc(var(--item-index, 1) * 0.2s);
}

/* 有序列表的数字样式 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content ol li::before,
.oow-popover[data-theme="cyberpunk"] .etymology-panel ol li::before {
  content: counter(list-item) '>';
  color: var(--accent-1, #f72585);
}

/* 列表项终端光标 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content ul li::after,
.oow-popover[data-theme="cyberpunk"] .info-panel-content ol li::after,
.oow-popover[data-theme="cyberpunk"] .etymology-panel ul li::after,
.oow-popover[data-theme="cyberpunk"] .etymology-panel ol li::after {
  content: '_';
  position: absolute;
  right: 5px;
  color: var(--accent-3, #4cc9f0);
  animation: cyberpunk-cursor 1s ease-in-out infinite;
  opacity: 0;
}

/* 列表项悬停光标显示 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content ul li:hover::after,
.oow-popover[data-theme="cyberpunk"] .info-panel-content ol li:hover::after,
.oow-popover[data-theme="cyberpunk"] .etymology-panel ul li:hover::after,
.oow-popover[data-theme="cyberpunk"] .etymology-panel ol li:hover::after {
  opacity: 1;
}

/* 列表项延迟显示 - 模拟命令行输入序列 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content ul li:nth-child(1),
.oow-popover[data-theme="cyberpunk"] .info-panel-content ol li:nth-child(1),
.oow-popover[data-theme="cyberpunk"] .etymology-panel ul li:nth-child(1),
.oow-popover[data-theme="cyberpunk"] .etymology-panel ol li:nth-child(1) {
  animation-delay: 0.5s;
  --item-index: 1;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content ul li:nth-child(2),
.oow-popover[data-theme="cyberpunk"] .info-panel-content ol li:nth-child(2),
.oow-popover[data-theme="cyberpunk"] .etymology-panel ul li:nth-child(2),
.oow-popover[data-theme="cyberpunk"] .etymology-panel ol li:nth-child(2) {
  animation-delay: 0.8s;
  --item-index: 2;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content ul li:nth-child(3),
.oow-popover[data-theme="cyberpunk"] .info-panel-content ol li:nth-child(3),
.oow-popover[data-theme="cyberpunk"] .etymology-panel ul li:nth-child(3),
.oow-popover[data-theme="cyberpunk"] .etymology-panel ol li:nth-child(3) {
  animation-delay: 1.1s;
  --item-index: 3;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content ul li:nth-child(4),
.oow-popover[data-theme="cyberpunk"] .info-panel-content ol li:nth-child(4),
.oow-popover[data-theme="cyberpunk"] .etymology-panel ul li:nth-child(4),
.oow-popover[data-theme="cyberpunk"] .etymology-panel ol li:nth-child(4) {
  animation-delay: 1.4s;
  --item-index: 4;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content ul li:nth-child(n+5),
.oow-popover[data-theme="cyberpunk"] .info-panel-content ol li:nth-child(n+5),
.oow-popover[data-theme="cyberpunk"] .etymology-panel ul li:nth-child(n+5),
.oow-popover[data-theme="cyberpunk"] .etymology-panel ol li:nth-child(n+5) {
  animation-delay: 1.7s;
  --item-index: 5;
}

/* 列表项悬停故障效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content ul li:hover,
.oow-popover[data-theme="cyberpunk"] .info-panel-content ol li:hover,
.oow-popover[data-theme="cyberpunk"] .etymology-panel ul li:hover,
.oow-popover[data-theme="cyberpunk"] .etymology-panel ol li:hover {
  animation: cyberpunk-glitch 0.15s ease-in-out infinite;
  color: var(--accent-2, #4361ee);
  background: rgba(67, 97, 238, 0.1);
  padding-left: 25px;
  transition: all 0.2s ease;
}

/* === Cyberpunk主题文字动效 - 霓虹灯管闪烁效果 === */

/* 强调文本霓虹灯管效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content strong,
.oow-popover[data-theme="cyberpunk"] .etymology-panel strong {
  animation: cyberpunk-neon-flicker 2.5s ease-in-out infinite;
  color: var(--accent-1, #f72585);
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  text-shadow:
    0 0 10px currentColor,
    0 0 20px currentColor,
    0 0 30px currentColor,
    0 0 40px var(--accent-1, #f72585);
  will-change: text-shadow, opacity;
}

/* 强调文本悬停增强霓虹效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content strong:hover,
.oow-popover[data-theme="cyberpunk"] .etymology-panel strong:hover {
  animation-duration: 0.8s;
  text-shadow:
    0 0 15px currentColor,
    0 0 30px currentColor,
    0 0 45px currentColor,
    0 0 60px var(--accent-1, #f72585),
    0 0 80px var(--accent-2, #4361ee);
  transform: scale(1.05);
  transition: all 0.3s ease;
}

/* 斜体文本霓虹管效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content em,
.oow-popover[data-theme="cyberpunk"] .etymology-panel em {
  color: var(--accent-3, #4cc9f0);
  font-style: italic;
  animation: cyberpunk-neon-flicker 3s ease-in-out infinite;
  animation-delay: 0.5s;
  text-shadow:
    0 0 8px currentColor,
    0 0 16px currentColor,
    0 0 24px var(--accent-3, #4cc9f0);
  will-change: text-shadow, opacity;
}

/* 斜体文本悬停增强效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content em:hover,
.oow-popover[data-theme="cyberpunk"] .etymology-panel em:hover {
  animation-duration: 1.2s;
  text-shadow:
    0 0 12px currentColor,
    0 0 24px currentColor,
    0 0 36px currentColor,
    0 0 48px var(--accent-3, #4cc9f0);
  animation: cyberpunk-glitch 0.2s ease-in-out infinite, cyberpunk-neon-flicker 1.2s ease-in-out infinite;
}

/* 代码块霓虹效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content code,
.oow-popover[data-theme="cyberpunk"] .etymology-panel code {
  color: var(--accent-3, #4cc9f0);
  background: rgba(0, 0, 0, 0.8);
  border: 1px solid var(--accent-3, #4cc9f0);
  padding: 4px 8px;
  font-family: 'Courier New', monospace;
  font-weight: bold;
  animation: cyberpunk-neon-flicker 4s ease-in-out infinite;
  text-shadow: 0 0 8px currentColor;
  box-shadow:
    0 0 10px rgba(76, 201, 240, 0.3),
    inset 0 0 10px rgba(76, 201, 240, 0.1);
  will-change: text-shadow, box-shadow;
}

/* 预格式化代码块终端效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content pre,
.oow-popover[data-theme="cyberpunk"] .etymology-panel pre {
  background: linear-gradient(135deg, rgba(0, 0, 0, 0.9), rgba(0, 0, 0, 0.7));
  border: 2px solid var(--accent-2, #4361ee);
  border-radius: 4px;
  padding: 16px;
  font-family: 'Courier New', monospace;
  color: #00ff00;
  position: relative;
  overflow: hidden;
  box-shadow:
    0 0 20px rgba(67, 97, 238, 0.5),
    inset 0 0 20px rgba(67, 97, 238, 0.2);
  animation: cyberpunk-electric-flow 6s linear infinite;
  will-change: box-shadow, background;
}

/* 代码块扫描线效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content pre::before,
.oow-popover[data-theme="cyberpunk"] .etymology-panel pre::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background: linear-gradient(90deg, transparent, var(--accent-3, #4cc9f0), transparent);
  animation: cyberpunk-data-flow 2s linear infinite;
  z-index: 1;
}

/* === Cyberpunk主题文字动效 - 综合效果 === */

/* 链接电子数据流效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content a,
.oow-popover[data-theme="cyberpunk"] .etymology-panel a {
  color: var(--accent-1, #ff006e);
  text-decoration: none;
  position: relative;
  padding: 2px 4px;
  background: linear-gradient(
    90deg,
    transparent 0%,
    rgba(247, 37, 133, 0.2) 50%,
    transparent 100%
  );
  background-size: 200% 100%;
  background-position: 100% 50%;
  transition: all 0.3s ease;
  animation: cyberpunk-neon-flicker 3s ease-in-out infinite;
  will-change: background-position, color, text-shadow;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content a:hover,
.oow-popover[data-theme="cyberpunk"] .etymology-panel a:hover {
  color: var(--accent-2, #4361ee);
  background-position: 0% 50%;
  text-shadow: 0 0 15px currentColor;
  animation: cyberpunk-glitch 0.1s ease-in-out infinite;
  transform: translateY(-1px);
}

/* 引用块电路板效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content blockquote,
.oow-popover[data-theme="cyberpunk"] .etymology-panel blockquote {
  border-left: 4px solid var(--accent-2, #7209b7);
  padding-left: 16px;
  margin: 1.5em 0;
  position: relative;
  background: linear-gradient(
    90deg,
    rgba(114, 9, 183, 0.1),
    rgba(67, 97, 238, 0.05)
  );
  animation: cyberpunk-electric-flow 8s linear infinite;
  will-change: border-color, box-shadow;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content blockquote:hover,
.oow-popover[data-theme="cyberpunk"] .etymology-panel blockquote:hover {
  border-left-width: 6px;
  padding-left: 20px;
  animation-duration: 4s;
  box-shadow:
    -4px 0 20px rgba(114, 9, 183, 0.4),
    inset 2px 0 10px rgba(67, 97, 238, 0.2);
}

/* 表格HUD扫描效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content table,
.oow-popover[data-theme="cyberpunk"] .etymology-panel table {
  border-collapse: separate;
  border-spacing: 0;
  border: 2px solid var(--accent-2, #4361ee);
  border-radius: 4px;
  overflow: hidden;
  animation: cyberpunk-hud-scan 1s ease-out forwards;
  opacity: 0;
  animation-fill-mode: forwards;
  will-change: opacity, transform;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content table th,
.oow-popover[data-theme="cyberpunk"] .etymology-panel table th {
  background: linear-gradient(135deg, var(--accent-1, #f72585), var(--accent-2, #4361ee));
  color: white;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  padding: 12px 16px;
  animation: cyberpunk-neon-flicker 2s ease-in-out infinite;
}

/* 分割线数字扫描效果 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content hr,
.oow-popover[data-theme="cyberpunk"] .etymology-panel hr {
  border: none;
  height: 2px;
  background: linear-gradient(
    90deg,
    transparent 0%,
    var(--accent-1, #f72585) 20%,
    var(--accent-2, #4361ee) 50%,
    var(--accent-3, #4cc9f0) 80%,
    transparent 100%
  );
  background-size: 200% 100%;
  animation: cyberpunk-data-flow 3s linear infinite;
  margin: 2em 0;
  position: relative;
  will-change: background-position;
}

.oow-popover[data-theme="cyberpunk"] .info-panel-content hr::after,
.oow-popover[data-theme="cyberpunk"] .etymology-panel hr::after {
  content: '';
  position: absolute;
  top: -2px;
  left: 0;
  right: 0;
  height: 6px;
  background: linear-gradient(
    90deg,
    transparent,
    rgba(247, 37, 133, 0.4),
    rgba(67, 97, 238, 0.4),
    transparent
  );
  animation: cyberpunk-data-flow 2s linear infinite reverse;
  filter: blur(2px);
}

`,Nt=`/* === Cyberpunk主题性能和体验优化 === */

/* 性能优化 - GPU加速 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content,
.oow-popover[data-theme="cyberpunk"] .etymology-panel {
  transform: translateZ(0);
  backface-visibility: hidden;
  perspective: 1000px;
}

/* 移动端性能优化 */
@media (max-width: 768px) {
  .oow-popover[data-theme="cyberpunk"] .info-panel-content *,
  .oow-popover[data-theme="cyberpunk"] .etymology-panel * {
    animation-duration: 0.2s !important;
    animation-delay: 0s !important;
  }

  .oow-popover[data-theme="cyberpunk"] .info-panel-content strong,
  .oow-popover[data-theme="cyberpunk"] .etymology-panel strong,
  .oow-popover[data-theme="cyberpunk"] .info-panel-content em,
  .oow-popover[data-theme="cyberpunk"] .etymology-panel em {
    animation: none !important;
    text-shadow: 0 0 5px currentColor;
  }
}

/* 用户偏好减少动画 */
@media (prefers-reduced-motion: reduce) {
  .oow-popover[data-theme="cyberpunk"] .info-panel-content *,
  .oow-popover[data-theme="cyberpunk"] .etymology-panel * {
    animation: none !important;
    opacity: 1 !important;
    transform: none !important;
  }

  .oow-popover[data-theme="cyberpunk"] .info-panel-content *:hover,
  .oow-popover[data-theme="cyberpunk"] .etymology-panel *:hover {
    animation: none !important;
    transform: none !important;
  }
}

/* 错误状态故障艺术 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content .error-message,
.oow-popover[data-theme="cyberpunk"] .etymology-panel .error-message {
  color: #ff3860;
  font-weight: 700;
  text-transform: uppercase;
  animation: cyberpunk-glitch 0.2s ease-in-out infinite, cyberpunk-neon-flicker 1.5s ease-in-out infinite;
  text-shadow: 0 0 10px currentColor;
}

@keyframes cyberpunk-scan {
  0%, 100% {
    opacity: 1;
    filter: brightness(1);
  }
  50% {
    opacity: 0.7;
    filter: brightness(1.2);
  }
}

`,Pt=`/* === Cyberpunk主题专属文字动效关键帧 === */

/* 故障艺术效果 - 模拟数字信号失真 */
@keyframes cyberpunk-glitch {
  0%, 100% {
    transform: translate(0, 0);
    filter: hue-rotate(0deg);
    opacity: 1;
  }
  20% {
    transform: translate(-2px, 2px);
    filter: hue-rotate(90deg) saturate(2);
    opacity: 0.8;
  }
  40% {
    transform: translate(-2px, -2px);
    filter: hue-rotate(180deg) saturate(1.5);
    opacity: 0.9;
  }
  60% {
    transform: translate(2px, 2px);
    filter: hue-rotate(270deg) saturate(2.5);
    opacity: 0.85;
  }
  80% {
    transform: translate(2px, -2px);
    filter: hue-rotate(360deg) saturate(1.8);
    opacity: 0.95;
  }
}

/* 扫描线效果 - 模拟HUD扫描 */
@keyframes cyberpunk-hud-scan {
  0% {
    clip-path: polygon(0 0, 100% 0, 100% 0, 0 0);
    opacity: 0;
  }
  50% {
    clip-path: polygon(0 0, 100% 0, 100% 50%, 0 50%);
    opacity: 1;
  }
  100% {
    clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);
    opacity: 1;
  }
}

/* 霓虹灯管闪烁 - 模拟城市霓虹 */
@keyframes cyberpunk-neon-flicker {
  0%, 100% {
    opacity: 1;
    text-shadow: 0 0 10px currentColor, 0 0 20px currentColor;
  }
  10% {
    opacity: 0.8;
    text-shadow: 0 0 5px currentColor;
  }
  15% {
    opacity: 1;
    text-shadow: 0 0 15px currentColor, 0 0 30px currentColor;
  }
  20% {
    opacity: 0.9;
    text-shadow: 0 0 8px currentColor;
  }
  80% {
    opacity: 0.95;
    text-shadow: 0 0 12px currentColor;
  }
}

/* 数据流动画 - 模拟数字传输 */
@keyframes cyberpunk-data-flow {
  0% {
    background-position: 0% 50%;
    transform: translateX(-100%);
  }
  100% {
    background-position: 100% 50%;
    transform: translateX(100%);
  }
}

/* 全息投影效果 - 模拟未来投影 */
@keyframes cyberpunk-hologram {
  0%, 100% {
    opacity: 0.9;
    transform: translateZ(0) scale(1);
    filter: brightness(1);
  }
  25% {
    opacity: 0.85;
    transform: translateZ(0) scale(1.02);
    filter: brightness(1.1);
  }
  50% {
    opacity: 0.95;
    transform: translateZ(0) scale(0.98);
    filter: brightness(0.9);
  }
  75% {
    opacity: 0.88;
    transform: translateZ(0) scale(1.01);
    filter: brightness(1.05);
  }
}

/* 数字噪点效果 - 模拟信号干扰 */
@keyframes cyberpunk-digital-noise {
  0%, 100% {
    filter: contrast(1) brightness(1);
    transform: translate(0, 0);
  }
  25% {
    filter: contrast(1.2) brightness(0.8);
    transform: translate(1px, -1px);
  }
  50% {
    filter: contrast(0.9) brightness(1.1);
    transform: translate(-1px, 1px);
  }
  75% {
    filter: contrast(1.1) brightness(0.9);
    transform: translate(1px, 1px);
  }
}

/* 终端光标闪烁 */
@keyframes cyberpunk-cursor {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
}

/* 电子流动画 - 模拟电流通过 */
@keyframes cyberpunk-electric-flow {
  0% {
    background-position: 0% 0%;
    box-shadow: inset 0 0 20px rgba(67, 97, 238, 0.2);
  }
  50% {
    background-position: 100% 0%;
    box-shadow: inset 0 0 30px rgba(247, 37, 133, 0.4);
  }
  100% {
    background-position: 200% 0%;
    box-shadow: inset 0 0 20px rgba(67, 97, 238, 0.2);
  }
}

/* 二进制码雨效果 */
@keyframes cyberpunk-matrix-rain {
  0% {
    background-position: 0% 0%;
    opacity: 0;
  }
  10% {
    opacity: 0.3;
  }
  90% {
    opacity: 0.3;
  }
  100% {
    background-position: 0% 100%;
    opacity: 0;
  }
}
`,Ft=`/* Cyberpunk主题的translation和contextual-analysis样式 */
.oow-popover[data-theme="cyberpunk"] .translation[data-style="framed"] {
  background: rgba(114, 9, 183, 0.15);
  border: 1px solid rgba(247, 37, 133, 0.3);
  border-radius: 6px;
  padding: 10px 12px;
  box-shadow: 0 2px 8px rgba(247, 37, 133, 0.2);
}

.oow-popover[data-theme="cyberpunk"] .contextual-analysis[data-style="framed"] {
  background: rgba(114, 9, 183, 0.15);
  border: 1px solid rgba(114, 9, 183, 0.3);
  border-radius: 6px;
  padding: 10px 12px;
  box-shadow: 0 2px 8px rgba(114, 9, 183, 0.2);
}

.oow-popover[data-theme="cyberpunk"] .translation .text {
  color: #f72585;
  font-weight: 700;
  text-shadow: 0 0 4px rgba(247, 37, 133, 0.3);
}

.oow-popover[data-theme="cyberpunk"] .contextual-analysis .text {
  color: #d946ef;
  font-weight: 400;
  text-shadow: 0 0 4px rgba(217, 70, 239, 0.3);
}

/* Cyberpunk主题的Info Panel和Etymology Panel样式 */
.oow-popover[data-theme="cyberpunk"] .info-panel-content,
.oow-popover[data-theme="cyberpunk"] .etymology-panel {
  /* 科技霓虹感：采用赛博朋克风格的发光文字和未来感字体，增强科技氛围 */
  --oow-info-panel-heading-color: #f72585;
  --oow-info-panel-heading-weight: 700;
  --oow-info-panel-heading-margin-top: 1.3em;
  --oow-info-panel-heading-margin-bottom: 0.7em;
  --oow-info-panel-paragraph-color: #f72585;
  --oow-info-panel-paragraph-margin-bottom: 0.9em;
  --oow-info-panel-line-height: 1.5;
  --oow-info-panel-letter-spacing: 0.02em;
  --oow-info-panel-font-family: 'Orbitron', 'Courier New', 'Segoe UI', monospace, sans-serif;
  --oow-info-panel-list-color: #f72585;
  --oow-info-panel-blockquote-color: #b5179e;
  --oow-info-panel-blockquote-border: #7209b7;
  --oow-info-panel-code-color: #4cc9f0;
  --oow-info-panel-code-bg: rgba(0, 0, 0, 0.15);
  --oow-info-panel-link-color: #ff006e;
  --oow-info-panel-link-hover: #4361ee;
}

`,It=`/*
 * Origin of Words - Cyberpunk Theme (Premium)
 * 赛博朋克主题 - 付费未来科技主题
 * 100% original style with ORIGINAL variable names
 */

/* Theme Variables - CRITICAL: Use original variable names */
.oow-popover[data-theme="cyberpunk"] {
  --panel-bg: #0a011a;
  --text-color: #f72585;
  --muted: #b5179e;
  --ring: #7209b7; /* purple */
  --accent-1: #ff006e; /* hot pink */
  --accent-2: #4361ee; /* electric blue */
  --accent-3: #4cc9f0; /* cyan */
  --accent-4: #9d4edd; /* deep purple */
  backdrop-filter: blur(20px);
  background: linear-gradient(135deg, #0a011a, #1a0b2e, #2a0a40) !important;
  border: 2px solid var(--ring);
  box-shadow: 0 0 50px rgba(247, 37, 133, 0.5), inset 0 0 40px rgba(114, 9, 183, 0.25);

  /* Enhanced Unified Button Styles */
  --oow-button-bg: rgba(114, 9, 183, 0.25);
  --oow-button-hover-bg: linear-gradient(135deg, var(--accent-1), var(--accent-2));
  --oow-button-color: var(--text-color);
  --oow-button-hover-color: white;
  --oow-button-radius: 8px;
  --oow-button-transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  /* Enhanced Markdown Highlight Styles */
  --oow-highlight-heading-color: var(--text-color);
  --oow-highlight-heading-font-weight: 700;
  --oow-highlight-heading-margin-top: 1.3em;
  --oow-highlight-heading-margin-bottom: 0.7em;
  --oow-highlight-h1-font-size: 1.6em;
  --oow-highlight-h2-font-size: 1.35em;
  --oow-highlight-h3-font-size: 1.2em;
  --oow-highlight-h4-font-size: 1.1em;
  --oow-highlight-h5-font-size: 1em;
  --oow-highlight-h6-font-size: 0.9em;
  --oow-highlight-strong-color: var(--accent-1);
  --oow-highlight-strong-font-weight: 700;
  --oow-highlight-em-color: var(--accent-2);
  --oow-highlight-em-font-style: italic;
  --oow-highlight-code-color: var(--accent-3);
  --oow-highlight-code-bg: rgba(0, 0, 0, 0.15);
  --oow-highlight-code-border-color: var(--ring);
  --oow-highlight-link-color: var(--accent-1);
  --oow-highlight-link-decoration: underline;
  --oow-highlight-link-decoration-thickness: 2px;
  --oow-highlight-link-hover-color: var(--accent-3);
  --oow-highlight-blockquote-margin: 1.3em 0;
  --oow-highlight-blockquote-padding: 0.8em 1.2em;
  --oow-highlight-blockquote-border-left: 5px solid var(--ring);
  --oow-highlight-blockquote-color: var(--muted);
  --oow-highlight-blockquote-bg: rgba(0, 0, 0, 0.1);
  --oow-highlight-hr-height: 2px;
  --oow-highlight-hr-bg: linear-gradient(90deg, var(--accent-1), var(--accent-2), var(--accent-3));
  --oow-highlight-hr-margin: 1.8em 0;
  --oow-highlight-pre-padding: 1.3em;
  --oow-highlight-pre-bg: rgba(0, 0, 0, 0.2);
  --oow-highlight-pre-border-radius: 8px;
  --oow-highlight-pre-font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  --oow-highlight-pre-font-size: 0.95em;
  --oow-highlight-table-margin: 1.8em 0;
  --oow-highlight-table-border: 2px solid var(--ring);
  --oow-highlight-table-cell-padding: 0.6em 0.9em;
  --oow-highlight-table-header-bg: rgba(255, 255, 255, 0.1);
  --oow-highlight-table-header-color: var(--text-color);
  --oow-highlight-table-header-font-weight: 700;
}

`,Lt=`/* === Trigger Button - Cyberpunk Theme === */
.oow-selection-trigger-button[data-theme="cyberpunk"] {
  background: radial-gradient(ellipse at center, rgba(247, 37, 133, 0.8), rgba(247, 37, 133, 0.4), #0a011a);
  border: none;
  box-shadow: 0 0 30px rgba(247, 37, 133, 0.8), inset 0 0 20px rgba(247, 37, 133, 0.3);
  color: white;
  text-shadow: 0 0 8px rgba(247, 37, 133, 0.6);
  text-transform: uppercase;
  font-weight: 700;
  border-radius: 0;
  clip-path: polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%);
  transition: var(--oow-button-transition);
  animation: cyberpunk-scan 2s linear infinite;
}

.oow-selection-trigger-button[data-theme="cyberpunk"]:hover {
  background: radial-gradient(ellipse at center, rgba(247, 37, 133, 0.9), rgba(247, 37, 133, 0.5), #1a0b2e);
  box-shadow: 0 0 40px rgba(247, 37, 133, 0.9), inset 0 0 25px rgba(247, 37, 133, 0.4);
  transform: scale(1.08);
  transition: var(--oow-button-transition);
}

.oow-selection-trigger-button[data-theme="cyberpunk"].activated {
  background: transparent;
  border: 3px ridge #4361ee;
  padding: 4px;
  box-shadow: 0 0 45px rgba(67, 97, 238, 0.6), 0 0 25px rgba(247, 37, 133, 0.4);
  color: #f72585;
  animation: none;
  transition: var(--oow-button-transition);
}

.oow-selection-trigger-button[data-theme="cyberpunk"].activated::before {
  content: '';
  position: absolute;
  top: 4px;
  left: 4px;
  right: 4px;
  bottom: 4px;
  background: radial-gradient(ellipse at center, rgba(247, 37, 133, 0.9), rgba(247, 37, 133, 0.6), #0a011a);
  clip-path: polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%);
  z-index: -1;
  box-shadow: inset 0 0 15px rgba(247, 37, 133, 0.4);
}

`,Rt=`/* Galaxy Stars Effect */
.oow-popover[data-theme="galaxy"]::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image:
    radial-gradient(1px 1px at 10% 20%, white, transparent),
    radial-gradient(2px 2px at 30% 40%, white, transparent),
    radial-gradient(1px 1px at 50% 60%, white, transparent),
    radial-gradient(3px 3px at 70% 80%, white, transparent),
    radial-gradient(1px 1px at 90% 10%, white, transparent),
    radial-gradient(2px 2px at 25% 75%, rgba(192, 132, 252, 0.6), transparent),
    radial-gradient(1px 1px at 65% 35%, rgba(232, 121, 249, 0.5), transparent);
  opacity: 0.5;
  pointer-events: none;
  z-index: 0;
  animation: galaxy-stars 15s linear infinite, galaxy-twinkle 3s ease-in-out infinite alternate;
}

@keyframes galaxy-stars {
  from {
    transform: translateY(0);
  }
  to {
    transform: translateY(-2000px);
  }
}

@keyframes galaxy-twinkle {
  0%, 100% {
    opacity: 0.5;
  }
  25% {
    opacity: 0.7;
  }
  50% {
    opacity: 0.4;
  }
  75% {
    opacity: 0.6;
  }
}

.oow-popover[data-theme="galaxy"] > * {
  position: relative;
  z-index: 1;
}

.oow-popover[data-theme="galaxy"] .header-title {
  background: linear-gradient(135deg, var(--accent-1), var(--accent-2), var(--accent-3), var(--accent-4));
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  font-weight: 800;
  font-size: 1.2em;
  letter-spacing: 1px;
  text-shadow: 0 0 15px rgba(192, 132, 252, 0.4);
  animation: galaxy-title-glow 3s ease-in-out infinite alternate;
}

@keyframes galaxy-title-glow {
  0%, 100% {
    text-shadow: 0 0 15px rgba(192, 132, 252, 0.4);
  }
  50% {
    text-shadow: 0 0 25px rgba(192, 132, 252, 0.6), 0 0 35px rgba(232, 121, 249, 0.3);
  }
}

.oow-popover[data-theme="galaxy"] .header-logo {
  background: linear-gradient(135deg, var(--accent-1), var(--accent-2));
  border: 2px solid var(--ring);
  color: white;
  font-weight: 900;
  font-size: 1.1em;
  border-radius: 6px;
  box-shadow: 0 0 20px rgba(192, 132, 252, 0.5);
  animation: galaxy-logo-pulse 2s infinite;
}

@keyframes galaxy-logo-pulse {
  0%, 100% {
    box-shadow: 0 0 20px rgba(192, 132, 252, 0.5);
  }
  50% {
    box-shadow: 0 0 30px rgba(192, 132, 252, 0.7), 0 0 40px rgba(232, 121, 249, 0.4);
  }
}

.oow-popover[data-theme="galaxy"] .section-title {
  color: var(--accent-1);
  font-weight: 700;
  font-size: 1.1em;
  text-shadow: 0 0 10px rgba(192, 132, 252, 0.3);
  background: linear-gradient(90deg, transparent 70%, rgba(192, 132, 252, 0.1) 70%);
  background-size: 200% 100%;
  animation: galaxy-scan 4s linear infinite;
}

@keyframes galaxy-scan {
  0% {
    background-position: 100% 0;
  }
  100% {
    background-position: -100% 0;
  }
}

.oow-popover[data-theme="galaxy"] .def-item .pos {
  color: var(--accent-2);
  font-weight: 700;
  text-shadow: 0 0 8px rgba(232, 121, 249, 0.3);
  font-size: 0.9em;
}

.oow-popover[data-theme="galaxy"] .def-item .meaning {
  color: var(--text-color);
  line-height: 1.5;
}

.oow-popover[data-theme="galaxy"] .def-item .example {
  color: var(--muted);
  border-left: 3px solid var(--accent-1);
  padding-left: 12px;
  background: rgba(192, 132, 252, 0.06);
  border-radius: 0 4px 4px 0;
  margin-left: 2px;
}

.oow-popover[data-theme="galaxy"] .eq .bar {
  background: linear-gradient(180deg, var(--accent-1), var(--accent-2));
  box-shadow: 0 2px 15px var(--accent-1), inset 0 1px 0 rgba(255, 255, 255, 0.2);
  border-radius: 8px;
  height: 10px;
  animation: galaxy-bar-pulse 2.5s infinite;
}

@keyframes galaxy-bar-pulse {
  0%, 100% {
    box-shadow: 0 2px 15px var(--accent-1), inset 0 1px 0 rgba(255, 255, 255, 0.2);
  }
  50% {
    box-shadow: 0 2px 25px var(--accent-1), 0 2px 35px var(--accent-2), inset 0 1px 0 rgba(255, 255, 255, 0.3);
    height: 12px;
  }
}

`,zt=`/* === Galaxy主题文字动效 - 段落和标题进入动画 === */

/* 标题星光闪烁动画 */
.oow-popover[data-theme="galaxy"] .info-panel-content h1,
.oow-popover[data-theme="galaxy"] .info-panel-content h2,
.oow-popover[data-theme="galaxy"] .info-panel-content h3,
.oow-popover[data-theme="galaxy"] .info-panel-content h4,
.oow-popover[data-theme="galaxy"] .info-panel-content h5,
.oow-popover[data-theme="galaxy"] .info-panel-content h6,
.oow-popover[data-theme="galaxy"] .etymology-panel h1,
.oow-popover[data-theme="galaxy"] .etymology-panel h2,
.oow-popover[data-theme="galaxy"] .etymology-panel h3,
.oow-popover[data-theme="galaxy"] .etymology-panel h4,
.oow-popover[data-theme="galaxy"] .etymology-panel h5,
.oow-popover[data-theme="galaxy"] .etymology-panel h6 {
  animation: galaxy-fadeInUp 0.8s ease-out forwards, galaxy-twinkle 4s ease-in-out infinite 2s;
  opacity: 0;
  animation-fill-mode: forwards;
}

/* 不同标题级别的延迟时间 */
.oow-popover[data-theme="galaxy"] .info-panel-content h1,
.oow-popover[data-theme="galaxy"] .etymology-panel h1 {
  animation-delay: 0s, 2s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content h2,
.oow-popover[data-theme="galaxy"] .etymology-panel h2 {
  animation-delay: 0.1s, 2.2s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content h3,
.oow-popover[data-theme="galaxy"] .etymology-panel h3 {
  animation-delay: 0.2s, 2.4s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content h4,
.oow-popover[data-theme="galaxy"] .info-panel-content h5,
.oow-popover[data-theme="galaxy"] .info-panel-content h6,
.oow-popover[data-theme="galaxy"] .etymology-panel h4,
.oow-popover[data-theme="galaxy"] .etymology-panel h5,
.oow-popover[data-theme="galaxy"] .etymology-panel h6 {
  animation-delay: 0.3s, 2.6s;
}

/* 段落渐入动画 */
.oow-popover[data-theme="galaxy"] .info-panel-content p,
.oow-popover[data-theme="galaxy"] .etymology-panel p {
  animation: galaxy-fadeInUp 0.6s ease-out forwards;
  opacity: 0;
  animation-fill-mode: forwards;
}

/* 段落延迟递增 */
.oow-popover[data-theme="galaxy"] .info-panel-content p:nth-child(1),
.oow-popover[data-theme="galaxy"] .etymology-panel p:nth-child(1) {
  animation-delay: 0.4s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content p:nth-child(2),
.oow-popover[data-theme="galaxy"] .etymology-panel p:nth-child(2) {
  animation-delay: 0.6s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content p:nth-child(3),
.oow-popover[data-theme="galaxy"] .etymology-panel p:nth-child(3) {
  animation-delay: 0.8s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content p:nth-child(n+4),
.oow-popover[data-theme="galaxy"] .etymology-panel p:nth-child(n+4) {
  animation-delay: 1s;
}

/* === Galaxy主题文字动效 - 列表和代码动画 === */

/* 列表项逐项显示动画 */
.oow-popover[data-theme="galaxy"] .info-panel-content ul li,
.oow-popover[data-theme="galaxy"] .info-panel-content ol li,
.oow-popover[data-theme="galaxy"] .etymology-panel ul li,
.oow-popover[data-theme="galaxy"] .etymology-panel ol li {
  animation: galaxy-fadeInUp 0.5s ease-out forwards;
  opacity: 0;
  animation-fill-mode: forwards;
  will-change: opacity, transform;
}

/* 列表项延迟递增 - 模拟星辰依次点亮 */
.oow-popover[data-theme="galaxy"] .info-panel-content ul li:nth-child(1),
.oow-popover[data-theme="galaxy"] .info-panel-content ol li:nth-child(1),
.oow-popover[data-theme="galaxy"] .etymology-panel ul li:nth-child(1),
.oow-popover[data-theme="galaxy"] .etymology-panel ol li:nth-child(1) {
  animation-delay: 0.3s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content ul li:nth-child(2),
.oow-popover[data-theme="galaxy"] .info-panel-content ol li:nth-child(2),
.oow-popover[data-theme="galaxy"] .etymology-panel ul li:nth-child(2),
.oow-popover[data-theme="galaxy"] .etymology-panel ol li:nth-child(2) {
  animation-delay: 0.5s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content ul li:nth-child(3),
.oow-popover[data-theme="galaxy"] .info-panel-content ol li:nth-child(3),
.oow-popover[data-theme="galaxy"] .etymology-panel ul li:nth-child(3),
.oow-popover[data-theme="galaxy"] .etymology-panel ol li:nth-child(3) {
  animation-delay: 0.7s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content ul li:nth-child(4),
.oow-popover[data-theme="galaxy"] .info-panel-content ol li:nth-child(4),
.oow-popover[data-theme="galaxy"] .etymology-panel ul li:nth-child(4),
.oow-popover[data-theme="galaxy"] .etymology-panel ol li:nth-child(4) {
  animation-delay: 0.9s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content ul li:nth-child(n+5),
.oow-popover[data-theme="galaxy"] .info-panel-content ol li:nth-child(n+5),
.oow-popover[data-theme="galaxy"] .etymology-panel ul li:nth-child(n+5),
.oow-popover[data-theme="galaxy"] .etymology-panel ol li:nth-child(n+5) {
  animation-delay: 1.1s;
}

/* 行内代码打字机效果 */
.oow-popover[data-theme="galaxy"] .info-panel-content code,
.oow-popover[data-theme="galaxy"] .etymology-panel code {
  position: relative;
  overflow: hidden;
  animation: galaxy-fadeInUp 0.4s ease-out forwards;
  opacity: 0;
  animation-fill-mode: forwards;
  will-change: opacity, transform;
}

/* 行内代码延迟 */
.oow-popover[data-theme="galaxy"] .info-panel-content p code,
.oow-popover[data-theme="galaxy"] .etymology-panel p code {
  animation-delay: 0.2s;
}

/* 预格式化代码块动画 */
.oow-popover[data-theme="galaxy"] .info-panel-content pre,
.oow-popover[data-theme="galaxy"] .etymology-panel pre {
  animation: galaxy-fadeInUp 0.6s ease-out forwards;
  opacity: 0;
  animation-fill-mode: forwards;
  border-left: 3px solid var(--ring);
  background: linear-gradient(90deg, rgba(0, 0, 0, 0.15), rgba(192, 132, 252, 0.05));
  will-change: opacity, transform;
  position: relative;
}

/* 代码块内部文字渐入 */
.oow-popover[data-theme="galaxy"] .info-panel-content pre *,
.oow-popover[data-theme="galaxy"] .etymology-panel pre * {
  animation: galaxy-fadeInUp 0.4s ease-out 0.3s forwards;
  opacity: 0;
  animation-fill-mode: forwards;
}

/* === Galaxy主题文字动效 - 悬停和强调微交互 === */

/* 强调文本脉冲发光 */
.oow-popover[data-theme="galaxy"] .info-panel-content strong,
.oow-popover[data-theme="galaxy"] .etymology-panel strong {
  animation: galaxy-glow 3s ease-in-out infinite;
  color: var(--accent-1);
  font-weight: 700;
  transition: all 0.3s ease;
  will-change: text-shadow;
}

.oow-popover[data-theme="galaxy"] .info-panel-content strong:hover,
.oow-popover[data-theme="galaxy"] .etymology-panel strong:hover {
  animation-duration: 1.5s;
  text-shadow: 0 0 20px rgba(192, 132, 252, 0.8);
  transform: scale(1.05);
}

/* 斜体文本星光效果 */
.oow-popover[data-theme="galaxy"] .info-panel-content em,
.oow-popover[data-theme="galaxy"] .etymology-panel em {
  color: var(--accent-2);
  font-style: italic;
  text-shadow: 0 0 8px rgba(232, 121, 249, 0.3);
  transition: all 0.3s ease;
  will-change: text-shadow;
}

.oow-popover[data-theme="galaxy"] .info-panel-content em:hover,
.oow-popover[data-theme="galaxy"] .etymology-panel em:hover {
  text-shadow: 0 0 15px rgba(232, 121, 249, 0.6);
  animation: galaxy-twinkle 2s ease-in-out infinite;
}

/* 链接星轨悬停效果 */
.oow-popover[data-theme="galaxy"] .info-panel-content a,
.oow-popover[data-theme="galaxy"] .etymology-panel a {
  color: var(--accent-1);
  text-decoration: none;
  position: relative;
  transition: all 0.3s ease;
  background-image: linear-gradient(90deg, transparent, rgba(192, 132, 252, 0.3), transparent);
  background-size: 0% 100%;
  background-repeat: no-repeat;
  background-position: 50% 100%;
  will-change: background-size, color;
}

.oow-popover[data-theme="galaxy"] .info-panel-content a:hover,
.oow-popover[data-theme="galaxy"] .etymology-panel a:hover {
  color: var(--accent-4);
  background-size: 100% 100%;
  text-shadow: 0 0 12px rgba(167, 139, 250, 0.5);
  animation: galaxy-glow 2s ease-in-out infinite;
}

/* 引用块边框星光流动 */
.oow-popover[data-theme="galaxy"] .info-panel-content blockquote,
.oow-popover[data-theme="galaxy"] .etymology-panel blockquote {
  border-left: 3px solid rgba(129, 140, 248, 0.5);
  padding-left: 12px;
  margin: 1em 0;
  position: relative;
  transition: all 0.3s ease;
  animation: galaxy-border-flow 4s ease-in-out infinite;
  will-change: border-color, box-shadow;
}

.oow-popover[data-theme="galaxy"] .info-panel-content blockquote:hover,
.oow-popover[data-theme="galaxy"] .etymology-panel blockquote:hover {
  border-left-width: 4px;
  padding-left: 16px;
  background: rgba(192, 132, 252, 0.05);
  animation-duration: 2s;
}

/* 段落悬停星光效果 */
.oow-popover[data-theme="galaxy"] .info-panel-content p:hover,
.oow-popover[data-theme="galaxy"] .etymology-panel p:hover {
  text-shadow: 0 0 8px rgba(192, 132, 252, 0.2);
  transition: text-shadow 0.3s ease;
  will-change: text-shadow;
}

/* 列表项悬停效果 */
.oow-popover[data-theme="galaxy"] .info-panel-content ul li:hover,
.oow-popover[data-theme="galaxy"] .info-panel-content ol li:hover,
.oow-popover[data-theme="galaxy"] .etymology-panel ul li:hover,
.oow-popover[data-theme="galaxy"] .etymology-panel ol li:hover {
  color: var(--accent-1);
  text-shadow: 0 0 6px rgba(192, 132, 252, 0.4);
  transform: translateX(4px);
  transition: all 0.3s ease;
  will-change: color, text-shadow, transform;
}

/* === Galaxy主题文字动效 - 特殊元素动画 === */

/* 分割线星河流动效果 */
.oow-popover[data-theme="galaxy"] .info-panel-content hr,
.oow-popover[data-theme="galaxy"] .etymology-panel hr {
  border: none;
  height: 2px;
  background: linear-gradient(90deg,
    transparent 0%,
    rgba(192, 132, 252, 0.3) 25%,
    rgba(232, 121, 249, 0.5) 50%,
    rgba(244, 114, 182, 0.3) 75%,
    transparent 100%);
  background-size: 200% 100%;
  margin: 2em 0;
  animation: galaxy-starflow 6s linear infinite;
  will-change: background-position;
}

/* 表格数据录入效果 */
.oow-popover[data-theme="galaxy"] .info-panel-content table,
.oow-popover[data-theme="galaxy"] .etymology-panel table {
  border-collapse: separate;
  border-spacing: 0;
  border: 2px solid var(--ring);
  border-radius: 8px;
  overflow: hidden;
  animation: galaxy-fadeInUp 0.8s ease-out forwards;
  opacity: 0;
  animation-fill-mode: forwards;
  will-change: opacity, transform;
}

/* 表格头部动画 */
.oow-popover[data-theme="galaxy"] .info-panel-content table th,
.oow-popover[data-theme="galaxy"] .etymology-panel table th {
  background: linear-gradient(135deg, var(--accent-1), var(--accent-2));
  color: white;
  font-weight: 700;
  padding: 12px 16px;
  text-shadow: 0 0 8px rgba(255, 255, 255, 0.3);
  animation: galaxy-glow 4s ease-in-out infinite;
}

/* 表格单元格动画 */
.oow-popover[data-theme="galaxy"] .info-panel-content table td,
.oow-popover[data-theme="galaxy"] .etymology-panel table td {
  padding: 10px 16px;
  border-bottom: 1px solid rgba(129, 140, 248, 0.2);
  animation: galaxy-fadeInUp 0.5s ease-out forwards;
  opacity: 0;
  animation-fill-mode: forwards;
  transition: all 0.3s ease;
  will-change: opacity, background-color;
}

/* 表格单元格延迟显示 */
.oow-popover[data-theme="galaxy"] .info-panel-content table tr:nth-child(1) td,
.oow-popover[data-theme="galaxy"] .etymology-panel table tr:nth-child(1) td {
  animation-delay: 0.2s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content table tr:nth-child(2) td,
.oow-popover[data-theme="galaxy"] .etymology-panel table tr:nth-child(2) td {
  animation-delay: 0.4s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content table tr:nth-child(3) td,
.oow-popover[data-theme="galaxy"] .etymology-panel table tr:nth-child(3) td {
  animation-delay: 0.6s;
}

.oow-popover[data-theme="galaxy"] .info-panel-content table tr:nth-child(n+4) td,
.oow-popover[data-theme="galaxy"] .etymology-panel table tr:nth-child(n+4) td {
  animation-delay: 0.8s;
}

/* 表格行悬停效果 */
.oow-popover[data-theme="galaxy"] .info-panel-content table tr:hover td,
.oow-popover[data-theme="galaxy"] .etymology-panel table tr:hover td {
  background: rgba(192, 132, 252, 0.1);
  text-shadow: 0 0 4px rgba(192, 132, 252, 0.3);
}

/* 图片淡入效果 */
.oow-popover[data-theme="galaxy"] .info-panel-content img,
.oow-popover[data-theme="galaxy"] .etymology-panel img {
  max-width: 100%;
  height: auto;
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(192, 132, 252, 0.3);
  animation: galaxy-fadeInUp 0.8s ease-out forwards;
  opacity: 0;
  animation-fill-mode: forwards;
  transition: all 0.3s ease;
  will-change: opacity, transform, box-shadow;
}

/* 图片悬停星光效果 */
.oow-popover[data-theme="galaxy"] .info-panel-content img:hover,
.oow-popover[data-theme="galaxy"] .etymology-panel img:hover {
  transform: scale(1.02);
  box-shadow: 0 8px 30px rgba(192, 132, 252, 0.5);
  animation: galaxy-glow 2s ease-in-out infinite;
}

/* 高亮文本动画 */
.oow-popover[data-theme="galaxy"] .info-panel-content .highlight,
.oow-popover[data-theme="galaxy"] .etymology-panel .highlight {
  background: linear-gradient(90deg,
    rgba(192, 132, 252, 0.2),
    rgba(232, 121, 249, 0.3),
    rgba(192, 132, 252, 0.2));
  background-size: 200% 100%;
  background-position: 0% 50%;
  padding: 2px 6px;
  border-radius: 4px;
  animation: galaxy-starflow 3s ease-in-out infinite;
  color: var(--accent-1);
  font-weight: 600;
  will-change: background-position;
}

/* === Galaxy主题动画性能优化和主题一致性 === */

/* 动画性能优化 - 为父容器添加GPU加速 */
.oow-popover[data-theme="galaxy"] .info-panel-content,
.oow-popover[data-theme="galaxy"] .etymology-panel {
  transform: translateZ(0);
  backface-visibility: hidden;
  perspective: 1000px;
}

/* 减少动画复杂度 - 优化移动设备性能 */
@media (max-width: 768px) {
  .oow-popover[data-theme="galaxy"] .info-panel-content *,
  .oow-popover[data-theme="galaxy"] .etymology-panel * {
    animation-duration: 0.3s !important;
    animation-delay: 0s !important;
  }

  .oow-popover[data-theme="galaxy"] .info-panel-content strong,
  .oow-popover[data-theme="galaxy"] .etymology-panel strong,
  .oow-popover[data-theme="galaxy"] .info-panel-content em,
  .oow-popover[data-theme="galaxy"] .etymology-panel em {
    animation: none !important;
  }
}

/* 用户偏好减少动画时的适配 */
@media (prefers-reduced-motion: reduce) {
  .oow-popover[data-theme="galaxy"] .info-panel-content *,
  .oow-popover[data-theme="galaxy"] .etymology-panel * {
    animation: none !important;
    opacity: 1 !important;
    transform: none !important;
  }

  .oow-popover[data-theme="galaxy"] .info-panel-content *:hover,
  .oow-popover[data-theme="galaxy"] .etymology-panel *:hover {
    transform: none !important;
    text-shadow: none !important;
  }
}

/* 主题一致性优化 - 统一动画节奏 */
.oow-popover[data-theme="galaxy"] .info-panel-content *,
.oow-popover[data-theme="galaxy"] .etymology-panel * {
  animation-timing-function: cubic-bezier(0.25, 0.1, 0.25, 1);
}

/* 确保所有动画元素都有合适的延迟层次 */
.oow-popover[data-theme="galaxy"] .info-panel-content {
  animation-delay: 0s;
}

/* 防止内容重叠 - 确保动画完成后元素正确显示 */
.oow-popover[data-theme="galaxy"] .info-panel-content *:not(:hover),
.oow-popover[data-theme="galaxy"] .etymology-panel *:not(:hover) {
  z-index: auto;
}

/* 优化动画结束状态 - 确保可读性 */
.oow-popover[data-theme="galaxy"] .info-panel-content *,
.oow-popover[data-theme="galaxy"] .etymology-panel * {
  animation-fill-mode: both;
}

/* 主题色彩一致性 - 确保所有动画使用Galaxy配色 */
.oow-popover[data-theme="galaxy"] .info-panel-content *,
.oow-popover[data-theme="galaxy"] .etymology-panel * {
  --galaxy-primary: rgba(192, 132, 252, 1);
  --galaxy-secondary: rgba(232, 121, 249, 1);
  --galaxy-tertiary: rgba(244, 114, 182, 1);
  --galaxy-quaternary: rgba(167, 139, 250, 1);
}

/* 错误状态动画 - 保持主题一致性 */
.oow-popover[data-theme="galaxy"] .info-panel-content .error-message,
.oow-popover[data-theme="galaxy"] .etymology-panel .error-message {
  color: #ff6b6b;
  animation: galaxy-glow 2s ease-in-out infinite;
  text-shadow: 0 0 8px rgba(255, 107, 107, 0.3);
}

/* 加载状态动画 - Galaxy风格的加载提示 */
.oow-popover[data-theme="galaxy"] .info-panel-content.loading::after,
.oow-popover[data-theme="galaxy"] .etymology-panel.loading::after {
  content: '';
  display: inline-block;
  width: 12px;
  height: 12px;
  border: 2px solid var(--galaxy-primary);
  border-radius: 50%;
  border-top-color: transparent;
  animation: galaxy-spin 1s linear infinite;
  margin-left: 8px;
}

@keyframes galaxy-spin {
  to {
    transform: rotate(360deg);
  }
}

@keyframes galaxy-activated-pulse {
  0%, 100% {
    box-shadow: 0 0 45px rgba(192, 132, 252, 0.9);
  }
  50% {
    box-shadow: 0 0 55px rgba(192, 132, 252, 1.0), 0 0 65px rgba(232, 121, 249, 0.6);
  }
}

`,Bt=`/* === Galaxy主题专属文字动效关键帧 === */

/* 淡入上升动画 - 模拟星辰升起 */
@keyframes galaxy-fadeInUp {
  0% {
    opacity: 0;
    transform: translateY(20px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 星光闪烁动画 - 模拟星光闪烁 */
@keyframes galaxy-twinkle {
  0%, 100% {
    opacity: 1;
    text-shadow: 0 0 10px rgba(192, 132, 252, 0.3);
  }
  25% {
    opacity: 0.8;
    text-shadow: 0 0 15px rgba(192, 132, 252, 0.5);
  }
  50% {
    opacity: 0.9;
    text-shadow: 0 0 20px rgba(232, 121, 249, 0.4);
  }
  75% {
    opacity: 0.85;
    text-shadow: 0 0 12px rgba(244, 114, 182, 0.3);
  }
}

/* 脉冲发光动画 - 模拟星云脉动 */
@keyframes galaxy-glow {
  0%, 100% {
    text-shadow: 0 0 8px rgba(192, 132, 252, 0.4);
  }
  50% {
    text-shadow: 0 0 15px rgba(192, 132, 252, 0.6), 0 0 25px rgba(232, 121, 249, 0.3);
  }
}

/* 星轨流动动画 - 模拟星河流动 */
@keyframes galaxy-starflow {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}

/* 打字机效果 - 模拟数据录入 */
@keyframes galaxy-typewriter {
  0% {
    width: 0;
    opacity: 0;
  }
  10% {
    opacity: 1;
  }
  100% {
    width: 100%;
    opacity: 1;
  }
}

/* 边框星光流动 - 模拟星尘流动 */
@keyframes galaxy-border-flow {
  0% {
    border-color: rgba(192, 132, 252, 0.3);
    box-shadow: -2px 0 8px rgba(192, 132, 252, 0.2);
  }
  25% {
    border-color: rgba(232, 121, 249, 0.4);
    box-shadow: -2px 0 10px rgba(232, 121, 249, 0.3);
  }
  50% {
    border-color: rgba(244, 114, 182, 0.3);
    box-shadow: -2px 0 8px rgba(244, 114, 182, 0.2);
  }
  75% {
    border-color: rgba(167, 139, 250, 0.4);
    box-shadow: -2px 0 10px rgba(167, 139, 250, 0.3);
  }
  100% {
    border-color: rgba(192, 132, 252, 0.3);
    box-shadow: -2px 0 8px rgba(192, 132, 252, 0.2);
  }
}
`,Vt=`/* Galaxy主题的translation和contextual-analysis样式 */
.oow-popover[data-theme="galaxy"] .translation[data-style="gradient"] {
  background: transparent;
  border: none;
  border-radius: 0;
  padding: 0;
  box-shadow: none;
  background-image: linear-gradient(135deg, var(--accent-1), var(--accent-2), var(--accent-3), var(--accent-4));
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}

.oow-popover[data-theme="galaxy"] .contextual-analysis[data-style="gradient"] {
  background: transparent;
  border: none;
  border-radius: 0;
  padding: 0;
  box-shadow: none;
  background-image: linear-gradient(135deg, var(--accent-2), var(--accent-4));
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}

.oow-popover[data-theme="galaxy"] .translation .text {
  font-weight: 700;
  text-shadow: 0 0 15px rgba(192, 132, 252, 0.4);
}

.oow-popover[data-theme="galaxy"] .contextual-analysis .text {
  font-weight: 400;
}

/* Galaxy主题的Info Panel和Etymology Panel样式 */
.oow-popover[data-theme="galaxy"] .info-panel-content,
.oow-popover[data-theme="galaxy"] .etymology-panel {
  /* 宇宙深邃感：使用星空渐变和银河般的文字效果，营造浩瀚宇宙的阅读氛围 */
  --oow-info-panel-heading-color: #e0e7ff;
  --oow-info-panel-heading-weight: 700;
  --oow-info-panel-heading-margin-top: 1.3em;
  --oow-info-panel-heading-margin-bottom: 0.7em;
  --oow-info-panel-paragraph-color: #e0e7ff;
  --oow-info-panel-paragraph-margin-bottom: 0.9em;
  --oow-info-panel-line-height: 1.5;
  --oow-info-panel-letter-spacing: 0.01em;
  --oow-info-panel-font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  --oow-info-panel-list-color: #e0e7ff;
  --oow-info-panel-blockquote-color: #a5b4fc;
  --oow-info-panel-blockquote-border: #818cf8;
  --oow-info-panel-code-color: #f472b6;
  --oow-info-panel-code-bg: rgba(255,255,255,0.08);
  --oow-info-panel-link-color: #c084fc;
  --oow-info-panel-link-hover: #e879f9;
}

`,Ht=`/*
 * Origin of Words - Galaxy Theme (Premium)
 * 银河主题 - 付费深空银河主题
 * 100% original style with ORIGINAL variable names
 */

/* Theme Variables - CRITICAL: Use original variable names */
.oow-popover[data-theme="galaxy"] {
  --panel-bg: #080a20;
  --text-color: #e0e7ff;
  --muted: #a5b4fc;
  --ring: #818cf8; /* indigo-400 */
  --accent-1: #c084fc; /* purple-400 */
  --accent-2: #e879f9; /* fuchsia-400 */
  --accent-3: #f472b6; /* pink-400 */
  --accent-4: #a78bfa; /* violet-400 */
  backdrop-filter: blur(25px);
  background: radial-gradient(ellipse at top, #1a1640, #080a20, #0f1230) !important;
  border: 1px solid rgba(129, 140, 248, 0.4);
  box-shadow: 0 0 70px rgba(192, 132, 252, 0.4), inset 0 0 60px rgba(129, 140, 248, 0.15);

  /* Enhanced Unified Button Styles */
  --oow-button-bg: rgba(129, 140, 248, 0.2);
  --oow-button-hover-bg: rgba(192, 132, 252, 0.3);
  --oow-button-color: var(--text-color);
  --oow-button-hover-color: var(--text-color);
  --oow-button-radius: 8px;
  --oow-button-transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  /* Enhanced Markdown Highlight Styles */
  --oow-highlight-heading-color: var(--text-color);
  --oow-highlight-heading-font-weight: 700;
  --oow-highlight-heading-margin-top: 1.3em;
  --oow-highlight-heading-margin-bottom: 0.7em;
  --oow-highlight-h1-font-size: 1.6em;
  --oow-highlight-h2-font-size: 1.35em;
  --oow-highlight-h3-font-size: 1.2em;
  --oow-highlight-h4-font-size: 1.1em;
  --oow-highlight-h5-font-size: 1em;
  --oow-highlight-h6-font-size: 0.9em;
  --oow-highlight-strong-color: var(--accent-1);
  --oow-highlight-strong-font-weight: 700;
  --oow-highlight-em-color: var(--accent-2);
  --oow-highlight-em-font-style: italic;
  --oow-highlight-code-color: var(--accent-3);
  --oow-highlight-code-bg: rgba(255,255,255,0.08);
  --oow-highlight-code-border-color: var(--ring);
  --oow-highlight-link-color: var(--accent-1);
  --oow-highlight-link-decoration: underline;
  --oow-highlight-link-decoration-thickness: 2px;
  --oow-highlight-link-hover-color: var(--accent-4);
  --oow-highlight-blockquote-margin: 1.3em 0;
  --oow-highlight-blockquote-padding: 0.8em 1.2em;
  --oow-highlight-blockquote-border-left: 5px solid var(--ring);
  --oow-highlight-blockquote-color: var(--muted);
  --oow-highlight-blockquote-bg: rgba(255,255,255,0.06);
  --oow-highlight-hr-height: 2px;
  --oow-highlight-hr-bg: linear-gradient(90deg, var(--accent-1), var(--accent-2), var(--accent-3));
  --oow-highlight-hr-margin: 1.8em 0;
  --oow-highlight-pre-padding: 1.3em;
  --oow-highlight-pre-bg: rgba(0, 0, 0, 0.15);
  --oow-highlight-pre-border-radius: 8px;
  --oow-highlight-pre-font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  --oow-highlight-pre-font-size: 0.95em;
  --oow-highlight-table-margin: 1.8em 0;
  --oow-highlight-table-border: 2px solid var(--ring);
  --oow-highlight-table-cell-padding: 0.6em 0.9em;
  --oow-highlight-table-header-bg: rgba(255,255,255,0.1);
  --oow-highlight-table-header-color: var(--text-color);
  --oow-highlight-table-header-font-weight: 700;

  /* Enhanced Collapsible Section 变量 */
  --oow-collapsible-section-title-color: var(--accent-1);
  --oow-collapsible-section-phonetic-color: var(--accent-2);
  --oow-collapsible-section-speaker-hover-color: var(--accent-1);
  --oow-collapsible-section-toggle-hover-color: var(--accent-2);
}

`,Ut=`/* === Trigger Button - Galaxy Theme === */
.oow-selection-trigger-button[data-theme="galaxy"] {
  background: radial-gradient(ellipse at top, #1a1640, #080a20);
  border: none;
  box-shadow: 0 0 20px rgba(192, 132, 252, 0.5);
  color: #e0e7ff;
  border-radius: 2px !important;
  font-weight: 600;
  transition: all 0.3s ease;
}

.oow-selection-trigger-button[data-theme="galaxy"]:hover {
  box-shadow: 0 0 35px rgba(192, 132, 252, 0.7);
  transform: scale(1.12);
  transition: all 0.3s ease;
}

.oow-selection-trigger-button[data-theme="galaxy"].activated {
  background: transparent;
  border: 2px dotted #e879f9;
  padding: 4px;
  box-shadow: 0 0 45px rgba(192, 132, 252, 0.9), 0 0 15px rgba(232, 121, 249, 0.6);
  animation: galaxy-activated-pulse 1.5s infinite;
  transition: all 0.3s ease;
}

.oow-selection-trigger-button[data-theme="galaxy"].activated::before {
  content: '';
  position: absolute;
  top: 4px;
  left: 4px;
  right: 4px;
  bottom: 4px;
  background: radial-gradient(ellipse at top, #312e81, #1e1b4b);
  border-radius: 2px;
  z-index: -1;
}

`,Wt=`.oow-popover[data-theme="neon"] .header-title {
  color: var(--accent-1);
  text-shadow: 0 0 12px rgba(255, 0, 110, 0.5), 0 0 20px rgba(255, 0, 110, 0.3);
  font-weight: 800;
  font-size: 1.2em;
  letter-spacing: 2px;
  animation: neon-flicker 1.5s infinite alternate, neon-pulse 3s ease-in-out infinite;
}

@keyframes neon-flicker {
  0%, 100% {
    text-shadow: 0 0 12px rgba(255, 0, 110, 0.5), 0 0 20px rgba(255, 0, 110, 0.3);
  }
  50% {
    text-shadow: 0 0 8px rgba(255, 0, 110, 0.3), 0 0 12px rgba(255, 0, 110, 0.2);
  }
}

@keyframes neon-pulse {
  0%, 100% {
    text-shadow: 0 0 12px rgba(255, 0, 110, 0.5), 0 0 20px rgba(255, 0, 110, 0.3);
  }
  50% {
    text-shadow: 0 0 18px rgba(255, 0, 110, 0.7), 0 0 28px rgba(255, 0, 110, 0.4), 0 0 35px rgba(0, 217, 255, 0.2);
  }
}

.oow-popover[data-theme="neon"] .header-logo {
  background: var(--ring);
  border: 2px solid var(--accent-2);
  color: #000;
  box-shadow: 0 0 20px var(--ring), inset 0 0 10px rgba(0, 0, 0, 0.5);
  font-weight: 900;
  font-size: 1.1em;
  border-radius: 6px;
  animation: neon-logo-pulse 2s infinite;
}

@keyframes neon-logo-pulse {
  0%, 100% {
    box-shadow: 0 0 20px var(--ring), inset 0 0 10px rgba(0, 0, 0, 0.5);
  }
  50% {
    box-shadow: 0 0 30px var(--ring), 0 0 40px var(--accent-2), inset 0 0 15px rgba(0, 0, 0, 0.7);
  }
}

.oow-popover[data-theme="neon"] .section-title {
  color: var(--accent-2);
  text-shadow: 0 0 12px rgba(0, 217, 255, 0.4);
  font-weight: 700;
  font-size: 1.1em;
  letter-spacing: 1px;
  background: linear-gradient(90deg, transparent 60%, rgba(0, 217, 255, 0.1) 60%);
  background-size: 200% 100%;
  animation: neon-scan 2.5s linear infinite;
}

@keyframes neon-scan {
  0% {
    background-position: 100% 0;
  }
  100% {
    background-position: -100% 0;
  }
}

.oow-popover[data-theme="neon"] .def-item .pos {
  color: var(--accent-1);
  text-shadow: 0 0 10px var(--accent-1);
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 1px;
  font-size: 0.9em;
}

.oow-popover[data-theme="neon"] .def-item .meaning {
  color: var(--text-color);
}

.oow-popover[data-theme="neon"] .def-item .example {
  color: var(--muted);
  border-left: 3px solid var(--accent-2);
  padding-left: 12px;
  background: rgba(0, 217, 255, 0.06);
  border-radius: 0 4px 4px 0;
  margin-left: 2px;
}

.oow-popover[data-theme="neon"] .eq .bar {
  background: linear-gradient(180deg, var(--accent-1), var(--accent-2));
  box-shadow: 0 0 20px var(--accent-1), inset 0 1px 0 rgba(255, 255, 255, 0.2);
  border-radius: 8px;
  height: 10px;
  animation: neon-bar-pulse 2s infinite;
}

@keyframes neon-bar-pulse {
  0%, 100% {
    box-shadow: 0 0 20px var(--accent-1), inset 0 1px 0 rgba(255, 255, 255, 0.2);
  }
  50% {
    box-shadow: 0 0 30px var(--accent-1), 0 0 40px var(--accent-2), inset 0 1px 0 rgba(255, 255, 255, 0.3);
    height: 12px;
  }
}

`,Gt=`/* === Neon主题专属文字动效关键帧 === */

/* 霓虹灯管闪烁 - 模拟城市霓虹灯管的间歇闪烁 */
@keyframes neon-tube-flicker {
  0%, 100% {
    opacity: 1;
    text-shadow:
      0 0 10px currentColor,
      0 0 20px currentColor,
      0 0 30px currentColor;
  }
  5% {
    opacity: 0.7;
    text-shadow:
      0 0 5px currentColor;
  }
  10% {
    opacity: 1;
    text-shadow:
      0 0 15px currentColor,
      0 0 35px currentColor;
  }
  15% {
    opacity: 0.8;
    text-shadow:
      0 0 8px currentColor;
  }
  20% {
    opacity: 0.9;
    text-shadow:
      0 0 12px currentColor;
  }
}

/* 电码文字效果 - 模拟老式霓虹灯管的逐渐点亮 */
@keyframes neon-text-illuminate {
  0% {
    opacity: 0;
    text-shadow: none;
    color: rgba(0, 255, 65, 0);
  }
  20% {
    opacity: 0.3;
    text-shadow: 0 0 15px rgba(0, 255, 65, 0.3);
    color: rgba(0, 255, 65, 0.3);
  }
  40% {
    opacity: 0.6;
    text-shadow: 0 0 25px rgba(0, 255, 65, 0.5);
    color: rgba(0, 255, 65, 0.6);
  }
  60% {
    opacity: 0.8;
    text-shadow: 0 0 30px rgba(0, 255, 65, 0.7);
    color: rgba(0, 255, 65, 0.8);
  }
  80% {
    opacity: 0.95;
    text-shadow: 0 0 35px rgba(0, 255, 65, 0.8);
    color: rgba(0, 255, 65, 0.9);
  }
  100% {
    opacity: 1;
    text-shadow:
      0 0 20px currentColor,
      0 0 40px currentColor,
      0 0 60px currentColor;
    color: #00ff41;
  }
}

/* 霓虹故障艺术 - 模拟霓虹灯管的故障闪烁 */
@keyframes neon-glitch-effect {
  0%, 100% {
    transform: translateX(0);
    opacity: 1;
    filter: hue-rotate(0deg);
  }
  10% {
    transform: translateX(-2px);
    opacity: 0.8;
    filter: hue-rotate(90deg);
  }
  20% {
    transform: translateX(2px);
    opacity: 0.9;
    filter: hue-rotate(180deg);
  }
  30% {
    transform: translateX(-1px);
    opacity: 0.85;
    filter: hue-rotate(270deg);
  }
  40% {
    transform: translateX(1px);
    opacity: 0.95;
    filter: hue-rotate(360deg);
  }
}

/* 电子脉冲扫描 - 模拟电子扫描线 */
@keyframes neon-pulse-scan {
  0%, 100% {
    box-shadow: 0 0 0 0 rgba(0, 255, 65, 0.4);
  }
  50% {
    box-shadow: 0 0 0 10px rgba(0, 255, 65, 0.2);
  }
}

/* 数字雨效果 - 模拟背景数字雨 */
@keyframes neon-digital-rain {
  0% {
    background-position: 0% 0%;
    opacity: 0;
  }
  10% {
    opacity: 0.3;
  }
  90% {
    opacity: 0.3;
  }
  100% {
    background-position: 0% 100%;
    opacity: 0;
  }
}

/* 霓虹光晕扩散 - 模拟霓虹灯管的光晕 */
@keyframes neon-halo-expand {
  0% {
    box-shadow: 0 0 20px currentColor;
    opacity: 1;
  }
  50% {
    box-shadow: 0 0 40px currentColor, 0 0 60px currentColor;
    opacity: 0.8;
  }
  100% {
    box-shadow: 0 0 30px currentColor, 0 0 50px currentColor;
    opacity: 0.6;
  }
}

`,Kt=`/* Enhanced Neon glow effect for text */
.oow-popover[data-theme="neon"] .translation[data-style="gradient"] {
  background: transparent;
  border: none;
  border-radius: 0;
  padding: 0;
  box-shadow: none;
  background-image: linear-gradient(135deg, var(--accent-3), var(--accent-1), var(--accent-2));
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}

.oow-popover[data-theme="neon"] .contextual-analysis[data-style="gradient"] {
  background: transparent;
  border: none;
  border-radius: 0;
  padding: 0;
  box-shadow: none;
  background-image: linear-gradient(135deg, #00cc33, #00d9ff);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}

.oow-popover[data-theme="neon"] .text-translation {
  font-weight: 700;
  animation: neon-text-glow 2.5s ease-in-out infinite;
}

.oow-popover[data-theme="neon"] .translation .text {
  animation: neon-text-glow 2.5s ease-in-out infinite;
}

.oow-popover[data-theme="neon"] .contextual-analysis .text {
  font-weight: 400;
}

/* Neon主题的Info Panel和Etymology Panel样式 */
.oow-popover[data-theme="neon"] .info-panel-content,
.oow-popover[data-theme="neon"] .etymology-panel {
  /* 霓虹炫彩感：采用霓虹灯管般的文字效果，强化赛博朋克的视觉冲击力 */
  --oow-info-panel-heading-color: #00ff41;
  --oow-info-panel-heading-weight: 700;
  --oow-info-panel-heading-margin-top: 1.3em;
  --oow-info-panel-heading-margin-bottom: 0.7em;
  --oow-info-panel-paragraph-color: #00ff41;
  --oow-info-panel-paragraph-margin-bottom: 0.9em;
  --oow-info-panel-line-height: 1.5;
  --oow-info-panel-letter-spacing: 0.02em;
  --oow-info-panel-font-family: 'Orbitron', 'Courier New', 'Segoe UI', monospace, sans-serif;
  --oow-info-panel-list-color: #00ff41;
  --oow-info-panel-blockquote-color: #00cc33;
  --oow-info-panel-blockquote-border: #00ff41;
  --oow-info-panel-code-color: #ffbe0b;
  --oow-info-panel-code-bg: rgba(0, 0, 0, 0.1);
  --oow-info-panel-link-color: #ff006e;
  --oow-info-panel-link-hover: #00d9ff;
}

/* === Neon主题专属文字动效应用 === */

/* 霓虹灯管效果 - 标题闪烁 */
.oow-popover[data-theme="neon"] .info-panel-content h1,
.oow-popover[data-theme="neon"] .info-panel-content h2,
.oow-popover[data-theme="neon"] .info-panel-content h3,
.oow-popover[data-theme="neon"] .info-panel-content h4,
.oow-popover[data-theme="neon"] .info-panel-content h5,
.oow-popover[data-theme="neon"] .info-panel-content h6,
.oow-popover[data-theme="neon"] .etymology-panel h1,
.oow-popover[data-theme="neon"] .etymology-panel h2,
.oow-popover[data-theme="neon"] .etymology-panel h3,
.oow-popover[data-theme="neon"] .etymology-panel h4,
.oow-popover[data-theme="neon"] .etymology-panel h5,
.oow-popover[data-theme="neon"] .etymology-panel h6 {
  animation: neon-tube-flicker 3s infinite;
  text-shadow:
    0 0 10px currentColor,
    0 0 20px currentColor,
    0 0 30px currentColor,
    0 0 40px currentColor;
  transform: translateZ(0);
}

/* 电码文字效果 - 段落逐字点亮 */
.oow-popover[data-theme="neon"] .info-panel-content p,
.oow-popover[data-theme="neon"] .etymology-panel p {
  animation: neon-text-illuminate 2s ease-out forwards;
  transform: translateZ(0);
}

/* 霓虹故障艺术 - 链接悬停故障效果 */
.oow-popover[data-theme="neon"] .info-panel-content a,
.oow-popover[data-theme="neon"] .etymology-panel a {
  color: var(--oow-info-panel-link-color);
  text-decoration: none;
  position: relative;
  transition: all 0.3s ease;
  animation: neon-tube-flicker 4s infinite;
}

.oow-popover[data-theme="neon"] .info-panel-content a:hover,
.oow-popover[data-theme="neon"] .etymology-panel a:hover {
  color: var(--oow-info-panel-link-hover);
  animation: neon-glitch-effect 0.3s infinite;
  text-shadow:
    0 0 15px currentColor,
    0 0 25px currentColor,
    0 0 35px currentColor;
}

/* 电子脉冲扫描 - 列表项扫描效果 */
.oow-popover[data-theme="neon"] .info-panel-content ul li,
.oow-popover[data-theme="neon"] .info-panel-content ol li,
.oow-popover[data-theme="neon"] .etymology-panel ul li,
.oow-popover[data-theme="neon"] .etymology-panel ol li {
  animation: neon-pulse-scan 2.5s infinite;
  position: relative;
  transform: translateZ(0);
}

.oow-popover[data-theme="neon"] .info-panel-content ul li::before,
.oow-popover[data-theme="neon"] .info-panel-content ol li::before,
.oow-popover[data-theme="neon"] .etymology-panel ul li::before,
.oow-popover[data-theme="neon"] .etymology-panel ol li::before {
  content: '▶';
  color: var(--accent-1);
  margin-right: 8px;
  animation: neon-tube-flicker 2s infinite;
  text-shadow: 0 0 10px var(--accent-1);
}

/* 霓虹光晕扩散 - 强调文字 */
.oow-popover[data-theme="neon"] .info-panel-content strong,
.oow-popover[data-theme="neon"] .etymology-panel strong {
  color: var(--accent-1);
  font-weight: 700;
  animation: neon-halo-expand 2s ease-in-out infinite;
  text-shadow:
    0 0 15px currentColor,
    0 0 25px currentColor,
    0 0 35px currentColor;
  transform: translateZ(0);
}

/* 斜体霓虹效果 */
.oow-popover[data-theme="neon"] .info-panel-content em,
.oow-popover[data-theme="neon"] .etymology-panel em {
  color: var(--accent-2);
  font-style: italic;
  animation: neon-tube-flicker 3.5s infinite;
  text-shadow:
    0 0 12px currentColor,
    0 0 20px currentColor,
    0 0 28px currentColor;
  transform: translateZ(0);
}

/* 代码块霓虹灯效果 */
.oow-popover[data-theme="neon"] .info-panel-content code,
.oow-popover[data-theme="neon"] .etymology-panel code {
  color: var(--oow-info-panel-code-color);
  background: var(--oow-info-panel-code-bg);
  padding: 0.2em 0.4em;
  border-radius: 4px;
  font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  border: 1px solid var(--accent-2);
  animation: neon-text-illuminate 1.5s ease-out forwards;
  text-shadow: 0 0 8px currentColor;
  transform: translateZ(0);
}

/* 引用块霓虹边框 */
.oow-popover[data-theme="neon"] .info-panel-content blockquote,
.oow-popover[data-theme="neon"] .etymology-panel blockquote {
  margin: var(--oow-highlight-blockquote-margin);
  padding: var(--oow-highlight-blockquote-padding);
  border-left: 5px solid var(--oow-info-panel-blockquote-border);
  background: rgba(0, 0, 0, 0.1);
  color: var(--oow-info-panel-blockquote-color);
  border-radius: 0 8px 8px 0;
  position: relative;
  animation: neon-halo-expand 3s ease-in-out infinite;
}

.oow-popover[data-theme="neon"] .info-panel-content blockquote::before,
.oow-popover[data-theme="neon"] .etymology-panel blockquote::before {
  content: '"';
  position: absolute;
  top: -10px;
  left: 10px;
  color: var(--accent-1);
  font-size: 3em;
  opacity: 0.3;
  animation: neon-tube-flicker 4s infinite;
  text-shadow: 0 0 15px var(--accent-1);
}

/* 分隔线霓虹渐变 */
.oow-popover[data-theme="neon"] .info-panel-content hr,
.oow-popover[data-theme="neon"] .etymology-panel hr {
  border: none;
  height: 2px;
  background: linear-gradient(90deg,
    transparent 0%,
    var(--accent-1) 20%,
    var(--accent-2) 50%,
    var(--accent-3) 80%,
    transparent 100%);
  margin: 2em 0;
  animation: neon-halo-expand 2s ease-in-out infinite;
}

/* 预格式化文本数字雨背景 */
.oow-popover[data-theme="neon"] .info-panel-content pre,
.oow-popover[data-theme="neon"] .etymology-panel pre {
  background:
    repeating-linear-gradient(
      0deg,
      transparent,
      transparent 2px,
      rgba(0, 255, 65, 0.03) 2px,
      rgba(0, 255, 65, 0.03) 4px
    ),
    var(--oow-highlight-pre-bg);
  border: 2px solid var(--ring);
  border-radius: var(--oow-highlight-pre-border-radius);
  padding: var(--oow-highlight-pre-padding);
  overflow-x: auto;
  font-family: var(--oow-highlight-pre-font-family);
  font-size: var(--oow-highlight-pre-font-size);
  color: var(--text-color);
  animation: neon-digital-rain 10s linear infinite;
  position: relative;
}

.oow-popover[data-theme="neon"] .info-panel-content pre::before,
.oow-popover[data-theme="neon"] .etymology-panel pre::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background:
    repeating-linear-gradient(
      90deg,
      transparent 0px,
      transparent 50px,
      rgba(0, 217, 255, 0.05) 50px,
      rgba(0, 217, 255, 0.05) 100px
    );
  pointer-events: none;
  animation: neon-pulse-scan 3s linear infinite;
}

/* 表格霓虹边框 */
.oow-popover[data-theme="neon"] .info-panel-content table,
.oow-popover[data-theme="neon"] .etymology-panel table {
  width: 100%;
  border-collapse: collapse;
  margin: var(--oow-highlight-table-margin);
  border: 2px solid var(--ring);
  border-radius: 8px;
  overflow: hidden;
  animation: neon-halo-expand 4s ease-in-out infinite;
}

.oow-popover[data-theme="neon"] .info-panel-content table th,
.oow-popover[data-theme="neon"] .etymology-panel table th {
  background: var(--oow-highlight-table-header-bg);
  color: var(--oow-highlight-table-header-color);
  font-weight: var(--oow-highlight-table-header-font-weight);
  padding: var(--oow-highlight-table-cell-padding);
  text-align: left;
  border-bottom: 2px solid var(--ring);
  animation: neon-tube-flicker 3s infinite;
  text-shadow: 0 0 10px var(--text-color);
}

.oow-popover[data-theme="neon"] .info-panel-content table td,
.oow-popover[data-theme="neon"] .etymology-panel table td {
  padding: var(--oow-highlight-table-cell-padding);
  border-bottom: 1px solid rgba(0, 255, 65, 0.2);
  color: var(--text-color);
  animation: neon-text-illuminate 1s ease-out forwards;
}

.oow-popover[data-theme="neon"] .info-panel-content table tr:hover td,
.oow-popover[data-theme="neon"] .etymology-panel table tr:hover td {
  background: rgba(0, 255, 65, 0.1);
  animation: neon-glitch-effect 0.5s infinite;
}

/* 性能优化 - GPU加速 */
@media (min-width: 768px) {
  .oow-popover[data-theme="neon"] .info-panel-content *,
  .oow-popover[data-theme="neon"] .etymology-panel * {
    transform: translateZ(0);
    will-change: transform, opacity;
  }
}

/* 减少动效 - 无障碍支持 */
@media (prefers-reduced-motion: reduce) {
  .oow-popover[data-theme="neon"] .info-panel-content *,
  .oow-popover[data-theme="neon"] .etymology-panel * {
    animation: none !important;
    text-shadow: none !important;
  }
}

`,qt=`/*
 * Origin of Words - Neon Theme (Premium)
 * 霓虹主题 - 付费赛博霓虹主题
 * 100% original style with ORIGINAL variable names
 */

/* Theme Variables - CRITICAL: Use original variable names */
.oow-popover[data-theme="neon"] {
  --panel-bg: #000000;
  --text-color: #00ff41;
  --muted: #00cc33;
  --ring: #00ff41; /* bright green */
  --accent-1: #ff006e; /* hot pink */
  --accent-2: #00d9ff; /* cyan */
  --accent-3: #ffbe0b; /* electric yellow */
  --accent-4: #9d4edd; /* deep purple */
  backdrop-filter: blur(15px);
  background: #000000 !important;
  border: 2px solid var(--ring);
  box-shadow: 0 0 40px var(--ring), inset 0 0 30px rgba(0, 255, 65, 0.15);

  /* Enhanced Unified Button Styles */
  --oow-button-bg: rgba(0, 255, 65, 0.2);
  --oow-button-hover-bg: var(--ring);
  --oow-button-color: var(--text-color);
  --oow-button-hover-color: #000;
  --oow-button-radius: 8px;
  --oow-button-transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  /* Enhanced Markdown Highlight Styles */
  --oow-highlight-heading-color: var(--text-color);
  --oow-highlight-heading-font-weight: 700;
  --oow-highlight-heading-margin-top: 1.3em;
  --oow-highlight-heading-margin-bottom: 0.7em;
  --oow-highlight-h1-font-size: 1.6em;
  --oow-highlight-h2-font-size: 1.35em;
  --oow-highlight-h3-font-size: 1.2em;
  --oow-highlight-h4-font-size: 1.1em;
  --oow-highlight-h5-font-size: 1em;
  --oow-highlight-h6-font-size: 0.9em;
  --oow-highlight-strong-color: var(--accent-1);
  --oow-highlight-strong-font-weight: 700;
  --oow-highlight-em-color: var(--accent-2);
  --oow-highlight-em-font-style: italic;
  --oow-highlight-code-color: var(--accent-3);
  --oow-highlight-code-bg: rgba(0, 0, 0, 0.1);
  --oow-highlight-code-border-color: var(--ring);
  --oow-highlight-link-color: var(--accent-1);
  --oow-highlight-link-decoration: underline;
  --oow-highlight-link-decoration-thickness: 2px;
  --oow-highlight-link-hover-color: var(--accent-2);
  --oow-highlight-blockquote-margin: 1.3em 0;
  --oow-highlight-blockquote-padding: 0.8em 1.2em;
  --oow-highlight-blockquote-border-left: 5px solid var(--ring);
  --oow-highlight-blockquote-color: var(--muted);
  --oow-highlight-blockquote-bg: rgba(0, 0, 0, 0.1);
  --oow-highlight-hr-height: 2px;
  --oow-highlight-hr-bg: linear-gradient(90deg, var(--accent-1), var(--accent-2), var(--accent-3));
  --oow-highlight-hr-margin: 1.8em 0;
  --oow-highlight-pre-padding: 1.3em;
  --oow-highlight-pre-bg: rgba(0, 0, 0, 0.15);
  --oow-highlight-pre-border-radius: 8px;
  --oow-highlight-pre-font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  --oow-highlight-pre-font-size: 0.95em;
  --oow-highlight-table-margin: 1.8em 0;
  --oow-highlight-table-border: 2px solid var(--ring);
  --oow-highlight-table-cell-padding: 0.6em 0.9em;
  --oow-highlight-table-header-bg: rgba(255,255,255,0.1);
  --oow-highlight-table-header-color: var(--text-color);
  --oow-highlight-table-header-font-weight: 700;

  /* Enhanced Collapsible Section 变量 */
  --oow-collapsible-section-title-color: var(--accent-2);
  --oow-collapsible-section-phonetic-color: var(--muted);
  --oow-collapsible-section-speaker-hover-color: var(--accent-1);
  --oow-collapsible-section-toggle-hover-color: var(--accent-2);
}

`,Jt=`.oow-selection-trigger-button[data-theme="neon"] {
  background: #000000;
  border: none;
  box-shadow: 0 0 15px rgba(0, 255, 65, 0.4);
  color: #00ff41;
  text-shadow: 0 0 6px rgba(0, 255, 65, 0.3);
  border-radius: 2px !important;
  font-weight: 600;
  transition: var(--oow-button-transition);
  animation: neon-standby-pulse 2s ease-in-out infinite;
}

.oow-selection-trigger-button[data-theme="neon"]:hover {
  background: #00ff41;
  color: #000;
  box-shadow: 0 0 25px rgba(0, 255, 65, 0.5);
  text-shadow: none;
  transform: scale(1.08);
  transition: var(--oow-button-transition);
}

.oow-selection-trigger-button[data-theme="neon"].activated {
  background: transparent;
  border: 2px dashed #ff006e;
  padding: 4px;
  box-shadow: 0 0 35px rgba(255, 0, 110, 0.6), 0 0 15px rgba(0, 217, 255, 0.4);
  color: #00ff41;
  animation: none;
  transition: var(--oow-button-transition);
}

.oow-selection-trigger-button[data-theme="neon"].activated::before {
  content: '';
  position: absolute;
  top: 4px;
  left: 4px;
  right: 4px;
  bottom: 4px;
  background: #00ff41;
  border-radius: 1px;
  z-index: -1;
}

@keyframes neon-standby-pulse {
  0%, 100% {
    box-shadow: 0 0 15px rgba(0, 255, 65, 0.4), 0 0 8px rgba(0, 255, 65, 0.2);
    opacity: 1;
  }
  50% {
    box-shadow: 0 0 25px rgba(0, 255, 65, 0.6), 0 0 12px rgba(0, 255, 65, 0.3);
    opacity: 0.85;
  }
}
`,Yt=`/* === Pro主题专属专业商务动效关键帧 === */

/* 专业淡入渐显 - 模拟商务演示的渐进式展示 */
@keyframes pro-fade-in-up {
  0% {
    opacity: 0;
    transform: translateY(20px);
    filter: blur(2px);
  }
  50% {
    opacity: 0.8;
    transform: translateY(-2px);
    filter: blur(0px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
    filter: blur(0px);
  }
}

/* 商务滑动进入 - 模拟PPT元素的滑动效果 */
@keyframes pro-slide-in-right {
  0% {
    opacity: 0;
    transform: translateX(30px);
    clip-path: inset(0 100% 0 0);
  }
  70% {
    opacity: 0.9;
    transform: translateX(-2px);
  }
  100% {
    opacity: 1;
    transform: translateX(0);
    clip-path: inset(0 0 0 0);
  }
}

/* 专业精确度标尺 - 模拟专业测量工具的精确感 */
@keyframes pro-precision-ruler {
  0% {
    background-position: 0% 0%;
    box-shadow: inset 0 0 0 0 rgba(59, 130, 246, 0.1);
  }
  50% {
    background-position: 100% 0%;
    box-shadow: inset 0 0 20px 0 rgba(59, 130, 246, 0.15);
  }
  100% {
    background-position: 0% 0%;
    box-shadow: inset 0 0 0 0 rgba(59, 130, 246, 0.1);
  }
}

/* 商务进度条 - 模拟项目进度的专业感 */
@keyframes pro-progress-bar {
  0% {
    background-size: 0% 100%;
    border-color: rgba(59, 130, 246, 0.3);
  }
  50% {
    background-size: 60% 100%;
    border-color: rgba(59, 130, 246, 0.6);
  }
  100% {
    background-size: 100% 100%;
    border-color: rgba(59, 130, 246, 0.8);
  }
}

/* 专业数据流 - 模拟商务数据流动 */
@keyframes pro-data-flow {
  0% {
    background-position: -100% 0%;
    opacity: 0.6;
  }
  50% {
    background-position: 100% 0%;
    opacity: 1;
  }
  100% {
    background-position: -100% 0%;
    opacity: 0.6;
  }
}

/* 商务强调脉冲 - 模拟商务重点突出 */
@keyframes pro-emphasis-pulse {
  0%, 100% {
    transform: scale(1);
    box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4);
  }
  50% {
    transform: scale(1.05);
    box-shadow: 0 0 15px 5px rgba(16, 185, 129, 0.2);
  }
}

/* 专业打字机效果 - 模拟专业文档输入 */
@keyframes pro-typewriter {
  0% {
    width: 0;
    opacity: 0;
  }
  10% {
    opacity: 1;
  }
  90% {
    width: 100%;
    opacity: 1;
  }
  100% {
    width: 100%;
    opacity: 1;
  }
}

/* 商务光泽扫过 - 模拟金属质感光泽 */
@keyframes pro-metallic-sweep {
  0% {
    background-position: -200% 0%;
    opacity: 0;
  }
  50% {
    opacity: 0.8;
  }
  100% {
    background-position: 200% 0%;
    opacity: 0;
  }
}

/* === Pro主题专属专业商务动效应用 === */

/* 专业淡入渐显 - 标题商务展示 */
.oow-popover[data-theme="pro"] .info-panel-content h1,
.oow-popover[data-theme="pro"] .info-panel-content h2,
.oow-popover[data-theme="pro"] .info-panel-content h3,
.oow-popover[data-theme="pro"] .info-panel-content h4,
.oow-popover[data-theme="pro"] .info-panel-content h5,
.oow-popover[data-theme="pro"] .info-panel-content h6,
.oow-popover[data-theme="pro"] .etymology-panel h1,
.oow-popover[data-theme="pro"] .etymology-panel h2,
.oow-popover[data-theme="pro"] .etymology-panel h3,
.oow-popover[data-theme="pro"] .etymology-panel h4,
.oow-popover[data-theme="pro"] .etymology-panel h5,
.oow-popover[data-theme="pro"] .etymology-panel h6 {
  animation: pro-fade-in-up 0.8s ease-out forwards;
  position: relative;
  color: var(--oow-info-panel-heading-color);
  font-weight: var(--oow-info-panel-heading-weight);
  transform: translateZ(0);
}

.oow-popover[data-theme="pro"] .info-panel-content h1::after,
.oow-popover[data-theme="pro"] .info-panel-content h2::after,
.oow-popover[data-theme="pro"] .info-panel-content h3::after,
.oow-popover[data-theme="pro"] .etymology-panel h1::after,
.oow-popover[data-theme="pro"] .etymology-panel h2::after,
.oow-popover[data-theme="pro"] .etymology-panel h3::after {
  content: '';
  position: absolute;
  bottom: -4px;
  left: 0;
  width: 0;
  height: 2px;
  background: linear-gradient(90deg, var(--accent-1), var(--accent-2));
  animation: pro-progress-bar 1.5s ease-out 0.3s forwards;
}

/* 商务滑动进入 - 段落专业展示 */
.oow-popover[data-theme="pro"] .info-panel-content p,
.oow-popover[data-theme="pro"] .etymology-panel p {
  animation: pro-slide-in-right 0.6s ease-out forwards;
  color: var(--oow-info-panel-paragraph-color);
  line-height: var(--oow-info-panel-line-height);
  transform: translateZ(0);
}

/* 专业精确度标尺 - 链接商务交互 */
.oow-popover[data-theme="pro"] .info-panel-content a,
.oow-popover[data-theme="pro"] .etymology-panel a {
  color: var(--oow-info-panel-link-color);
  text-decoration: none;
  position: relative;
  transition: all 0.3s ease;
  font-weight: 500;
  background: linear-gradient(90deg, transparent, rgba(59, 130, 246, 0.1), transparent);
  background-size: 200% 100%;
  animation: pro-precision-ruler 3s ease-in-out infinite;
  padding: 2px 4px;
  border-radius: 3px;
  transform: translateZ(0);
}

.oow-popover[data-theme="pro"] .info-panel-content a::before,
.oow-popover[data-theme="pro"] .etymology-panel a::before {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 1px;
  background: var(--oow-info-panel-link-color);
  transform: scaleX(0);
  transform-origin: left;
  transition: transform 0.3s ease;
}

.oow-popover[data-theme="pro"] .info-panel-content a:hover,
.oow-popover[data-theme="pro"] .etymology-panel a:hover {
  color: var(--oow-info-panel-link-hover);
  background: linear-gradient(90deg, transparent, rgba(16, 185, 129, 0.15), transparent);
  animation: pro-data-flow 2s linear infinite;
}

.oow-popover[data-theme="pro"] .info-panel-content a:hover::before,
.oow-popover[data-theme="pro"] .etymology-panel a:hover::before {
  transform: scaleX(1);
}

/* 专业数据流 - 列表项商务展示 */
.oow-popover[data-theme="pro"] .info-panel-content ul li,
.oow-popover[data-theme="pro"] .info-panel-content ol li,
.oow-popover[data-theme="pro"] .etymology-panel ul li,
.oow-popover[data-theme="pro"] .etymology-panel ol li {
  animation: pro-slide-in-right 0.8s ease-out forwards;
  position: relative;
  padding-left: 20px;
  margin-bottom: 0.6em;
  color: var(--oow-info-panel-list-color);
  transform: translateZ(0);
}

.oow-popover[data-theme="pro"] .info-panel-content ul li::before,
.oow-popover[data-theme="pro"] .info-panel-content ol li::before,
.oow-popover[data-theme="pro"] .etymology-panel ul li::before,
.oow-popover[data-theme="pro"] .etymology-panel ol li::before {
  content: '▸';
  position: absolute;
  left: 0;
  color: var(--accent-1);
  font-weight: 700;
  animation: pro-emphasis-pulse 2s ease-in-out infinite;
}

/* 商务强调脉冲 - 强调文字 */
.oow-popover[data-theme="pro"] .info-panel-content strong,
.oow-popover[data-theme="pro"] .etymology-panel strong {
  color: var(--accent-2);
  font-weight: 700;
  position: relative;
  display: inline-block;
  animation: pro-emphasis-pulse 3s ease-in-out infinite;
  transform: translateZ(0);
}

.oow-popover[data-theme="pro"] .info-panel-content strong::after,
.oow-popover[data-theme="pro"] .etymology-panel strong::after {
  content: '';
  position: absolute;
  bottom: -2px;
  left: 0;
  width: 100%;
  height: 1px;
  background: var(--accent-2);
  opacity: 0.5;
}

/* 专业斜体效果 - 斜体文字 */
.oow-popover[data-theme="pro"] .info-panel-content em,
.oow-popover[data-theme="pro"] .etymology-panel em {
  color: var(--accent-1);
  font-style: italic;
  font-weight: 500;
  animation: pro-fade-in-up 0.7s ease-out forwards;
  transform: translateZ(0);
}

/* 专业代码块 - 商务代码展示 */
.oow-popover[data-theme="pro"] .info-panel-content code,
.oow-popover[data-theme="pro"] .etymology-panel code {
  background: var(--oow-info-panel-code-bg);
  color: var(--oow-info-panel-code-color);
  padding: 0.2em 0.5em;
  border-radius: 4px;
  font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  border: 1px solid var(--ring);
  border-left: 3px solid var(--accent-3);
  animation: pro-slide-in-right 0.5s ease-out forwards;
  position: relative;
  transform: translateZ(0);
}

.oow-popover[data-theme="pro"] .info-panel-content code::before,
.oow-popover[data-theme="pro"] .etymology-panel code::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, var(--accent-3), transparent);
  animation: pro-metallic-sweep 4s ease-in-out infinite;
}

/* 专业引用块 - 商务引用设计 */
.oow-popover[data-theme="pro"] .info-panel-content blockquote,
.oow-popover[data-theme="pro"] .etymology-panel blockquote {
  margin: var(--oow-highlight-blockquote-margin);
  padding: var(--oow-highlight-blockquote-padding);
  border-left: 4px solid var(--oow-info-panel-blockquote-border);
  background: var(--oow-highlight-blockquote-bg);
  color: var(--oow-info-panel-blockquote-color);
  border-radius: 0 6px 6px 0;
  position: relative;
  animation: pro-fade-in-up 0.9s ease-out forwards;
  transform: translateZ(0);
}

.oow-popover[data-theme="pro"] .info-panel-content blockquote::before,
.oow-popover[data-theme="pro"] .etymology-panel blockquote::before {
  content: '"';
  position: absolute;
  top: -10px;
  left: 8px;
  color: var(--accent-1);
  font-size: 2.5em;
  opacity: 0.3;
  font-weight: 300;
}

/* 专业分隔线 - 商务分隔效果 */
.oow-popover[data-theme="pro"] .info-panel-content hr,
.oow-popover[data-theme="pro"] .etymology-panel hr {
  border: none;
  height: var(--oow-highlight-hr-height);
  background: var(--oow-highlight-hr-bg);
  margin: var(--oow-highlight-hr-margin);
  position: relative;
  overflow: hidden;
  animation: pro-progress-bar 2s ease-out forwards;
}

.oow-popover[data-theme="pro"] .info-panel-content hr::after,
.oow-popover[data-theme="pro"] .etymology-panel hr::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
  animation: pro-metallic-sweep 3s ease-in-out infinite;
}

/* 专业预格式化文本 - 商务代码展示 */
.oow-popover[data-theme="pro"] .info-panel-content pre,
.oow-popover[data-theme="pro"] .etymology-panel pre {
  background: var(--oow-highlight-pre-bg);
  border: 1px solid var(--ring);
  border-radius: var(--oow-highlight-pre-border-radius);
  padding: var(--oow-highlight-pre-padding);
  overflow-x: auto;
  font-family: var(--oow-highlight-pre-font-family);
  font-size: var(--oow-highlight-pre-font-size);
  color: var(--text-color);
  position: relative;
  animation: pro-fade-in-up 1s ease-out forwards;
  transform: translateZ(0);
}

.oow-popover[data-theme="pro"] .info-panel-content pre::before,
.oow-popover[data-theme="pro"] .etymology-panel pre::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: linear-gradient(90deg, var(--accent-1), var(--accent-2), var(--accent-3));
  border-radius: 3px 3px 0 0;
  animation: pro-data-flow 5s linear infinite;
}

/* 专业表格 - 商务表格设计 */
.oow-popover[data-theme="pro"] .info-panel-content table,
.oow-popover[data-theme="pro"] .etymology-panel table {
  width: 100%;
  border-collapse: collapse;
  margin: var(--oow-highlight-table-margin);
  border: var(--oow-highlight-table-border);
  border-radius: 6px;
  overflow: hidden;
  animation: pro-fade-in-up 1.1s ease-out forwards;
  transform: translateZ(0);
}

.oow-popover[data-theme="pro"] .info-panel-content table th,
.oow-popover[data-theme="pro"] .etymology-panel table th {
  background: var(--oow-highlight-table-header-bg);
  color: var(--oow-highlight-table-header-color);
  font-weight: var(--oow-highlight-table-header-font-weight);
  padding: var(--oow-highlight-table-cell-padding);
  text-align: left;
  border-bottom: 2px solid var(--accent-1);
  animation: pro-slide-in-right 0.8s ease-out forwards;
}

.oow-popover[data-theme="pro"] .info-panel-content table td,
.oow-popover[data-theme="pro"] .etymology-panel table td {
  padding: var(--oow-highlight-table-cell-padding);
  border-bottom: 1px solid var(--ring);
  color: var(--text-color);
  animation: pro-slide-in-right 0.6s ease-out forwards;
}

.oow-popover[data-theme="pro"] .info-panel-content table tr:hover td,
.oow-popover[data-theme="pro"] .etymology-panel table tr:hover td {
  background: rgba(59, 130, 246, 0.1);
  animation: pro-emphasis-pulse 1s ease-in-out infinite;
}

/* 性能优化 - GPU加速 */
@media (min-width: 768px) {
  .oow-popover[data-theme="pro"] .info-panel-content *,
  .oow-popover[data-theme="pro"] .etymology-panel * {
    transform: translateZ(0);
    will-change: transform, opacity;
  }
}

/* 减少动效 - 无障碍支持 */
@media (prefers-reduced-motion: reduce) {
  .oow-popover[data-theme="pro"] .info-panel-content *,
  .oow-popover[data-theme="pro"] .etymology-panel * {
    animation: none !important;
    background: none !important;
  }
}`,Xt=`/* Pro主题的translation和contextual-analysis样式 */
.oow-popover[data-theme="pro"] .translation[data-style="framed"] {
  background: rgba(59, 130, 246, 0.1);
  border: 1px solid rgba(59, 130, 246, 0.3);
  border-radius: 6px;
  padding: 10px 12px;
  box-shadow: 0 2px 8px rgba(59, 130, 246, 0.2);
}

.oow-popover[data-theme="pro"] .contextual-analysis[data-style="framed"] {
  background: rgba(156, 163, 175, 0.1);
  border: 1px solid rgba(156, 163, 175, 0.2);
  border-radius: 6px;
  padding: 10px 12px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.oow-popover[data-theme="pro"] .translation .text {
  color: #60a5fa;
  font-weight: 700;
}

.oow-popover[data-theme="pro"] .contextual-analysis .text {
  color: #d1d5db;
  font-weight: 400;
}

/* Pro主题的Info Panel和Etymology Panel样式 */
.oow-popover[data-theme="pro"] .info-panel-content,
.oow-popover[data-theme="pro"] .etymology-panel {
  /* 专业立体风格：采用深色背景与浅色文字的经典搭配，增强立体感 */
  --oow-info-panel-heading-color: #f9fafb;
  --oow-info-panel-heading-weight: 600;
  --oow-info-panel-heading-margin-top: 1.3em;
  --oow-info-panel-heading-margin-bottom: 0.7em;
  --oow-info-panel-paragraph-color: #f9fafb;
  --oow-info-panel-paragraph-margin-bottom: 0.9em;
  --oow-info-panel-line-height: 1.6;
  --oow-info-panel-letter-spacing: 0.01em;
  --oow-info-panel-font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  --oow-info-panel-list-color: #f9fafb;
  --oow-info-panel-blockquote-color: #9ca3af;
  --oow-info-panel-blockquote-border: #3b82f6;
  --oow-info-panel-code-color: #f59e0b;
  --oow-info-panel-code-bg: rgba(0, 0, 0, 0.2);
  --oow-info-panel-link-color: #3b82f6;
  --oow-info-panel-link-hover: #10b981;
}

`,Zt=`/*
 * Origin of Words - Pro Theme (Free)
 * 专业主题 - 免费高级主题
 * 100% original style with ORIGINAL variable names
 */

/* Theme Variables - CRITICAL: Use original variable names */
.oow-popover[data-theme="pro"] {
  --panel-bg: #1f2937;
  --text-color: #f9fafb;
  --muted: #9ca3af;
  --ring: #6b7280;
  --accent-1: #3b82f6;
  --accent-2: #10b981;
  --accent-3: #f59e0b;
  backdrop-filter: blur(10px);
  background: var(--panel-bg) !important;
  border: 1px solid rgba(107, 114, 128, 0.3);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.1);

  /* Unified Button Styles */
  --oow-button-bg: var(--accent-1);
  --oow-button-hover-bg: #2563eb;
  --oow-button-color: white;
  --oow-button-hover-color: white;
  --oow-button-radius: 8px;
  --oow-button-transition: all 0.3s ease;

  /* Enhanced Markdown Highlight Styles */
  --oow-highlight-heading-color: var(--text-color);
  --oow-highlight-heading-font-weight: 600;
  --oow-highlight-heading-margin-top: 1.3em;
  --oow-highlight-heading-margin-bottom: 0.7em;
  --oow-highlight-h1-font-size: 1.6em;
  --oow-highlight-h2-font-size: 1.35em;
  --oow-highlight-h3-font-size: 1.2em;
  --oow-highlight-h4-font-size: 1.1em;
  --oow-highlight-h5-font-size: 1em;
  --oow-highlight-h6-font-size: 0.9em;
  --oow-highlight-strong-color: var(--accent-2);
  --oow-highlight-strong-font-weight: 700;
  --oow-highlight-em-color: var(--accent-1);
  --oow-highlight-em-font-style: italic;
  --oow-highlight-code-color: var(--accent-3);
  --oow-highlight-code-bg: rgba(0, 0, 0, 0.2);
  --oow-highlight-code-border-color: var(--ring);
  --oow-highlight-link-color: var(--accent-1);
  --oow-highlight-link-decoration: underline;
  --oow-highlight-link-decoration-thickness: 2px;
  --oow-highlight-link-hover-color: var(--accent-2);
  --oow-highlight-blockquote-margin: 1.3em 0;
  --oow-highlight-blockquote-padding: 0.8em 1.2em;
  --oow-highlight-blockquote-border-left: 4px solid var(--accent-1);
  --oow-highlight-blockquote-color: var(--muted);
  --oow-highlight-blockquote-bg: rgba(59, 130, 246, 0.1);
  --oow-highlight-hr-height: 2px;
  --oow-highlight-hr-bg: var(--accent-1);
  --oow-highlight-hr-margin: 1.8em 0;
  --oow-highlight-pre-padding: 1.2em;
  --oow-highlight-pre-bg: rgba(0, 0, 0, 0.15);
  --oow-highlight-pre-border-radius: 8px;
  --oow-highlight-pre-font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
  --oow-highlight-pre-font-size: 0.95em;
  --oow-highlight-table-margin: 1.8em 0;
  --oow-highlight-table-border: 2px solid var(--accent-1);
  --oow-highlight-table-cell-padding: 0.6em 0.9em;
  --oow-highlight-table-header-bg: rgba(59, 130, 246, 0.15);
  --oow-highlight-table-header-color: var(--text-color);
  --oow-highlight-table-header-font-weight: 700;
}

`,Qt=`/* === Trigger Button - Pro Theme === */
.oow-selection-trigger-button[data-theme="pro"] {
  background: #1f2937; /* Unified dark background from theme */
  border: 1px solid transparent; /* Use transparent border to prevent size shifts */
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
  color: #f9fafb; /* Light text/icon color from theme */
  border-radius: 8px; /* Default shape is a rounded square */
  font-weight: 600;
  transition: all 0.3s ease;
}

.oow-selection-trigger-button[data-theme="pro"]:hover {
  background: #1f2937; /* Keep background unified */
  border-color: var(--ring); /* Subtle border color on hover for feedback */
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.3);
  transform: translateY(-2px) scale(1.02);
}

.oow-selection-trigger-button[data-theme="pro"].activated {
  background: #1f2937; /* Keep background unified */
  border-radius: 50%; /* Refined: Change shape to a circle */
  border: 3px dashed #f59e0b; /* Refined: A circular, dashed, high-contrast border */
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
  color: #f9fafb;
  transform: scale(1.05);
}

`,$t=`shared/part-01.css,shared/part-02.css,shared/part-03.css,shared/part-04.css,shared/part-05.css,shared/part-06.css,shared/part-07.css,shared/part-08.css,shared/part-09.css,themes/basic/tokens/part-01.css,themes/basic/trigger/part-01.css,themes/basic/panels/part-01.css,themes/basic/effects/part-01.css,themes/pro/tokens/part-01.css,themes/pro/trigger/part-01.css,themes/pro/panels/part-01.css,themes/pro/effects/part-01.css,themes/creative/tokens/part-01.css,themes/creative/trigger/part-01.css,themes/creative/panels/part-01.css,themes/creative/effects/part-01.css,themes/galaxy/tokens/part-01.css,themes/galaxy/effects/part-01.css,themes/galaxy/trigger/part-01.css,themes/galaxy/panels/part-01.css,themes/galaxy/effects/part-02.css,themes/galaxy/effects/part-03.css,themes/neon/tokens/part-01.css,themes/neon/effects/part-01.css,themes/neon/panels/part-01.css,themes/neon/effects/part-02.css,themes/neon/trigger/part-01.css,themes/cyberpunk/tokens/part-01.css,themes/cyberpunk/effects/part-01.css,themes/cyberpunk/trigger/part-01.css,themes/cyberpunk/panels/part-01.css,themes/cyberpunk/effects/part-02.css,themes/cyberpunk/effects/part-03.css,themes/cyberpunk/effects/part-04.css,themes/aurora/tokens/part-01.css,themes/aurora/effects/part-01.css,themes/aurora/panels/part-01.css,themes/aurora/effects/part-02.css,themes/aurora/trigger/part-01.css`.split(`,`),en=Object.assign({"./original-themes/shared/part-01.css":lt,"./original-themes/shared/part-02.css":ut,"./original-themes/shared/part-03.css":dt,"./original-themes/shared/part-04.css":ft,"./original-themes/shared/part-05.css":pt,"./original-themes/shared/part-06.css":mt,"./original-themes/shared/part-07.css":ht,"./original-themes/shared/part-08.css":gt,"./original-themes/shared/part-09.css":_t,"./original-themes/themes/aurora/effects/part-01.css":vt,"./original-themes/themes/aurora/effects/part-02.css":yt,"./original-themes/themes/aurora/panels/part-01.css":bt,"./original-themes/themes/aurora/tokens/part-01.css":xt,"./original-themes/themes/aurora/trigger/part-01.css":St,"./original-themes/themes/basic/effects/part-01.css":Ct,"./original-themes/themes/basic/panels/part-01.css":wt,"./original-themes/themes/basic/tokens/part-01.css":Tt,"./original-themes/themes/basic/trigger/part-01.css":Et,"./original-themes/themes/creative/effects/part-01.css":Dt,"./original-themes/themes/creative/panels/part-01.css":Ot,"./original-themes/themes/creative/tokens/part-01.css":kt,"./original-themes/themes/creative/trigger/part-01.css":At,"./original-themes/themes/cyberpunk/effects/part-01.css":jt,"./original-themes/themes/cyberpunk/effects/part-02.css":Mt,"./original-themes/themes/cyberpunk/effects/part-03.css":Nt,"./original-themes/themes/cyberpunk/effects/part-04.css":Pt,"./original-themes/themes/cyberpunk/panels/part-01.css":Ft,"./original-themes/themes/cyberpunk/tokens/part-01.css":It,"./original-themes/themes/cyberpunk/trigger/part-01.css":Lt,"./original-themes/themes/galaxy/effects/part-01.css":Rt,"./original-themes/themes/galaxy/effects/part-02.css":zt,"./original-themes/themes/galaxy/effects/part-03.css":Bt,"./original-themes/themes/galaxy/panels/part-01.css":Vt,"./original-themes/themes/galaxy/tokens/part-01.css":Ht,"./original-themes/themes/galaxy/trigger/part-01.css":Ut,"./original-themes/themes/neon/effects/part-01.css":Wt,"./original-themes/themes/neon/effects/part-02.css":Gt,"./original-themes/themes/neon/panels/part-01.css":Kt,"./original-themes/themes/neon/tokens/part-01.css":qt,"./original-themes/themes/neon/trigger/part-01.css":Jt,"./original-themes/themes/pro/effects/part-01.css":Yt,"./original-themes/themes/pro/panels/part-01.css":Xt,"./original-themes/themes/pro/tokens/part-01.css":Zt,"./original-themes/themes/pro/trigger/part-01.css":Qt}),tn=$t.map(e=>{let t=`./original-themes/${e}`,n=en[t];if(typeof n!=`string`)throw Error(`Missing original theme slice: ${t}`);return n}).join(``);function nn(e){let t=an();return e.appendChild(t),{popover:t,header:G(t,`.modal-header`),title:G(t,`.header-title`),sectionTitle:G(t,`.section-title`),phonetic:G(t,`.section-phonetic`),lexicalSection:G(t,`.lexical-section`),lexicalToggle:G(t,`.section-toggle-btn`),lexicalLoader:G(t,`.context-loader`),definitionsList:G(t,`.defs-list`),translationText:G(t,`.translation .text`),contextualText:G(t,`.contextual-analysis .text`),themeButton:G(t,`[data-action="theme"]`),closeButton:G(t,`[data-action="close"]`),themeLabel:G(t,`.footer-theme-label`),exploration:G(t,`.pcss3t`)}}function rn(){let e=document.createElement(`div`);return e.className=`oow-selection-trigger-button`,e.dataset.theme=`pro`,e.setAttribute(`aria-haspopup`,`dialog`),e}function an(){let e=document.createElement(`div`);e.className=`oow-popover`,e.id=`oow-popover`,e.setAttribute(`popover`,`auto`),e.setAttribute(`aria-live`,`polite`),e.dataset.theme=`pro`,e.dataset.placement=`side`;let t=document.createElement(`div`);return t.className=`content-body`,t.append(sn(),cn()),e.append(on(),t,ln()),e}function on(){let e=document.createElement(`div`);e.className=`modal-header`;let t=document.createElement(`div`);t.className=`header-left`;let n=document.createElement(`span`);n.className=`header-logo`,n.textContent=`小猹`,t.appendChild(n);let r=document.createElement(`div`);r.className=`header-center`;let i=document.createElement(`span`);i.className=`header-title`,i.setAttribute(`aria-live`,`polite`),r.appendChild(i);let a=document.createElement(`div`);return a.className=`header-right`,a.append(dn(`theme-toggle`,`Toggle theme`,`🎨`,`theme`),dn(``,`Close`,`✕`,`close`)),e.append(t,r,a),e}function sn(){let e=document.createElement(`div`);e.className=`collapsible-section lexical-section is-expanded`;let t=document.createElement(`div`);t.className=`section-header`,t.setAttribute(`aria-expanded`,`true`);let n=document.createElement(`div`);n.className=`header-left`;let r=document.createElement(`span`);r.className=`section-title`,r.textContent=`Lexical`;let i=document.createElement(`span`);i.className=`section-phonetic`,n.append(r,i);let a=document.createElement(`div`);a.className=`header-right`;let o=document.createElement(`button`);o.className=`section-toggle-btn`,o.setAttribute(`aria-label`,`Toggle section`),o.innerHTML=`<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,a.appendChild(o),t.append(n,a);let s=document.createElement(`div`);s.className=`section-content`;let c=document.createElement(`div`);c.className=`lexical-panel part2-content`,c.setAttribute(`role`,`region`),c.setAttribute(`aria-label`,`Lexical information`);let l=document.createElement(`ul`);l.className=`defs-list`;let u=document.createElement(`div`);u.className=`lexical-context-box`;let d=document.createElement(`div`);d.className=`context-loader`,d.style.display=`none`;let f=document.createElement(`div`);f.className=`eq`;for(let e=1;e<=5;e+=1){let t=document.createElement(`i`);t.className=`bar b${e}`,f.appendChild(t)}return d.appendChild(f),u.append(d,un(`translation`),un(`contextual-analysis`)),c.append(l,u),s.appendChild(c),e.append(t,s),e}function cn(){let e=document.createElement(`div`);e.className=`pcss3t pcss3t-effect-scale pcss3t-theme-1`;let t=document.createElement(`ul`);return t.dataset.role=`task-panels`,e.appendChild(t),e}function ln(){let e=document.createElement(`div`);e.className=`modal-footer`;let t=document.createElement(`span`);return t.className=`footer-theme-label`,t.style.cssText=`font-size:11px;color:var(--muted);padding:6px 12px;`,t.textContent=`Pro Dark · free`,e.appendChild(t),e}function un(e){let t=document.createElement(`div`);t.className=e;let n=document.createElement(`div`);return n.className=`text`,t.appendChild(n),t}function dn(e,t,n,r){let i=document.createElement(`button`);return i.className=[`action-btn`,e].filter(Boolean).join(` `),i.setAttribute(`aria-label`,t),i.textContent=n,i.dataset.action=r,i}function G(e,t){let n=e.querySelector(t);if(!n)throw Error(`OriginalPopoverView: missing "${t}"`);return n}function fn(e){let t={active:!1,startX:0,startY:0,left:0,top:0},n=()=>{t.active=!1,e.setDragging(!1),document.removeEventListener(`pointermove`,r),document.removeEventListener(`pointerup`,n)},r=n=>{t.active&&e.applyPosition({left:t.left+(n.clientX-t.startX),top:t.top+(n.clientY-t.startY)})};return{start(i){t.active=!0,t.startX=i.clientX,t.startY=i.clientY,{left:t.left,top:t.top}=e.getPosition(),e.setDragging(!0),document.addEventListener(`pointermove`,r),document.addEventListener(`pointerup`,n)},stop:n,dispose:n}}function pn(e){switch(e){case 1:return`href`;case 2:return`src`;case 4:return`class`;case 8:return`checked`;case 16:return`start`}}var mn=e=>{switch(e){case 1:return 3;case 2:return 4;case 3:return 5;case 4:return 6;case 5:return 7;default:return 8}},hn=24;function gn(e){let t=new Uint32Array(hn);return t[0]=1,{renderer:e,text:``,pending:``,tokens:t,len:0,token:1,fence_end:0,blockquote_idx:0,hr_char:``,hr_chars:0,fence_start:0,spaces:new Uint8Array(hn),indent:``,indent_len:0,table_state:0}}function _n(e){e.pending.length>0&&Q(e,`
`)}function K(e){e.text.length!==0&&(console.assert(e.len>0,`Never adding text to root`),e.renderer.add_text(e.renderer.data,e.text),e.text=``)}function q(e){console.assert(e.len>0,`No nodes to end`),--e.len,e.token=e.tokens[e.len],e.renderer.end_token(e.renderer.data)}function J(e,t){(e.tokens[e.len]===24||e.tokens[e.len]===23)&&t!==25&&q(e),e.len+=1,e.tokens[e.len]=t,e.token=t,e.renderer.add_token(e.renderer.data,t)}function vn(e,t,n){for(;n<=e.len;){if(e.tokens[n]===t)return n;n+=1}return-1}function Y(e,t){for(e.fence_start=0;e.len>t;)q(e)}function X(e,t){let n=0;for(let r=0;r<=e.len&&(t-=e.spaces[r],!(t<0));r+=1)switch(e.tokens[r]){case 9:case 10:case 20:case 25:n=r;break}for(;e.len>n;)q(e);return t}function yn(e,t){let n=-1,r=-1;for(let i=e.blockquote_idx+1;i<=e.len;i+=1)if(e.tokens[i]===25){if(e.indent_len<e.spaces[i]){r=-1;break}r=i}else e.tokens[i]===t&&(n=i);return r===-1?n===-1?(Y(e,e.blockquote_idx),J(e,t),!0):(Y(e,n),!1):(Y(e,r),J(e,t),!0)}function bn(e,t){J(e,25),e.spaces[e.len]=e.indent_len+t,Z(e),e.token=103}function Z(e){e.indent=``,e.indent_len=0,e.pending=``}function xn(e){switch(e){case 48:case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:return!0;default:return!1}}function Sn(e){switch(e){case 32:case 58:case 59:case 41:case 44:case 33:case 46:case 63:case 93:case 10:return!0;default:return!1}}function Cn(e){return xn(e)||Sn(e)}function Q(e,t){for(let n of t){if(e.token===101){switch(n){case` `:e.indent_len+=1;continue;case`	`:e.indent_len+=4;continue}let t=X(e,e.indent_len);e.indent_len=0,e.token=e.tokens[e.len],t>0&&Q(e,` `.repeat(t))}let t=e.pending+n;switch(e.token){case 21:case 1:case 20:case 24:case 23:switch(console.assert(e.text.length===0,`Root should not have any text`),e.pending[0]){case void 0:e.pending=n;continue;case` `:console.assert(e.pending.length===1),e.pending=n,e.indent+=` `,e.indent_len+=1;continue;case`	`:console.assert(e.pending.length===1),e.pending=n,e.indent+=`	`,e.indent_len+=4;continue;case`
`:if(console.assert(e.pending.length===1),e.tokens[e.len]===25&&e.token===21){q(e),Z(e),e.pending=n;continue}Y(e,e.blockquote_idx),Z(e),e.blockquote_idx=0,e.fence_start=0,e.pending=n;continue;case`#`:switch(n){case`#`:if(e.pending.length<6){e.pending=t;continue}break;case` `:X(e,e.indent_len),J(e,mn(e.pending.length)),Z(e);continue}break;case`>`:{let t=vn(e,20,e.blockquote_idx+1);t===-1?(Y(e,e.blockquote_idx),e.blockquote_idx+=1,e.fence_start=0,J(e,20)):e.blockquote_idx=t,Z(e),e.pending=n;continue}case`-`:case`*`:case`_`:if(e.hr_chars===0&&(console.assert(e.pending.length===1,`Pending should be one character`),e.hr_chars=1,e.hr_char=e.pending),e.hr_chars>0){switch(n){case e.hr_char:e.hr_chars+=1,e.pending=t;continue;case` `:e.pending=t;continue;case`
`:if(e.hr_chars<3)break;X(e,e.indent_len),e.renderer.add_token(e.renderer.data,22),e.renderer.end_token(e.renderer.data),Z(e),e.hr_chars=0;continue}e.hr_chars=0}if(e.pending[0]!==`_`&&e.pending[1]===` `){yn(e,23),bn(e,2),Q(e,t.slice(2));continue}break;case"`":if(e.pending.length<3){if(n==="`"){e.pending=t,e.fence_start=t.length;continue}e.fence_start=0;break}switch(n){case"`":e.pending.length===e.fence_start?(e.pending=t,e.fence_start=t.length):(J(e,2),Z(e),e.fence_start=0,Q(e,t));continue;case`
`:X(e,e.indent_len),J(e,10),e.pending.length>e.fence_start&&e.renderer.set_attr(e.renderer.data,4,e.pending.slice(e.fence_start)),Z(e),e.token=101;continue;default:e.pending=t;continue}case`+`:if(n!==` `)break;yn(e,23),bn(e,2);continue;case`0`:case`1`:case`2`:case`3`:case`4`:case`5`:case`6`:case`7`:case`8`:case`9`:if(e.pending[e.pending.length-1]===`.`){if(n!==` `)break;yn(e,24)&&e.pending!==`1.`&&e.renderer.set_attr(e.renderer.data,16,e.pending.slice(0,-1)),bn(e,e.pending.length+1);continue}else{let r=n.charCodeAt(0);if(r===46||xn(r)){e.pending=t;continue}}break;case`|`:Y(e,e.blockquote_idx),J(e,27),J(e,28),e.pending=``,Q(e,n);continue}let r=t;if(e.token===21)e.token=e.tokens[e.len],e.renderer.add_token(e.renderer.data,21),e.renderer.end_token(e.renderer.data);else if(e.indent_len>=4){let n=0;for(;n<4;n+=1)if(e.indent[n]===`	`){n+=1;break}r=e.indent.slice(n)+t,J(e,9)}else J(e,2);Z(e),Q(e,r);continue;case 27:if(e.table_state===1)switch(n){case`-`:case` `:case`|`:case`:`:e.pending=t;continue;case`
`:e.table_state=2,e.pending=``;continue;default:q(e),e.table_state=0;break}else switch(e.pending){case`|`:J(e,28),e.pending=``,Q(e,n);continue;case`
`:q(e),e.pending=``,e.table_state=0,Q(e,n);continue}break;case 28:switch(e.pending){case``:break;case`|`:J(e,29),q(e),e.pending=``,Q(e,n);continue;case`
`:q(e),e.table_state=Math.min(e.table_state+1,2),e.pending=``,Q(e,n);continue;default:J(e,29),Q(e,n);continue}break;case 29:if(e.pending===`|`){K(e),q(e),e.pending=``,Q(e,n);continue}break;case 9:switch(t){case`
    `:case`
   	`:case`
  	`:case`
 	`:case`
	`:e.text+=`
`,e.pending=``;continue;case`
`:case`
 `:case`
  `:case`
   `:e.pending=t;continue;default:e.pending.length===0?e.text+=n:(K(e),q(e),e.pending=n);continue}case 10:switch(n){case"`":e.pending=t;continue;case`
`:if(t.length===e.fence_start+e.fence_end+1){K(e),q(e),e.pending=``,e.fence_start=0,e.fence_end=0,e.token=101;continue}e.token=101;break;case` `:if(e.pending[0]===`
`){e.pending=t,e.fence_end+=1;continue}break}e.text+=e.pending,e.pending=n,e.fence_end=1;continue;case 11:switch(n){case"`":t.length===e.fence_start+Number(e.pending[0]===` `)?(K(e),q(e),e.pending=``,e.fence_start=0):e.pending=t;continue;case`
`:e.text+=e.pending,e.pending=``,e.token=21,e.blockquote_idx=0,K(e);continue;case` `:e.text+=e.pending,e.pending=n;continue;default:e.text+=t,e.pending=``;continue}case 103:switch(e.pending.length){case 0:if(n!==`[`)break;e.pending=t;continue;case 1:if(n!==` `&&n!==`x`)break;e.pending=t;continue;case 2:if(n!==`]`)break;e.pending=t;continue;case 3:if(n!==` `)break;e.renderer.add_token(e.renderer.data,26),e.pending[1]===`x`&&e.renderer.set_attr(e.renderer.data,8,``),e.renderer.end_token(e.renderer.data),e.pending=` `;continue}e.token=e.tokens[e.len],e.pending=``,Q(e,t);continue;case 14:case 15:{let t=`*`,r=12;if(e.token===15&&(t=`_`,r=13),t===e.pending){if(K(e),t===n){q(e),e.pending=``;continue}J(e,r),e.pending=n;continue}break}case 12:case 13:{let r=`*`,i=14;switch(e.token===13&&(r=`_`,i=15),e.pending){case r:r===n?e.tokens[e.len-1]===i?e.pending=t:(K(e),J(e,i),e.pending=``):(K(e),q(e),e.pending=n);continue;case r+r:let a=e.token;K(e),q(e),q(e),r===n?e.pending=``:(J(e,a),e.pending=n);continue}break}case 16:if(t===`~~`){K(e),q(e),e.pending=``;continue}break;case 105:n===`
`?(K(e),J(e,30),e.pending=``):(e.token=e.tokens[e.len],e.pending[0]===`\\`?e.text+=`[`:e.text+=`$$`,e.pending=``,Q(e,n));continue;case 30:if(t===`\\]`||t===`$$`){K(e),q(e),e.pending=``;continue}break;case 31:if(t===`\\)`||e.pending[0]===`$`){K(e),q(e),n===`)`?e.pending=``:e.pending=n;continue}break;case 102:t===`http://`||t===`https://`?(K(e),J(e,18),e.pending=t,e.text=t):`http:/`[e.pending.length]===n||`https:/`[e.pending.length]===n?e.pending=t:(e.token=e.tokens[e.len],Q(e,n));continue;case 17:case 19:if(e.pending===`]`){K(e),n===`(`?e.pending=t:(q(e),e.pending=n);continue}if(e.pending[0]===`]`&&e.pending[1]===`(`){if(n===`)`){let t=e.token===17?1:2,n=e.pending.slice(2);e.renderer.set_attr(e.renderer.data,t,n),q(e),e.pending=``}else e.pending+=n;continue}break;case 18:n===` `||n===`
`||n===`\\`?(e.renderer.set_attr(e.renderer.data,1,e.pending),K(e),q(e),e.pending=n):(e.text+=n,e.pending=t);continue;case 104:if(t.startsWith(`<br`)){if(t.length===3||n===` `||n===`/`&&(t.length===4||e.pending[e.pending.length-1]===` `)){e.pending=t;continue}if(n===`>`){K(e),e.token=e.tokens[e.len],e.renderer.add_token(e.renderer.data,21),e.renderer.end_token(e.renderer.data),e.pending=``;continue}}e.token=e.tokens[e.len],e.text+=`<`,e.pending=e.pending.slice(1),Q(e,n);continue}switch(e.pending[0]){case`\\`:if(e.token===19||e.token===30||e.token===31)break;switch(n){case`(`:K(e),J(e,31),e.pending=``;continue;case`[`:e.token=105,e.pending=t;continue;case`
`:e.pending=n;continue;default:let r=n.charCodeAt(0);e.pending=``,e.text+=xn(r)||r>=65&&r<=90||r>=97&&r<=122?t:n;continue}case`
`:switch(e.token){case 19:case 30:case 31:break;case 3:case 4:case 5:case 6:case 7:case 8:K(e),Y(e,e.blockquote_idx),e.blockquote_idx=0,e.pending=n;continue;default:K(e),e.pending=n,e.token=21,e.blockquote_idx=0;continue}break;case`<`:if(e.token!==19&&e.token!==30&&e.token!==31){K(e),e.pending=t,e.token=104;continue}break;case"`":if(e.token===19)break;n==="`"?(e.fence_start+=1,e.pending=t):(e.fence_start+=1,K(e),J(e,11),e.text=n===` `||n===`
`?``:n,e.pending=``);continue;case`_`:case`*`:{if(e.token===19||e.token===30||e.token===31||e.token===14)break;let r=12,i=14,a=e.pending[0];if(a===`_`&&(r=13,i=15),e.pending.length===1){if(a===n){e.pending=t;continue}if(n!==` `&&n!==`
`){K(e),J(e,r),e.pending=n;continue}}else{if(a===n){K(e),J(e,i),J(e,r),e.pending=``;continue}if(n!==` `&&n!==`
`){K(e),J(e,i),e.pending=n;continue}}break}case`~`:if(e.token!==19&&e.token!==16){if(e.pending===`~`){if(n===`~`){e.pending=t;continue}}else if(n!==` `&&n!==`
`){K(e),J(e,16),e.pending=n;continue}}break;case`$`:if(e.token!==19&&e.token!==16&&e.pending===`$`)if(n===`$`){e.token=105,e.pending=t;continue}else if(Cn(n.charCodeAt(0)))break;else{K(e),J(e,31),e.pending=n;continue}break;case`[`:if(e.token!==19&&e.token!==17&&e.token!==30&&e.token!==31&&n!==`]`){K(e),J(e,17),e.pending=n;continue}break;case`!`:if(e.token!==19&&n===`[`){K(e),J(e,19),e.pending=``;continue}break;case` `:if(e.pending.length===1&&n===` `)continue;break}if(e.token!==19&&e.token!==17&&e.token!==30&&e.token!==31&&n===`h`&&(e.pending===` `||e.pending===``)){e.text+=e.pending,e.pending=n,e.token=102;continue}e.text+=e.pending,e.pending=n}K(e)}function wn(e){return{add_token:Tn,end_token:En,add_text:Dn,set_attr:On,data:{nodes:[e,,,,,],index:0}}}function Tn(e,t){let n=e.nodes[e.index],r;switch(t){case 1:return;case 20:r=document.createElement(`blockquote`);break;case 2:r=document.createElement(`p`);break;case 21:r=document.createElement(`br`);break;case 22:r=document.createElement(`hr`);break;case 3:r=document.createElement(`h1`);break;case 4:r=document.createElement(`h2`);break;case 5:r=document.createElement(`h3`);break;case 6:r=document.createElement(`h4`);break;case 7:r=document.createElement(`h5`);break;case 8:r=document.createElement(`h6`);break;case 12:case 13:r=document.createElement(`em`);break;case 14:case 15:r=document.createElement(`strong`);break;case 16:r=document.createElement(`s`);break;case 11:r=document.createElement(`code`);break;case 18:case 17:r=document.createElement(`a`);break;case 19:r=document.createElement(`img`);break;case 23:r=document.createElement(`ul`);break;case 24:r=document.createElement(`ol`);break;case 25:r=document.createElement(`li`);break;case 26:let e=r=document.createElement(`input`);e.type=`checkbox`,e.disabled=!0;break;case 9:case 10:n=n.appendChild(document.createElement(`pre`)),r=document.createElement(`code`);break;case 27:r=document.createElement(`table`);break;case 28:switch(n.children.length){case 0:n=n.appendChild(document.createElement(`thead`));break;case 1:n=n.appendChild(document.createElement(`tbody`));break;default:n=n.children[1]}r=document.createElement(`tr`);break;case 29:r=document.createElement(n.parentElement?.tagName===`THEAD`?`th`:`td`);break;case 30:r=document.createElement(`equation-block`);break;case 31:r=document.createElement(`equation-inline`);break}e.nodes[++e.index]=n.appendChild(r)}function En(e){--e.index}function Dn(e,t){e.nodes[e.index].appendChild(document.createTextNode(t))}function On(e,t,n){e.nodes[e.index].setAttribute(pn(t),n)}function kn(e,t){return{parser:null,renderedLength:0,finalized:!1,container:e,visibility:t}}function $(e,t){if(e.replaceChildren(),!t)return;let n=gn(wn(e));Q(n,t),_n(n)}function An(e,t){if(e.visibility.setLoadingVisible(t.status===`loading`),e.visibility.setErrorMessage(t.status===`error`?t.errorMessage??``:``),t.status===`idle`)return jn(e);t.content.length<e.renderedLength&&jn(e),e.parser||(e.parser=gn(wn(e.container)),e.finalized=!1);let n=e.parser;if(!n)return;let r=t.content.slice(e.renderedLength);r&&(Q(n,r),e.renderedLength=t.content.length),t.status!==`loading`&&!e.finalized&&(_n(n),e.finalized=!0,e.parser=null)}function jn(e){e.parser&&_n(e.parser),e.parser=null,e.renderedLength=0,e.finalized=!1,e.container.replaceChildren(),e.visibility.setErrorMessage(``),e.visibility.setLoadingVisible(!1)}function Mn(e,t){t.setLoadingVisible(e.status===`loading`),t.setErrorMessage?.(e.status===`error`?e.errorMessage??`Lexical analysis failed.`:``),t.setPhonetic(e.lexical?.phonetic??``),t.renderTranslation(e.lexical?.translation),t.renderContextual(e.lexical?.contextualAnalysis),t.renderDefinitions(e.lexical?.definitions??[])}function Nn(e,t,n){e.replaceChildren(...t.map(n))}function Pn(e){let t=document.createElement(`li`);t.className=`def-item`;let n=document.createElement(`div`);n.className=`pos-meaning`,e.pos&&n.appendChild(Object.assign(document.createElement(`span`),{className:`pos`,textContent:e.pos}));let r=document.createElement(`span`);if(r.className=`meaning`,$(r,e.meaning??``),n.appendChild(r),t.appendChild(n),e.example?.source||e.example?.target){let n=document.createElement(`div`);if(n.className=`example`,e.example.source){let t=document.createElement(`span`);t.className=`src`,$(t,e.example.source),n.appendChild(t)}if(e.example.source&&e.example.target&&n.appendChild(Object.assign(document.createElement(`span`),{className:`arrow`,textContent:` → `})),e.example.target){let t=document.createElement(`span`);t.className=`tgt`,$(t,e.example.target),n.appendChild(t)}t.appendChild(n)}return t}function Fn(e,t){let n=document.documentElement.clientWidth,r=e.offsetWidth||450,i=t.left+t.width/2<n/2?n-r-16:16;e.style.setProperty(`--oow-modal-left`,`${Math.round(i)}px`),e.style.setProperty(`--oow-modal-top`,`16px`),e.dataset.placement=`side`,e.classList.add(`is-positioned`)}function In(e,t,n){let r=e.cloneRange();r.collapse(!1);let i=document.createElement(`span`);i.dataset.scanExplainInlineTrigger=`true`,i.setAttribute(`contenteditable`,`false`);let a=i.attachShadow({mode:`open`}),o=document.createElement(`style`);o.textContent=`${tn}
    :host {
      display: inline-block;
      position: relative;
      width: 16px;
      height: 14px;
      margin: 0 4px;
      vertical-align: baseline;
      line-height: 1;
      user-select: none;
    }

    .oow-selection-trigger-button {
      position: absolute !important;
      top: 2px !important;
      left: 0 !important;
      margin: 0 !important;
    }
  `;let s=rn();return s.dataset.theme=t,s.classList.add(`visible`),s.classList.remove(`hidden`),s.addEventListener(`pointerenter`,()=>{n()}),s.addEventListener(`click`,()=>{n()}),a.append(o,s),r.insertNode(i),{triggerHost:i,triggerElement:s}}function Ln(e){if(!e)return;let t=e.parentNode;e.remove(),t instanceof Element&&!window.getSelection()?.toString().trim()&&t.normalize()}function Rn(e,t){return{container:e,visibility:t}}function zn(e,t){if(e.visibility.setLoadingVisible(t.status===`loading`),e.visibility.setErrorMessage(t.status===`error`?t.errorMessage??``:``),t.status===`idle`){e.container.textContent=``;return}e.container.textContent=Bn(t.content)}function Bn(e){let t=e.trim();if(!t)return``;try{let e=t.startsWith("```")?t.replace(/^```(?:json)?\s*/i,``).replace(/\s*```$/,``).trim():t;return JSON.stringify(JSON.parse(e),null,2)}catch{return e}}function Vn(e){return e.replace(/[^a-z0-9_-]/gi,`-`)}function Hn(e,t,n){let r=Un(t,n),i=`tab-content ${r} typography`;return e.id===`etymology`?{tabClassName:r,panelItemClassName:i,panelClassName:`etymology-panel part2-content`,contentClassName:`etymology-panel-content markdown-content`,loadingText:`Streaming etymology…`}:e.id===`information`?{tabClassName:r,panelItemClassName:i,panelClassName:`information-panel base-markdown-panel part2-content`,contentClassName:`info-panel-content markdown-content`,loadingText:`Streaming interpretation…`}:{tabClassName:r,panelItemClassName:i,panelClassName:`base-markdown-panel part2-content`,contentClassName:`markdown-content`,loadingText:`Streaming ${e.label}...`}}function Un(e,t){return e===0?`tab-content-first`:e===t-1?`tab-content-last`:`tab-content-${e+1}`}function Wn(e,t,n){let r=new Map,i=document.createElement(`ul`);return e.replaceChildren(),t.forEach((a,o)=>{let s=Hn(a,o,t.length),c=document.createElement(`input`);c.type=`radio`,c.name=`pcss3t`,c.id=`popover-task-${Vn(a.id)}`,c.className=s.tabClassName,c.addEventListener(`change`,()=>{c.checked&&n(a.id)});let l=document.createElement(`label`);l.htmlFor=c.id,l.dataset.role=`task-tab`,l.dataset.taskId=a.id,l.textContent=a.label,l.title=a.label;let u=document.createElement(`li`);u.className=s.panelItemClassName,u.dataset.role=`task-panel`,u.dataset.taskId=a.id;let d=document.createElement(`div`);d.className=s.panelClassName;let f=document.createElement(`div`);f.className=`loading`,f.dataset.role=`task-loading`,f.style.display=`none`,f.textContent=s.loadingText;let p=document.createElement(`div`);p.className=`error-message`,p.dataset.role=`task-error`,p.style.display=`none`;let m,h;if(a.kind===`markdown`){let t=document.createElement(`div`);t.className=s.contentClassName,t.dataset.role=`task-content`,t.dataset.taskId=a.id;let n=kn(t,{setLoadingVisible:e=>{f.style.display=e?``:`none`},setErrorMessage:e=>{p.textContent=e,p.style.display=e?``:`none`}});m=e=>{An(n,e)},h=()=>{jn(n)},d.append(f,p,t),u.appendChild(d),r.set(a.id,{descriptor:a,radio:c,panel:u,render:m,dispose:h}),e.append(c,l),i.appendChild(u);return}let g=document.createElement(`pre`);g.className=`${s.contentClassName} scanex-json`,g.dataset.role=`task-content`,g.dataset.taskId=a.id;let _=Rn(g,{setLoadingVisible:e=>{f.style.display=e?``:`none`},setErrorMessage:e=>{p.textContent=e,p.style.display=e?``:`none`}});m=e=>{zn(_,e)},h=()=>{g.textContent=``,f.style.display=`none`,p.textContent=``,p.style.display=`none`},d.append(f,p,g),u.appendChild(d),r.set(a.id,{descriptor:a,radio:c,panel:u,render:m,dispose:h}),e.append(c,l),i.appendChild(u)}),e.appendChild(i),r}function Gn(e,t){for(let n of e){let e=n.descriptor.id===t;n.radio.checked=e,n.panel.hidden=!e}}function Kn(e,t){for(let n of e)n.render(t(n.descriptor.id))}function qn(e){for(let t of e.values())t.dispose();e.clear()}var Jn=class{host;shadow;refs;drag;triggerHost=null;triggerElement=null;currentTheme=`pro`;taskRuntimes=new Map;callbacks=null;unsubscribers=[];constructor(e){this.host=document.createElement(`div`),this.host.id=`scan-explain-popover-root`,document.documentElement.appendChild(this.host),this.shadow=this.host.attachShadow({mode:`open`});let t=document.createElement(`style`);t.textContent=tn,this.shadow.appendChild(t),this.refs=nn(this.shadow),this.drag=fn({getPosition:()=>{let e=getComputedStyle(this.refs.popover);return{left:parseInt(e.getPropertyValue(`--oow-modal-left`),10)||this.refs.popover.offsetLeft,top:parseInt(e.getPropertyValue(`--oow-modal-top`),10)||this.refs.popover.offsetTop}},applyPosition:({left:e,top:t})=>{this.refs.popover.style.setProperty(`--oow-modal-left`,`${e}px`),this.refs.popover.style.setProperty(`--oow-modal-top`,`${t}px`)},setDragging:e=>{this.refs.header.classList.toggle(`is-dragging`,e)}}),this.bindStaticEvents(),this.subscribeToViewModel(e)}setCallbacks(e){this.callbacks=e}containsEvent(e){let t=e.composedPath();return t.includes(this.host)||(this.triggerHost?t.includes(this.triggerHost):!1)}showTrigger(e){this.hideTrigger();let{triggerHost:t,triggerElement:n}=In(e,this.currentTheme,()=>{this.callbacks?.onTriggerActivate()});this.triggerHost=t,this.triggerElement=n,this.triggerElement.classList.add(`visible`),this.triggerElement.classList.remove(`hidden`)}hideTrigger(){Ln(this.triggerHost),this.triggerHost=null,this.triggerElement=null}activateTrigger(){this.triggerElement?.classList.add(`activated`)}openAt(e){if(Fn(this.refs.popover,e),this.refs.popover.classList.add(`is-visible`),this.refs.popover.classList.remove(`is-hidden`),typeof this.refs.popover.showPopover==`function`)try{this.refs.popover.showPopover()}catch{}}close(){if(typeof this.refs.popover.hidePopover==`function`)try{this.refs.popover.hidePopover()}catch{}this.refs.popover.classList.remove(`is-visible`,`is-positioned`),this.refs.popover.classList.add(`is-hidden`)}destroy(){this.drag.dispose();for(let e of this.unsubscribers)e();this.unsubscribers=[],qn(this.taskRuntimes),Ln(this.triggerHost),this.triggerHost=null,this.triggerElement=null,this.host.remove()}bindStaticEvents(){this.refs.themeButton.addEventListener(`click`,()=>{this.callbacks?.onCycleTheme()}),this.refs.closeButton.addEventListener(`click`,()=>{this.callbacks?.onClose()}),this.refs.lexicalToggle.addEventListener(`click`,()=>{this.callbacks?.onToggleLexical()}),this.refs.header.addEventListener(`pointerdown`,e=>{e.target?.closest(`button`)||this.drag.start(e)})}subscribeToViewModel(e){this.unsubscribers.push(e.title.subscribe(e=>{this.refs.title.textContent=e,this.refs.sectionTitle.textContent=e})),this.unsubscribers.push(e.theme.subscribe(e=>{this.currentTheme=e,this.refs.popover.dataset.theme=e,this.triggerElement&&(this.triggerElement.dataset.theme=e);let t=a.find(t=>t.id===e);this.refs.themeLabel.textContent=t?`${t.name} · ${t.tier}`:e})),this.unsubscribers.push(e.isOpen.subscribe(e=>{e||(this.close(),this.hideTrigger())})),this.unsubscribers.push(e.lexicalCollapsed.subscribe(e=>{this.refs.lexicalSection.classList.toggle(`is-expanded`,!e),this.refs.lexicalSection.classList.toggle(`is-collapsed`,e)})),this.unsubscribers.push(e.tasks.subscribe(()=>{this.renderTaskSurfaces(e)})),this.unsubscribers.push(e.selectedTab.subscribe(t=>{Gn(this.taskRuntimes.values(),t),Kn(this.taskRuntimes.values(),t=>e.getTaskState(t))})),this.unsubscribers.push(e.lexicalState.subscribe(e=>{this.updateLexicalState(e)})),this.unsubscribers.push(e.taskStates.subscribe(()=>{Kn(this.taskRuntimes.values(),t=>e.getTaskState(t))}))}renderTaskSurfaces(e){qn(this.taskRuntimes),this.taskRuntimes=Wn(this.refs.exploration,e.getTabTasks(),e=>{this.callbacks?.onSelectTab(e)}),Gn(this.taskRuntimes.values(),e.selectedTab.value),Kn(this.taskRuntimes.values(),t=>e.getTaskState(t))}updateLexicalState(e){Mn(e,{setLoadingVisible:e=>{this.refs.lexicalLoader.style.display=e?`grid`:`none`},setPhonetic:e=>{this.refs.phonetic.textContent=e?` ${e}`:``},renderTranslation:e=>{this.refs.translationText.replaceChildren(),e&&$(this.refs.translationText,e)},renderContextual:e=>{this.refs.contextualText.replaceChildren(),e&&$(this.refs.contextualText,e)},renderDefinitions:e=>Nn(this.refs.definitionsList,e,Pn)})}},Yn=100;function Xn(e){return e?.trim()??``}function Zn(e,t){return e.length<=t?e:e.slice(0,t)}function Qn(e,t){return e.length<=t?e:e.slice(-t)}function $n(e,t,n){let r=[Qn(Xn(e),Yn),Xn(t),Zn(Xn(n),Yn)].filter(Boolean).join(`

`);return r?`${r}\n`:``}var er={basic:`#0ea5e9`,pro:`#3b82f6`,creative:`#ed8936`,galaxy:`#c084fc`,neon:`#39ff14`,cyberpunk:`#ff006e`,aurora:`#67e8f9`},tr=class{viewModel=new ct(new rt);view=new Jn(this.viewModel);pendingSelection=null;highlightRange=null;highlightStyle=null;start(){this.view.setCallbacks({onTriggerActivate:()=>{this.pendingSelection&&(this.view.activateTrigger(),this.viewModel.openSelection(this.pendingSelection),this.view.openAt(this.pendingSelection.lastLineRect??this.pendingSelection.rect))},onClose:()=>{this.pendingSelection=null,this.clearSelectionHighlight(),this.clearBrowserSelection(),this.viewModel.close()},onCycleTheme:()=>{this.viewModel.cycleTheme()},onToggleLexical:()=>{this.viewModel.toggleLexicalCollapsed()},onSelectTab:e=>{this.viewModel.selectTab(e)}}),document.addEventListener(`mouseup`,this.handleMouseUp),document.addEventListener(`selectionchange`,this.handleSelectionChange),document.addEventListener(`pointerdown`,this.handlePointerDown),window.addEventListener(`scroll`,this.handleViewportChange,!0),window.addEventListener(`resize`,this.handleViewportChange),n.runtime.onMessage.addListener(this.handleRuntimeMessage),this.viewModel.theme.subscribe(e=>{this.updateHighlightColor(e)})}handleRuntimeMessage=e=>{c(e)&&this.viewModel.handleStreamEvent(e)};handleViewportChange=()=>{this.view.hideTrigger(),this.viewModel.isOpen.value||(this.pendingSelection=null,this.clearSelectionHighlight())};handleSelectionChange=()=>{this.viewModel.isOpen.value||window.getSelection()?.toString().trim()||(this.pendingSelection=null,this.view.hideTrigger(),this.clearSelectionHighlight())};handlePointerDown=e=>{this.view.containsEvent(e)||window.getSelection()?.toString().trim()||(this.pendingSelection=null,this.view.hideTrigger(),this.viewModel.isOpen.value||this.clearSelectionHighlight())};handleMouseUp=e=>{this.view.containsEvent(e)||window.setTimeout(()=>{let e=this.readSelection();if(!e){this.viewModel.isOpen.value||(this.view.hideTrigger(),this.clearSelectionHighlight()),this.pendingSelection=null;return}this.pendingSelection=e,this.applySelectionHighlight(),this.view.showTrigger(this.readTriggerRange())},10)};readSelection(){let e=window.getSelection();if(!e||e.rangeCount===0||e.isCollapsed)return null;let t=e.toString().replace(/\s+/g,` `).trim();if(!t)return null;let n=e.getRangeAt(0),r=n.getBoundingClientRect();if(!r.width&&!r.height)return null;let i=n.getClientRects(),a=i.length>0?i[i.length-1]:r;return{text:t,context:this.readContext(e),trigger:`text-selection`,blockIndex:0,sourceLabel:window.location.hostname,rect:o(r),lastLineRect:o(a)}}readContext(e){let t=e.anchorNode;if(!t)return``;let n=(t.nodeType===Node.TEXT_NODE?t.parentElement:t)?.closest(`p, li, blockquote, article, section, div, h1, h2, h3, h4, h5, h6`);return n?$n(n.previousElementSibling?.textContent,n.textContent,n.nextElementSibling?.textContent):$n(``,e.toString(),``)}readTriggerRange(){let e=window.getSelection();if(!e||e.rangeCount===0||e.isCollapsed)throw Error(`PopoverFeature: expected an active selection range for trigger placement.`);return e.getRangeAt(0).cloneRange()}applySelectionHighlight(){this.clearSelectionHighlight();let e=window.getSelection();if(!e||e.rangeCount===0||e.isCollapsed)return;let t=e.getRangeAt(0).cloneRange();if(this.highlightRange=t,!(`Highlight`in window))return;let n=new Highlight(t);CSS.highlights.set(`scan-explain-selection`,n),this.highlightStyle||(this.highlightStyle=document.createElement(`style`),this.highlightStyle.dataset.scanExplain=`highlight`,document.head.appendChild(this.highlightStyle));let r=er[this.viewModel.theme.value]??`#3b82f6`;this.highlightStyle.textContent=`::highlight(scan-explain-selection) { text-decoration: underline wavy ${r}; text-decoration-skip-ink: none; text-underline-offset: 3px; background-color: transparent; }`}clearSelectionHighlight(){`Highlight`in window&&CSS.highlights.delete(`scan-explain-selection`),this.highlightRange=null}updateHighlightColor(e){if(!this.highlightStyle||!this.highlightRange)return;let t=er[e]??`#3b82f6`;this.highlightStyle.textContent=`::highlight(scan-explain-selection) { text-decoration: underline wavy ${t}; text-decoration-skip-ink: none; text-underline-offset: 3px; background-color: transparent; }`}clearBrowserSelection(){window.getSelection()?.removeAllRanges()}},nr=e({matches:[`<all_urls>`],allFrames:!0,main(){new tr().start()}}),rr={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},ir=class e extends Event{static EVENT_NAME=ar(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function ar(e){return`${n?.runtime?.id}:content:${e}`}var or=typeof globalThis.navigation?.addEventListener==`function`;function sr(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),or?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new ir(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new ir(e,t)),t=e)},1e3))}}}var cr=class e{static SCRIPT_STARTED_MESSAGE_TYPE=ar(`wxt:content-script-started`);id;abortController;locationWatcher=sr(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return n.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?ar(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),rr.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},lr={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=nr;return await e(new cr(`content`,t))}catch(e){throw lr.error(`The content script "content" crashed on startup!`,e),e}})()})();
content;